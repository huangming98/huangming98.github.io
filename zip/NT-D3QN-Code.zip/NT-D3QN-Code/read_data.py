#
# @Author      : Huang Ming
# @Create      : 2025/2/15 18:26
# @University  : Beijing Institute of Technology
# Copyright (C) 2026-05 Huang Ming, indie developer. All Rights Reserve
import pandas as pd
import numpy as np



def read_product(EXCEL):
    # 使用pandas的read_excel函数读取Excel文件
    # 指定sheet_name为'生产订单信息'，header默认为0（假设第一行是列名）
    df = pd.read_excel(io=EXCEL, sheet_name='生产订单信息', engine='openpyxl')
    product_info_array = np.array(df.values)  #df.values 虽然也是np矩阵但不是数值格式，所以需要转换为np
    return product_info_array


def read_transportation(EXCEL):
    #存储运输时间矩阵（TTM）信息
    #先定义列表

    df = pd.read_excel(io=EXCEL, sheet_name='装配岛运输信息', engine='openpyxl')
    TTM=np.array(df.values[:,1:]).astype('float')
    return TTM

def read_Processing(EXCEL):
    #存储加工时间矩阵（PTM）信息
    df = pd.read_excel(io=EXCEL, sheet_name='工艺加工岛信息', engine='openpyxl')
    PTM = np.array(df.values[:, 1:]).astype('float')
    return PTM


def read_process_pre(EXCEL):
    #存储工序前置矩阵（PPM）信息
    df = pd.read_excel(io=EXCEL, sheet_name='前置工序', engine='openpyxl')
    PPM = np.array(df.values[:, 1:]).astype('int')
    return PPM