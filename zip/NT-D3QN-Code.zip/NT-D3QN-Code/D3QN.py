#
# @Author      : Huang Ming
# @Create      : 2025/2/15 18:26
# @University  : Beijing Institute of Technology
# Copyright (C) 2026-05 Huang Ming, indie developer. All Rights Reserve
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np


# 神经网络参数设置
class Net(nn.Module):
    """docstring for Net"""
    def __init__(self,input_dim, output_dim):
        # 设置神经网络层数及每层大小
        super(Net, self).__init__()
        self.fc1 = nn.Linear(input_dim, 256)
        # 第二层（中间层1）
        self.fc2 = nn.Linear(256, 128)
        # 第三层（中间层2）
        self.fc3 = nn.Linear(128, 64)
        self.V = nn.Linear(64, 1)
        self.A = nn.Linear(64, output_dim)

    # 基于所给定状态，通过神经网络计算Q值进行动作选择
    def forward(self, x):
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        x = F.relu(self.fc3(x))
        V = self.V(x)
        A = self.A(x)
        Q = V + A - torch.mean(A, dim=-1, keepdim=True)
        return Q

# 创建D3QN智能体
class D3QN():

    def __init__(self,NUM_STATES, NUM_ACTIONS, LR, MEMORY_CAPACITY, BATCH_SIZE, EPSILON, Q_NETWORK_ITERATION, GAMMA):
        # 设置D3QN智能体、包括创建神经网络、创建样本池等
        super(D3QN, self).__init__()
        self.device = torch.device("cuda") if torch.cuda.is_available() else torch.device("cpu")
        self.NUM_STATES = NUM_STATES  # 学习率
        self.NUM_ACTIONS = NUM_ACTIONS  # 学习率
        self.LR = LR  #学习率
        self.MEMORY_CAPACITY = MEMORY_CAPACITY #经验回访池容量
        self.BATCH_SIZE = BATCH_SIZE #mini_batch尺寸
        self.Q_NETWORK_ITERATION = Q_NETWORK_ITERATION # Q_net Q_target 对齐频率
        self.GAMMA = GAMMA  # 折现系数
        self.eval_net, self.target_net = Net(self.NUM_STATES,self.NUM_ACTIONS).to(self.device), Net(self.NUM_STATES,self.NUM_ACTIONS).to(self.device)
        self.eval_net.apply(self.init_weights)
        self.target_net.apply(self.init_weights)
        self.learn_step_counter = 0
        self.memory_counter = 0
        self.memory = np.zeros((self.MEMORY_CAPACITY, NUM_STATES * 2 + 2))

        self.optimizer = torch.optim.Adam(self.eval_net.parameters(), lr=self.LR)
        self.loss_func = nn.MSELoss()
        self.loss = []
        self.EPSILON = EPSILON

    def init_weights(self, layer):
        # 如果为卷积层，使用正态分布初始化
        if type(layer) == nn.Conv2d:
            nn.init.normal_(layer.weight, mean=0, std=0.5)
        # 如果为全连接层，权重使用均匀分布初始化，偏置初始化为0.1
        elif type(layer) == nn.Linear:
            # nn.init.uniform_(layer.weight, a=-0.1, b=0.1)
            # 使用权重
            nn.init.kaiming_normal_(layer.weight, mode='fan_out',
                                    nonlinearity='relu')  # 选择"fan_in"可以保留前向计算中权重方差的大小。选择"fan_out"将保留后向传播的方差大小。
            nn.init.constant_(layer.bias, 0.1)


    # 基于状态进行动作选择
    def choose_action(self, state):
        state = torch.unsqueeze(torch.FloatTensor(state), 0).to(self.device)  # get a 1D array
        # 选择Q值最优对应动作 EPSILON的概率随机选，并且从1~0.1随迭代之间次数逐渐建降低
        if np.random.randn() >= self.EPSILON:  # greedy policy
            action_value = self.eval_net.forward(state).cpu()  #######dueling change
            action = torch.max(action_value, 1)[1].data.numpy()
            # action = T.argmax(A).item()
            action = action[0]

        # 选择随机动作
        else:  # random policy
            action = np.random.randint(0, self.NUM_ACTIONS)
        return action

    # 经验存储至样本池中
    def store_transition(self, state, action, reward, next_state):
        transition = np.hstack((state, [action, reward], next_state))
        index = self.memory_counter % self.MEMORY_CAPACITY  #经验池迭代更新
        self.memory[index, :] = transition
        self.memory_counter += 1

    # 更新神经网络
    def learn(self, done):

        # update the parameters
        # 以Q_NETWORK_UPDATE 为周期更新目标网络
        if self.learn_step_counter % self.Q_NETWORK_ITERATION == 0:
            self.target_net.load_state_dict(self.eval_net.state_dict())
        self.learn_step_counter += 1

        # 从样本池中获取BATCH_SIZE数量的样本进行学习
        # sample batch from memory
        sample_index = np.random.choice(self.MEMORY_CAPACITY, self.BATCH_SIZE)
        batch_memory = self.memory[sample_index, :]
        batch_state = torch.FloatTensor(batch_memory[:, :self.NUM_STATES]).to(self.device)
        batch_action = torch.LongTensor(batch_memory[:, self.NUM_STATES:self.NUM_STATES + 1].astype(int)).to(self.device)
        batch_reward = torch.FloatTensor(batch_memory[:, self.NUM_STATES + 1:self.NUM_STATES + 2]).to(self.device)
        batch_next_state = torch.FloatTensor(batch_memory[:, -self.NUM_STATES:]).to(self.device)

        # 根据样本计算损失函数
        # q_eval
        q_eval = self.eval_net(batch_state).gather(1, batch_action)
        with torch.no_grad():
            max_actions = self.eval_net(batch_next_state).max(1)[1].view(-1, 1)
            # max_actions = torch.argmax(self.eval_net(batch_next_state), dim=-1).view(-1, 1)
            max_next_q_values = self.target_net(batch_next_state).gather(1, max_actions)
            q_target = batch_reward + self.GAMMA * max_next_q_values

        loss = self.loss_func(q_eval, q_target.detach())
        #需要将目标网络输出的 q_target 从计算图中分离出来（使用 detach ()），这样反向传播时就不会计算目标网络的梯度，只更新评估网络的参数。

        # 基于损失函数进行优化更新
        if done:
            self.loss.append(loss.detach().item())  # 储存每一epoch的NN的loss
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()
