#
# @Author      : Huang Ming
# @Create      : 2025/2/15 18:26
# @University  : Beijing Institute of Technology
# Copyright (C) 2026-05 Huang Ming, indie developer. All Rights Reserve
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import torch
import time
import os

from D3QN import D3QN
import model_training as mt
import toolset
import psutil

EXCEL= 'data8-4-8.xlsx'

# 获取当前进程的内存使用情况
def get_process_memory_usage():
    """
    获取并打印当前进程的内存使用情况。
    该函数使用psutil库来获取当前进程的内存信息，具体是驻留集大小（RSS），并将其转换为MB并保留两位小数。
    """
    process = psutil.Process()
    memory_info = process.memory_info()
    rss = memory_info.rss / (1024 ** 2)  # 转换为 MB
    print(f"当前进程的驻留集大小（RSS）: {rss:.2f} MB")


# 超参数设置
LR = 0.001
MEMORY_CAPACITY = 2000
BATCH_SIZE = 512
EPSILON = 1
Q_NETWORK_ITERATION = 100
GAMMA=0.9

# 获取动作空间、状态空间大小
NUM_STATES = 7
NUM_ACTIONS =6
# 设置迭代次数、初始最大奖励
episodes = 1000
# 多目标优化的分解权重粒度
Decomposition_number= 20

def main():
    #########获得初始解#############
    Weight=np.zeros((Decomposition_number+1,2),dtype=np.float64)
    pareto = np.zeros((Decomposition_number + 1, 2), dtype=np.float64)
    data =pd.read_csv("result_data\\Data_init_d3qn\\data_best.csv",header=None)# 替换成本地初始解获得后储存的地址位置即可
    bselect_gongxvlist = toolset.str_to_int(data.iloc[2, 0])
    bselect_Machinelist = toolset.str_to_int(data.iloc[3, 0])
    bselect_productlist = toolset.str_to_int(data.iloc[4, 0])
    b_productlist =  np.array(toolset.str_to_int(data.iloc[6, 0]))
    Initial_product_list = [bselect_gongxvlist, bselect_Machinelist, bselect_productlist, b_productlist]

    #########获得动态解（多目标优化）#############
    Weight[:,0] = np.arange(Decomposition_number,-1,-1)/Decomposition_number
    Weight[:, 1] = np.arange(Decomposition_number+1) / Decomposition_number
    Weight[Decomposition_number, 0]=1e-6
    Weight[0, 1] = 1e-6

    FLAG =  "Dynamic"
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    ######### D3QN #############
    #储存地址
    alg_path = 'NT_d3qn'
    if not os.path.exists(alg_path):
        os.makedirs(alg_path)

    Network_path = os.path.join(alg_path, 'Network_save')
    if not os.path.exists(Network_path):
        os.makedirs(Network_path)
    save_path = os.path.join(alg_path, 'result_data')
    if not os.path.exists(save_path):
        os.makedirs(save_path)
    Gannt_path = os.path.join(alg_path, 'Gannt_save')
    if not os.path.exists(Gannt_path):
        os.makedirs(Gannt_path)

    torch.cuda.synchronize()
    time_start_mo = time.time()
    for sub in range(Decomposition_number+1):
        print("(NT_D3QN)Current w:%2.4f/%2.4f" % (Weight[sub, 0], Weight[sub, 1]))
        GUID = f"w_{Weight[sub,0]:.3f}_{Weight[sub,1]:.3f}"
        torch.cuda.synchronize()
        time_start_sub = time.time()
        # if sub ==0:
        if sub >= 0:
            dqn = D3QN(NUM_STATES, NUM_ACTIONS, LR, MEMORY_CAPACITY, BATCH_SIZE, EPSILON, Q_NETWORK_ITERATION, GAMMA)
            reward_list, makespan_list, SCR_list, best_makespan, best_SCR, best_actionlist, bselect_gongxvlist, bselect_Machinelist, bselect_productlist, b_productlist, fixed_number_time = mt.model_training(episodes, dqn, EXCEL, FLAG, Weight[sub,:], Initial_product_list, Network_path, GUID)

            print(f"显存峰值：{torch.cuda.max_memory_allocated() / 1024 ** 2:.2f} MB")
            print("\n当前进程内存使用情况:")
            get_process_memory_usage()

            pareto[sub,0] = best_makespan
            pareto[sub, 1] = best_SCR
            print("子问题",sub,"best_makespan", best_makespan, "best_SCR", best_SCR)
        else:
            GUID_per = f"w_{Weight[sub-1, 0]:.3f}_{Weight[sub-1, 1]:.3f}"
            dqn = D3QN(NUM_STATES, NUM_ACTIONS, LR, MEMORY_CAPACITY, BATCH_SIZE, EPSILON, Q_NETWORK_ITERATION, GAMMA)
            dqn.eval_net = toolset.load_model(dqn.eval_net, f"{Network_path}//{GUID_per}//QN.pt", device)
            dqn.target_net = toolset.load_model(dqn.target_net, f"{Network_path}//{GUID_per}//QN.pt", device)
            reward_list, makespan_list, SCR_list, best_makespan, best_SCR, best_actionlist, bselect_gongxvlist, bselect_Machinelist, bselect_productlist, b_productlist, fixed_number_time = mt.model_training(episodes, dqn, EXCEL, FLAG, Weight[sub,:], Initial_product_list, Network_path, GUID)

            print(f"显存峰值：{torch.cuda.max_memory_allocated() / 1024 ** 2:.2f} MB")
            print("\n当前进程内存使用情况:")
            get_process_memory_usage()

            pareto[sub,0] = best_makespan
            pareto[sub, 1] = best_SCR
            print("子问题",sub,"best_makespan", best_makespan, "best_SCR", best_SCR)
        torch.cuda.synchronize()
        time_end = time.time()
        time_sum = time_end - time_start_sub
        toolset.draw_gantt(bselect_gongxvlist, bselect_Machinelist, bselect_productlist, b_productlist, best_makespan,best_SCR,fixed_number_time, EXCEL, FLAG, GUID, Gannt_path)
        toolset.fig_data_save(reward_list, makespan_list, SCR_list, dqn, FLAG, save_path, GUID, best_makespan,
                              best_SCR, bselect_gongxvlist,bselect_Machinelist, bselect_productlist, b_productlist, best_actionlist, time_sum,episodes)
    torch.cuda.synchronize()
    time_end = time.time()
    time_sum = time_end - time_start_mo
    print( "多目标总耗时:", time_sum)

    # 保存pareto数据
    data_pareto = pd.DataFrame(pareto)
    with pd.ExcelWriter(f"{alg_path}//pareto.xlsx", engine='openpyxl') as writer:
        data_pareto.to_excel(writer, sheet_name='Sheet1')

    #画pareto图
    plt.scatter(pareto[:, 0], pareto[:, 1])
    font1 = {'weight': 'bold', 'size': 18, 'family': 'KaiTi'}
    plt.xlabel("完工时间(Makespan)", font1)
    plt.title("Pareto前沿面图", font1)
    plt.ylabel("变更指数(SCR)", font1)
    plt.savefig(f"{alg_path}//NT-D3QN前沿面图.png", dpi=600, pad_inches=0.1, transparent=False)
    plt.show()



if __name__ == '__main__':
    main()
