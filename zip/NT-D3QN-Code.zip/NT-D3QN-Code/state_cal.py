#
# @Author      : Huang Ming
# @Create      : 2025/2/15 18:26
# @University  : Beijing Institute of Technology
# Copyright (C) 2026-05 Huang Ming, indie developer. All Rights Reserve
import numpy as np
import statistics

# 状态指标1：装配岛平均利用率
def Uave(PTM, product_list,Machinetime_list):
    #储存工序在那个装配岛上加工
    m = [[] for _ in range(PTM.shape[1])]
    for index, value in enumerate(product_list):  #np.argwhere(product_list!= -1)
        if value != -1:
            m[value].append(index)
    # 然后要根据装配岛加工工序计算占用时间
    time_machine = []
    for row_index, row in enumerate(m):
        t_temp = 0
        for element in row:
            t_temp += PTM[element][row_index]
        time_machine.append(t_temp)
    # 初始化Uk，用于计算每个装配岛的利用率
    uk = []
    for i in range(len(time_machine)):
        if Machinetime_list[i] != 0 :
            uk_temp = time_machine[i] / Machinetime_list[i]
        else:
            uk_temp = 0
        uk.append(uk_temp)  # 将计算结果加入uk列表
    uave = sum(uk) / len(uk)
    return uave

# 状态指标2：装配岛平均利用率标准差
def Ustd(PTM, product_list,Machinetime_list):
    #储存工序在那个装配岛上加工
    m = [[] for _ in range(PTM.shape[1])]
    for index, value in enumerate(product_list):  #np.argwhere(product_list!= -1)
        if value != -1:
            m[value].append(index)
    # 然后要根据装配岛加工工序计算占用时间
    time_machine = []
    for row_index, row in enumerate(m):
        t_temp = 0
        for element in row:
            t_temp += PTM[element][row_index]
        time_machine.append(t_temp)
    # 初始化Uk，用于计算每个装配岛的利用率
    uk = []
    for i in range(len(time_machine)):
        if Machinetime_list[i] != 0 :
            uk_temp = time_machine[i] / Machinetime_list[i]
        else:
            uk_temp = 0
        uk.append(uk_temp)  # 将计算结果加入uk列表
    # 计算标准差
    std_dev = statistics.pstdev(uk)  #pstdev 总体标准差（分母n）  stdev 样本标准差（分母n-1）
    return std_dev

# 状态指标3：工艺的作业平均完成率
def CROave(product_list,gongxv_list,gongxvs):
    # 先记录每个工件在t时刻已经完成的工序
    op_list=[]
    append_temp = 0
    for i in range(gongxvs):
        op_list.append(sum(1 for x in product_list[append_temp:gongxv_list[i]+append_temp] if x != -1))  #按size统计个数
        append_temp =append_temp + gongxv_list[i]
    croave = sum(op_list) / sum(gongxv_list)
    return croave

# 状态指标4：产品的作业平均完成率
def CRJave(product_list,gongxv_list,gongxvs):
    # 先记录每个工件在t时刻已经完成的工序
    op_list=[]
    append_temp = 0
    for i in range(gongxvs):
        op_list.append(sum(1 for x in product_list[append_temp:gongxv_list[i]+append_temp] if x != -1))
        append_temp =append_temp + gongxv_list[i]
    # 计算每个工件的完成率
    crj_list = [a / b for a, b in zip(op_list, gongxv_list)]  #迭代器zip利用
    # 计算平均值
    crjave = sum(crj_list) / len(crj_list)
    return crjave

# 状态指标5：产品的作业平均完成率标准差
def CRJstd(product_list,gongxv_list,gongxvs):
    # 先记录每个工件在t时刻已经完成的工序
    op_list=[]
    append_temp = 0
    for i in range(gongxvs):
        op_list.append(sum(1 for x in product_list[append_temp:gongxv_list[i]+append_temp] if x != -1))
        append_temp =append_temp + gongxv_list[i]
    # 计算每个工件的完成率
    crj_list = [a / b for a, b in zip(op_list, gongxv_list)]
    # 计算标准差
    crjstd = statistics.pstdev(crj_list)
    return crjstd

# 状态指标6：运输时间占比率的平均值
def Tave(TTM,select_gongxvlist,select_Machinelist,gongxv_list,gongxvs,product_timelist):

    position_temp = np.ones(shape = gongxvs, dtype=int) * -1
    #首先用一个list储存每个工序对应的工件
    workpiece_list = []
    for i in range(len(select_gongxvlist)):
        append_temp = 0
        for j in range (gongxvs):
            append_temp = append_temp + gongxv_list[j]
            if select_gongxvlist[i] < append_temp:
                workpiece_list.append(j)
                break
    #储存各产品的总运输时间
    transport_time = np.zeros(shape = gongxvs, dtype=int)
    for i in range(len(select_gongxvlist)):
        if position_temp[workpiece_list[i]] != -1:
            transport_time[workpiece_list[i]] = transport_time[workpiece_list[i]] + TTM[position_temp[workpiece_list[i]],select_Machinelist[i]]
            #目前的运输时间为一次，完成不考虑产品数量造成的影响。也没有岛只能储存一件产品岛与岛之间转运如果节拍不一致会产生堵塞问题。  限制岛外排队产品数量，产品按单件在甘特图上排列计算时间是一个改进点，加工完成后由AGV运送半成品岛缓冲池，
            position_temp[workpiece_list[i]] = select_Machinelist[i]
        else:
            position_temp[workpiece_list[i]] = select_Machinelist[i]
    #运输时间占比列表
    rate_list = []
    for i in range(gongxvs):
        if product_timelist[i] != 0:
            transport_rate = transport_time[i] / product_timelist[i]
        else:
            transport_rate = 0
        rate_list.append(transport_rate)
    tave = sum(rate_list) / len(rate_list)
    return tave

# 状态指标7：运输时间占比率的平均值标准差
def Tstd(TTM, select_gongxvlist, select_Machinelist, gongxv_list, gongxvs, product_timelist):
    position_temp = np.ones(shape=gongxvs, dtype=int) * -1
    # 首先用一个list储存每个工序对应的工件
    workpiece_list = []
    for i in range(len(select_gongxvlist)):
        append_temp = 0
        for j in range(gongxvs):
            append_temp = append_temp + gongxv_list[j]
            if select_gongxvlist[i] < append_temp:
                workpiece_list.append(j)
                break
    # 储存各产品的总运输时间
    transport_time = np.zeros(shape=gongxvs, dtype=int)
    for i in range(len(select_gongxvlist)):
        if position_temp[workpiece_list[i]] != -1:
            transport_time[workpiece_list[i]] = transport_time[workpiece_list[i]] + TTM[
                position_temp[workpiece_list[i]], select_Machinelist[i]]
            # 目前的运输时间为一次，完成不考虑产品数量造成的影响。也没有岛只能储存一件产品岛与岛之间转运如果节拍不一致会产生堵塞问题。  限制岛外排队产品数量，产品按单件在甘特图上排列计算时间是一个改进点，加工完成后由AGV运送半成品岛缓冲池，
            position_temp[workpiece_list[i]] = select_Machinelist[i]
        else:
            position_temp[workpiece_list[i]] = select_Machinelist[i]
    # 运输时间占比列表
    rate_list = []
    for i in range(gongxvs):
        if product_timelist[i] != 0:
            transport_rate = transport_time[i] / product_timelist[i]
        else:
            transport_rate = 0
        rate_list.append(transport_rate)
    tave = sum(rate_list) / len(rate_list)
    tstd = statistics.pstdev(rate_list)
    return tstd

def state_cal(PRODUCT_info, PTM, TTM, product_list, product_timelist, machinetime_list, select_gongxvlist, select_Machinelist):

    Time_last = machinetime_list.max()
    timedone_rows = PRODUCT_info[PRODUCT_info[:, 3] <= Time_last]
    gongxv_list = timedone_rows[:, 2]
    gongxvs = gongxv_list.size


    STATE = []
    STATE.append(Uave(PTM, product_list,machinetime_list))
    STATE.append(Ustd(PTM, product_list,machinetime_list))
    STATE.append(CROave(product_list, gongxv_list, gongxvs))
    STATE.append(CRJave(product_list, gongxv_list, gongxvs))
    STATE.append(CRJstd(product_list, gongxv_list, gongxvs))
    STATE.append(Tave(TTM,select_gongxvlist,select_Machinelist,gongxv_list,gongxvs,product_timelist))
    STATE.append(Tstd(TTM, select_gongxvlist, select_Machinelist, gongxv_list, gongxvs, product_timelist))
    return STATE
