#
# @Author      : Huang Ming
# @Create      : 2025/2/15 18:26
# @University  : Beijing Institute of Technology
# Copyright (C) 2026-05 Huang Ming, indie developer. All Rights Reserve
import numpy as np
import read_data as read
import matplotlib.pyplot as plt
import matplotlib
from matplotlib.pylab import mpl
import torch
import pandas as pd
import os
mpl.rcParams['font.sans-serif'] = ['SimHei']  # 添加这条可以让图形显示中文
matplotlib.rcParams['axes.unicode_minus'] = False

##案例数据读取
def data_fetch(EXCEL,FLAG):
    """
    包括产品信息、运输矩阵信息、加工时间信息、前置工序信息。

    """
    #存储每种产品数量和工序量
    PRODUCT_info=read.read_product(EXCEL)
    #运输矩阵信息、加工时间信息、前置工序信息。
    TTM = read.read_transportation(EXCEL)
    PTM = read.read_Processing(EXCEL)
    PPM = read.read_process_pre(EXCEL)

    if FLAG == 'Initial':
        PRODUCT_info = PRODUCT_info[PRODUCT_info[:, 3] == 0]
        PTM = PTM[0:np.sum(PRODUCT_info[:, 2]),:]
        PPM = PPM[0:np.sum(PRODUCT_info[:, 2]), 0:np.sum(PRODUCT_info[:, 2])]
    #product_list为一个长度为工序总数量的一维数组，对应的数值为工序选择的机床，为-1说明还未选择
    product_list = np.ones(shape = PTM.shape[0], dtype=int) * -1

    #position_list 产品当前所在的岛序号 -1说明还未进入加工  产品到第一个岛的运输时间默认为0
    position_list = np.ones(shape = PRODUCT_info.shape[0], dtype=int) * -1

    # product_timelist 产品当前的最早加工时间
    product_timelist = np.zeros(shape = PRODUCT_info.shape[0], dtype=float)
    # Machinetime_list  当前岛的最早可用加工时间
    machinetime_list = np.zeros(shape = PTM.shape[1], dtype=float)  #机床加工的结束时间

    #reward  R_normalized=R−Rmin / Rmax−Rmin
    '''
    工程上的优化，防止出现有的reward的值太高了，如果不做归一化，方差太大，导致梯度异常，主要是保证梯度更新的比较平稳。
     PPO 中的reward scaling和reward normalization的性能优劣呢
    统一范围： 将奖惩信号映射到固定范围内，确保在算法中使用的奖惩信号具有相似的数值范围。
    提高训练稳定性： 归一化可以提高强化学习算法的稳定性，避免奖惩信号过大或过小导致算法难以收敛。
    提高泛化能力： 归一化可以帮助模型更好地泛化到未见过的数据，因为模型学习到的数值范围更广，更适应不同情境。
    简化调参： 在训练中，如果奖惩信号的范围已经归一化，那么学习率等超参数的选择相对更容易。
    不对Loss做归一化的话，如果激活函数用ReLU很容易死，到时候跑出来一堆的NaN，所以应该是梯度的问题。就算用LeakyReLU也一样死。如果你这时候调低学习率，又很容易训练效果不好，训练前和训练后的Loss又没什么很大区别。
    '''
    max_PTM = np.ones_like(PTM)*-1
    for i in range(PTM.shape[0]):
        append_temp = 0
        for j in range (PRODUCT_info.shape[0]):
            append_temp = append_temp + PRODUCT_info[j, 2]
            if i < append_temp:
                workpiece = j
                break
        max_PTM[i,:] =PRODUCT_info[workpiece,1]*PTM[i,:]
    #最大增加跨度=max(max(插入时间，最大运输时间)+最大工序加工时间*相应的数量)
    min_reward=-(max(max(PRODUCT_info[:, 3]),np.amax(TTM))+np.amax(max_PTM))
    return PRODUCT_info,TTM,PTM,PPM,product_list,position_list,product_timelist,machinetime_list,min_reward

##保存nn模型
def save_model(neural_network, path):
    # neural_network 保存的网络
    # path 保存路径
    #state_dict()只保存网络参数  不保存优化器参数、神经网络架构、及训练episode数
    torch.save(neural_network.state_dict(), path)

##加载nn模型
def load_model(neural_network_f, path,device):
    # neural_network 新建网络 要与需要加载的网络一致才行
    # path 加载路径
    # device 部署在gpu or cpu
    nn_load=torch.load(path, weights_only=True,map_location=device)
    neural_network_f.load_state_dict(nn_load)
    return neural_network_f


# 将读取数据为str类型转化为list
def str_to_int(str):
    s=str.strip('[')
    s=s.strip(']')
    s=s.strip(',')
    if s.find(',') != -1:
       s = s.split(',')
    else:
        s = s.replace("\n", "")    #替换所有换行
        s = s.split(' ')           #按空格分割
        s= list(filter(None, s))  #去掉所有空元素‘’
    list_s=list(map(int,s))
    return list_s


## 绘制奖励图、目标1、2的图、loss图
def fig_data_save(reward_list,makespan_list,SCR_list,dqn,FLAG,save_path,GUID,best_makespan, best_SCR, bselect_gongxvlist, bselect_Machinelist, bselect_productlist, b_productlist, best_actionlist, time_sum, episodes):
    fig_path = os.path.join(save_path, f"Fig_{GUID}")
    if not os.path.exists(fig_path):
         os.makedirs(fig_path)

    # 绘制奖励图表
    plt.plot(range(len(reward_list)), reward_list, alpha=0.5, color='#e75840')
    df = pd.DataFrame(reward_list)
    reward_smooth = list(np.hstack(df.rolling(15, min_periods=1).mean().values))  #rolling_intv=5
    plt.plot(range(len(reward_list)), reward_smooth, label='reward_smooth', color='#e75840')
    reward_best=[]
    for i in range(len(reward_list)):
        reward_best.append(max(reward_list[:i+1]))
    plt.plot(range(len(reward_list)), reward_best, label='reward_best', color='#3A0964')
    # 添加标题和标签
    plt.title('Reward Training')
    plt.xlabel('Episodes')
    plt.ylabel('Reward')
    # 显示图表
    plt.legend()
    plt.grid(True)  # 可选：添加网格线
    out_picture = f"{fig_path}\\Reward Training.png"
    plt.savefig(out_picture, dpi=600, pad_inches=0.1, transparent=False)
    plt.show()

    # 绘制目标1图表
    plt.plot(range(len(makespan_list)),  makespan_list,label='Makespan',alpha=0.5, color='#7A1B6D')
    df = pd.DataFrame(makespan_list)
    makespan_smooth = list(np.hstack(df.rolling(10, min_periods=1).mean().values))  # rolling_intv=5
    plt.plot(range(len(makespan_list)), makespan_smooth, label='Makespan_smooth', color='#7A1B6D')
    makespan_best = []
    for i in range(len(makespan_list)):
        makespan_best.append(min(makespan_list[:i + 1]))
    plt.plot(range(len(makespan_list)), makespan_best, label='Makespan_best', color='#000000')
    # 添加标题和标签
    plt.title('Makespan Training')
    plt.xlabel('Episodes')
    plt.ylabel('makespan')
    # 显示图表
    plt.legend()
    plt.grid(True)  # 可选：添加网格线
    out_picture = f"{fig_path}\\Makespan Training.png"
    plt.savefig(out_picture, dpi=600, pad_inches=0.1, transparent=False)
    plt.show()

    if FLAG == "Dynamic":
        # 绘制目标2图表
        plt.plot(range(len(SCR_list)),  SCR_list,label='SCR', alpha=0.5, color='#7A1B6D')
        df = pd.DataFrame(SCR_list)
        SCR_smooth = list(np.hstack(df.rolling(10, min_periods=1).mean().values))  # rolling_intv=5
        plt.plot(range(len(SCR_list)), SCR_smooth, label='SCR_smooth', color='#7A1B6D')
        SCR_best = []
        for i in range(len(SCR_list)):
            SCR_best.append(min(SCR_list[:i + 1]))
        plt.plot(range(len(SCR_list)), SCR_best, label='SCR_best', color='#000000')
        # 添加标题和标签
        plt.title('SCR Training')
        plt.xlabel('Episodes')
        plt.ylabel('SCR')
        # 显示图表
        plt.legend()
        plt.grid(True)  # 可选：添加网格线
        out_picture = f"{fig_path}\\SCR Training_{GUID}.png"
        plt.savefig(out_picture, dpi=600, pad_inches=0.1, transparent=False)
        plt.show()


    # 绘制loss图表
    plt.plot(range(len(dqn.loss)), dqn.loss,alpha=0.5, label='loss_origin', color='#628cee')
    df = pd.DataFrame(dqn.loss)
    loss_smooth = list(np.hstack(df.rolling(5, min_periods=1).mean().values))  #rolling_intv=5
    plt.plot(range(len(dqn.loss)), loss_smooth, label='loss_smooth', color='#628cee')
    # 添加标题和标签
    plt.title('NN-LOSS')
    plt.xlabel('Index')
    plt.ylabel('loss')
    # 显示图表
    plt.legend()
    plt.grid(True)  # 可选：添加网格线
    out_picture = f"{fig_path}\\NN-LOSS.png"
    plt.savefig(out_picture, dpi=600, pad_inches=0.1, transparent=False)
    plt.show()

    #数据保存

    data_path = os.path.join(save_path, f"Data_{GUID}")
    if not os.path.exists(data_path):
         os.makedirs(data_path)

    if FLAG == "Dynamic":
        data_best = pd.DataFrame(
            [best_makespan, best_SCR, bselect_gongxvlist, bselect_Machinelist, bselect_productlist, best_actionlist, b_productlist],
            index=["best_makespan", "best_SCR", "bselect_gongxvlist", "bselect_Machinelist", "bselect_productlist",
                   "best_actionlist", "b_productlist"])
        data_SCR = pd.DataFrame([SCR_list, SCR_smooth, SCR_best],
                                index=["SCR_list", "SCR_smooth", "SCR_best"])
    else:
        data_best = pd.DataFrame(
            [best_makespan, bselect_gongxvlist, bselect_Machinelist, bselect_productlist, best_actionlist, b_productlist],
            index=["best_makespan", "bselect_gongxvlist", "bselect_Machinelist", "bselect_productlist",
                   "best_actionlist", "b_productlist"])  # 将list格式转换为DataFrame
        data_SCR = pd.DataFrame([])
    data_makespan = pd.DataFrame([makespan_list, makespan_smooth, makespan_best],
                                 index=["makespan_list", "makespan_smooth", "makespan_best"])
    data_reward = pd.DataFrame([reward_list, reward_smooth, reward_best],
                               index=["reward_list", "reward_smooth", "reward_best"])
    data_loss = pd.DataFrame([dqn.loss, loss_smooth, [min(dqn.loss)]],
                             index=["loss_origin", "loss_smooth", "loss_best"])
    data_time = pd.DataFrame([time_sum, episodes, dqn.MEMORY_CAPACITY, dqn.BATCH_SIZE, dqn.LR, dqn.Q_NETWORK_ITERATION,dqn.GAMMA],
                             index=["time", "episodes", "MEMORY_CAPACITY", "BATCH_SIZE", "LR", "Q_NETWORK_ITERATION", "GAMMA"])
    # 使用ExcelWriter保存DataFrame到Excel文件
    with pd.ExcelWriter(f"{data_path}\\result.xlsx", engine='openpyxl') as writer:
        data_best.to_excel(writer, sheet_name='Sheet1')
        data_makespan.to_excel(writer, sheet_name='Sheet2')
        data_SCR.to_excel(writer, sheet_name='Sheet3')
        data_reward.to_excel(writer, sheet_name='Sheet4')
        data_loss.to_excel(writer, sheet_name='Sheet5')
        data_time.to_excel(writer, sheet_name='Sheet6')
    # 将DataFrame写入CSV文件
    data_best.to_csv(f"{data_path}\\data_best.csv", index=False)
    data_makespan.to_csv(f"{data_path}\\data_makespan.csv", index=False)
    data_SCR.to_csv(f"{data_path}\\data_SCR.csv", index=False)
    data_reward.to_csv(f"{data_path}\\data_reward.csv", index=False)
    data_loss.to_csv(f"{data_path}\\data_loss.csv", index=False)
    data_time.to_csv(f"{data_path}\\data_time.csv", index=False)

# 画Gantt图

def axis(machine_num):
    index = ['M1', 'M2', 'M3', 'M4', 'M5', 'M6', 'M7', 'M8', 'M9', 'M10', 'M11', 'M12',
             'M13', 'M14', 'M15', 'M16', 'M17', 'M18', 'M19', 'M20', 'M21', 'M22']
    scale_ls, index_ls = [], []
    for i in range(machine_num):
        scale_ls.append(i + 1)
        index_ls.append(index[i])
    return index_ls, scale_ls  # 返回坐标轴信息，按照工件数返回，最多画20个机器，需要在后面添加

def draw_gantt(bselect_gongxvlist, bselect_Machinelist, bselect_productlist, b_productlist,best_makespan,best_SCR, fixed_number_time, EXCEL, FLAG,GUID,Gannt_path):  # 画甘特图
    #obtain data
    PRODUCT_info, TTM, PTM, PPM, product_list, position_list, product_timelist, machinetime_list, min_reward = data_fetch(EXCEL, FLAG)
    bselect_orggongxvlist=[]
    list_Start, list_Uses, list_Trans = [], [], []
    if FLAG == "Initial":
        for i in range(len(bselect_gongxvlist)): # 画产品特征加工模块，各类产品用一种颜色标识
            workpiece = bselect_productlist[i]
            machine = bselect_Machinelist[i]
            gongxv = bselect_gongxvlist[i]
            bselect_orggongxvlist.append(bselect_gongxvlist[i]-np.sum(PRODUCT_info[:bselect_productlist[i],2]))

            if position_list[bselect_productlist[i]] != -1:

                pro_starttime = product_timelist[workpiece]
                mac_starttime = machinetime_list[machine]
                usestime = PTM[gongxv, machine] * PRODUCT_info[workpiece, 1]
                transtime = TTM[position_list[workpiece], machine]
                list_Uses.append(usestime)
                position_list[workpiece] = machine
                # 如果max（产完,插入时间）>机完
                if max(PRODUCT_info[workpiece,3], product_timelist[workpiece]) >= machinetime_list[machine]:
                    # C_max=max（产完,插入时间）+运输+持续时间
                    list_Start.append(max(PRODUCT_info[workpiece][3],pro_starttime)+ transtime)
                    product_timelist[workpiece] = max(PRODUCT_info[workpiece][3],pro_starttime)+ transtime + usestime
                    machinetime_list[machine] = max(PRODUCT_info[workpiece][3],pro_starttime) + transtime + usestime

                else:
                    # C_max=max（产完+运输时间，机完）+持续时间
                    list_Start.append(max(pro_starttime + transtime,mac_starttime))
                    position_list[workpiece] = machine
                    product_timelist[workpiece] = max(pro_starttime + transtime,mac_starttime) + usestime
                    machinetime_list[machine] = max(pro_starttime + transtime,mac_starttime) + usestime
                if transtime!=0:
                    list_Trans.append([workpiece,machine,list_Start[-1]-transtime,transtime])

            else:
                # C_max=max（机完，产完，插入时间）+持续时间
                starttime = max([machinetime_list[machine], product_timelist[workpiece], PRODUCT_info[workpiece, 3]])
                usestime = PTM[gongxv, machine] * PRODUCT_info[workpiece, 1]
                list_Start.append(starttime)
                list_Uses.append(usestime)
                position_list[workpiece] = machine
                product_timelist[workpiece] = starttime + usestime
                machinetime_list[machine] = starttime + usestime
    else:
        for i in range(len(bselect_gongxvlist)):  # 画产品特征加工模块，各类产品用一种颜色标识
            workpiece = bselect_productlist[i]
            machine = bselect_Machinelist[i]
            gongxv = bselect_gongxvlist[i]
            bselect_orggongxvlist.append(bselect_gongxvlist[i] - np.sum(PRODUCT_info[:bselect_productlist[i], 2]))

            if position_list[bselect_productlist[i]] != -1:

                pro_starttime = product_timelist[workpiece]
                mac_starttime = machinetime_list[machine]
                usestime = PTM[gongxv, machine] * PRODUCT_info[workpiece, 1]
                transtime = TTM[position_list[workpiece], machine]
                list_Uses.append(usestime)
                position_list[workpiece] = machine
                # 如果max（产完,插入时间）>机完
                if max(PRODUCT_info[workpiece, 3], product_timelist[workpiece]) >= machinetime_list[machine]:
                    # C_max=max（产完,插入时间）+运输+持续时间
                    list_Start.append(max(PRODUCT_info[workpiece][3], pro_starttime) + transtime)
                    product_timelist[workpiece] = max(PRODUCT_info[workpiece][3], pro_starttime) + transtime + usestime
                    machinetime_list[machine] = max(PRODUCT_info[workpiece][3], pro_starttime) + transtime + usestime

                else:
                    # C_max=max（产完+运输时间，机完）+持续时间
                    list_Start.append(max(pro_starttime + transtime, mac_starttime))
                    position_list[workpiece] = machine
                    product_timelist[workpiece] = max(pro_starttime + transtime, mac_starttime) + usestime
                    machinetime_list[machine] = max(pro_starttime + transtime, mac_starttime) + usestime
                if transtime != 0:
                    list_Trans.append([workpiece, machine, list_Start[-1] - transtime, transtime])
            else:
                # C_max=max（机完，产完，插入时间）+持续时间
                starttime = max([machinetime_list[machine], product_timelist[workpiece], PRODUCT_info[workpiece, 3]])
                usestime = PTM[gongxv, machine] * PRODUCT_info[workpiece, 1]
                list_Start.append(starttime)
                list_Uses.append(usestime)
                position_list[workpiece] = machine
                product_timelist[workpiece] = starttime + usestime
                machinetime_list[machine] = starttime + usestime
            if i == fixed_number_time[0][0]-1: #可注释用处不大
                product_timelist = np.where((product_timelist > 0) & (product_timelist < fixed_number_time[0][1]), fixed_number_time[0][1],
                                    product_timelist)
                machinetime_list = np.where((machinetime_list > 0) & (machinetime_list < fixed_number_time[0][1]), fixed_number_time[0][1],
                                    machinetime_list)
    #draw
    colorlist = ['#4B65AF', '#F46F44', '#7FCBA4', '#E9F5A1', '#a4649b', '#6cbdd0', '#4d8ea1', '#cdccbd', '#bde3e3', '#4e6e7e', '#fcbca6', '#fbca5f']  # 配色列表
    figure, ax = plt.subplots()
    for i in range(len(list_Trans)):  # 画运输模块，深红色标识
        if i != len(list_Trans) - 1:
            plt.bar(x=list_Trans[i][2], bottom=list_Trans[i][1]+1, height=0.7, width=list_Trans[i][3],
                    orientation="horizontal", alpha=.8, hatch='////', color='#b9b9b9', edgecolor='black')
        else:
            plt.bar(x=list_Trans[i][2], bottom=list_Trans[i][1]+1, height=0.7, width=list_Trans[i][3],
                    orientation="horizontal", alpha=.9, hatch='////', color='#b9b9b9', edgecolor='black',
                    label='AGV物流搬运')

    for i in range(len(bselect_gongxvlist)):  # 画产品特征加工模块，各类产品用一种颜色标识
        plt.bar(x=list_Start[i], bottom=bselect_Machinelist[i]+1, height=0.5, width=list_Uses[i], orientation="horizontal",
                color=colorlist[int(bselect_productlist[i])], edgecolor='black')
        plt.text(list_Start[i] + list_Uses[i] / list_Uses[i], bselect_Machinelist[i]+1 - 0.1,
                 '(%.0f,%.0f)' % (bselect_productlist[i]+1, bselect_orggongxvlist[i]+1), color='black', fontsize=8, weight='bold')
    if FLAG == "Initial":
        plt.plot([best_makespan, best_makespan], [0, PTM.shape[1]], c='black', linestyle='-.',label='Makespan:%.2f' % (best_makespan))  # 用虚线画出最晚完工时间
    else:
        plt.plot([best_makespan, best_makespan], [0, PTM.shape[1]], c='black', linestyle='-.',label='Makespan:%.0f\nSCR:%.2f' % (best_makespan,best_SCR))  # 用虚线画出最晚完工时间
    font1 = {'weight': 'bold', 'size': 10, 'family': 'KaiTi'}  # 汉字字体大小
    font2 = {'weight': 'bold', 'size': 12, 'family': 'KaiTi'}  # 汉字字体大小
    plt.xlabel("岛式装配时间/min", font1)
    plt.title("甘特图", font2)
    plt.ylabel("装配岛", font1)

    scale_ls, index_ls = axis(PTM.shape[1])
    plt.yticks(index_ls, scale_ls)
    plt.axis([0, best_makespan * 1.05, 0, PTM.shape[1] + 1])  # 设置x轴和y轴的范围
    plt.tick_params(labelsize=10)  # 坐标轴刻度字体大小
    labels = ax.get_xticklabels()
    [label.set_fontname('SimHei') for label in labels]
    plt.legend(prop={'family': ['SimHei'], 'size': 8})  # 标签字体大小
    plt.savefig(f"{Gannt_path}//gannt_{GUID}.png", dpi=600, pad_inches=0.1, transparent=False)
    plt.show()


def fixed_completed_tasks(EXCEL,FLAG,Initial_product_list):
    # 数据读取
    PRODUCT_info, TTM, PTM, PPM, product_list, position_list, product_timelist, machinetime_list, min_reward = data_fetch(EXCEL, FLAG)
    rescheduling_time = np.amax(PRODUCT_info[:, 3])
    # rescheduling_time = 200
    bselect_gongxvlist = Initial_product_list[0]
    bselect_Machinelist = Initial_product_list[1]
    bselect_productlist = Initial_product_list[2]

    ############# 获取当前gantt数据  ###############
    list_Start = []
    for i in range(len(bselect_gongxvlist)):
        workpiece = bselect_productlist[i]
        machine = bselect_Machinelist[i]
        gongxv = bselect_gongxvlist[i]
        product_list[gongxv] = machine
        if position_list[bselect_productlist[i]] != -1:
            pro_starttime = product_timelist[workpiece]
            mac_starttime = machinetime_list[machine]
            usestime = PTM[gongxv, machine] * PRODUCT_info[workpiece, 1]
            transtime = TTM[position_list[workpiece], machine]
            position_list[workpiece] = machine

            # 如果max（产完,插入时间）>机完
            if max(PRODUCT_info[workpiece, 3], product_timelist[workpiece]) >= machinetime_list[machine]:
                # C_max=max（产完,插入时间）+运输+持续时间
                list_Start.append(max(PRODUCT_info[workpiece][3], pro_starttime) + transtime)
                product_timelist[workpiece] = max(PRODUCT_info[workpiece][3],
                                                  pro_starttime) + transtime + usestime
                machinetime_list[machine] = max(PRODUCT_info[workpiece][3],
                                                pro_starttime) + transtime + usestime
            else:
                # C_max=max（产完+运输时间，机完）+持续时间
                list_Start.append(max(pro_starttime + transtime, mac_starttime))
                position_list[workpiece] = machine
                product_timelist[workpiece] = max(pro_starttime + transtime, mac_starttime) + usestime
                machinetime_list[machine] = max(pro_starttime + transtime, mac_starttime) + usestime

        else:
            # C_max=max（机完，产完，插入时间）+持续时间
            starttime = max(
                [machinetime_list[machine], product_timelist[workpiece], PRODUCT_info[workpiece, 3]])
            usestime = PTM[gongxv, machine] * PRODUCT_info[workpiece, 1]
            list_Start.append(starttime)
            position_list[workpiece] = machine
            product_timelist[workpiece] = starttime + usestime
            machinetime_list[machine] = starttime + usestime

    fixed_positions = [i for i, x in enumerate(list_Start) if x < rescheduling_time] #找到所有需要固定的工序
    select_gongxvlist = [bselect_gongxvlist[j] for j in fixed_positions]
    select_Machinelist = [bselect_Machinelist[j] for j in fixed_positions]
    select_productlist = [bselect_productlist[j] for j in fixed_positions]

    # 更新固定工序后的状态信息（包括 product_list, position_list, product_timelist, machinetime_list）
    PRODUCT_info, TTM, PTM, PPM, product_list, position_list, product_timelist, machinetime_list, min_reward = data_fetch(EXCEL, FLAG)
    fix_gongxvlist = select_gongxvlist
    fix_Machinelist = select_Machinelist
    fix_productlist = select_productlist

    ######### 获取固定的工序gantt数据#############
    list_Start_fix = []
    for i in range(len(fix_gongxvlist)):
        workpiece = fix_productlist[i]
        machine = fix_Machinelist[i]
        gongxv = fix_gongxvlist[i]
        product_list[gongxv] = machine
        if position_list[fix_productlist[i]] != -1:
            pro_starttime = product_timelist[workpiece]
            mac_starttime = machinetime_list[machine]
            usestime = PTM[gongxv, machine] * PRODUCT_info[workpiece, 1]
            transtime = TTM[position_list[workpiece], machine]
            position_list[workpiece] = machine

            # 如果max（产完,插入时间）>机完
            if max(PRODUCT_info[workpiece, 3], product_timelist[workpiece]) >= machinetime_list[machine]:
                # C_max=max（产完,插入时间）+运输+持续时间
                list_Start_fix.append(max(PRODUCT_info[workpiece][3], pro_starttime) + transtime)
                product_timelist[workpiece] = max(PRODUCT_info[workpiece][3],
                                                  pro_starttime) + transtime + usestime
                machinetime_list[machine] = max(PRODUCT_info[workpiece][3],
                                                pro_starttime) + transtime + usestime
            else:
                # C_max=max（产完+运输时间，机完）+持续时间
                list_Start_fix.append(max(pro_starttime + transtime, mac_starttime))
                position_list[workpiece] = machine
                product_timelist[workpiece] = max(pro_starttime + transtime, mac_starttime) + usestime
                machinetime_list[machine] = max(pro_starttime + transtime, mac_starttime) + usestime

        else:
            # C_max=max（机完，产完，插入时间）+持续时间
            starttime = max(
                [machinetime_list[machine], product_timelist[workpiece], PRODUCT_info[workpiece, 3]])
            usestime = PTM[gongxv, machine] * PRODUCT_info[workpiece, 1]
            list_Start_fix.append(starttime)
            position_list[workpiece] = machine
            product_timelist[workpiece] = starttime + usestime
            machinetime_list[machine] = starttime + usestime
    product_timelist=np.where((product_timelist>0)&(product_timelist<np.amax(PRODUCT_info[:, 3])),np.amax(PRODUCT_info[:, 3]),product_timelist)
    machinetime_list = np.where((machinetime_list > 0) & (machinetime_list < np.amax(PRODUCT_info[:, 3])), np.amax(PRODUCT_info[:, 3]),machinetime_list)

    fixed_number_time = []
    # fixed_number_time.append([len(select_gongxvlist),rescheduling_time])
    fixed_number_time.append([len(select_gongxvlist), np.amax(PRODUCT_info[:, 3])])
    return product_list, position_list, product_timelist, machinetime_list, select_gongxvlist, select_Machinelist, select_productlist,fixed_number_time