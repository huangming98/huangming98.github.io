#
# @Author      : Huang Ming
# @Create      : 2025/2/15 18:26
# @University  : Beijing Institute of Technology
# Copyright (C) 2026-05 Huang Ming, indie developer. All Rights Reserve
import numpy as np
import makes
import state_cal
import tqdm
import toolset
import os


def model_training(episodes, dqn, EXCEL, FLAG, Weight, Initial_product_list, Network_path, GUID):
    max_reward = -10e6
    reward_list = []
    makespan_list=[]
    SCR_list=[]
    best_makespan=-10e6
    best_SCR=-10e6
    fixed_number_time=[]
    # 迭代优化
    with tqdm.tqdm(total=int(episodes), desc='Epoch %d' % 1) as pbar:
        for i in range(episodes):
            #数据读取
            PRODUCT_info, TTM, PTM, PPM, product_list, position_list, product_timelist, machinetime_list,min_reward = toolset.data_fetch(EXCEL,FLAG)
            # 状态初始化、累计奖励初始化_reward = 0
            ep_reward=0
            action_list = []
            select_gongxvlist=[]
            select_Machinelist=[]
            select_productlist = []

            if FLAG == "Dynamic":
                product_list, position_list, product_timelist, machinetime_list, select_gongxvlist, select_Machinelist, select_productlist,fixed_number_time = toolset.fixed_completed_tasks(EXCEL,FLAG,Initial_product_list)

            while True:
                #计算状态
                state_D = state_cal.state_cal(PRODUCT_info, PTM, TTM, product_list, product_timelist, machinetime_list, select_gongxvlist, select_Machinelist)
                action = dqn.choose_action(state_D)
                action_list.append(action)

                # 选择动作
                select_gongxv, select_Machine=makes.action_done(action,PRODUCT_info,TTM,PTM,PPM,product_list,position_list,product_timelist,machinetime_list)
                select_gongxvlist.append(select_gongxv)
                select_Machinelist.append(select_Machine)

                #状态转移
                # 基于所选择的动作获取 奖励、新状态等
                product_list,position_list,product_timelist,machinetime_list,finish,reward,time_begin,C_max,select_product = makes.state_transition(select_gongxv,select_Machine,product_list,position_list,PTM,TTM,product_timelist,machinetime_list,PRODUCT_info,FLAG,Initial_product_list,Weight,min_reward)
                select_productlist.append(select_product)
                #新的状态
                next_state_D = state_cal.state_cal(PRODUCT_info, PTM, TTM, product_list, product_timelist, machinetime_list, select_gongxvlist, select_Machinelist)

                # 存储状态转移的经验值样本库
                dqn.store_transition(state_D, action, reward, next_state_D)
                # 记录状态转移对应获取的奖励
                ep_reward += reward

                # 在样本数量超过样本容量时更新智能体
                if dqn.memory_counter >= dqn.MEMORY_CAPACITY:
                    dqn.learn(finish)
                    if finish:
                       break
                if dqn.memory_counter < dqn.MEMORY_CAPACITY and finish:
                    # 数据读取
                    PRODUCT_info, TTM, PTM, PPM, product_list, position_list, product_timelist, machinetime_list, min_reward = toolset.data_fetch(
                        EXCEL, FLAG)
                    # 状态初始化、累计奖励初始化_reward = 0
                    ep_reward = 0
                    action_list = []
                    select_gongxvlist = []
                    select_Machinelist = []
                    select_productlist = []
                    if FLAG == "Dynamic":
                        product_list, position_list, product_timelist, machinetime_list, select_gongxvlist, select_Machinelist, select_productlist, fixed_number_time = toolset.fixed_completed_tasks(
                            EXCEL, FLAG, Initial_product_list)

            #生成一个episod后
            if FLAG == "Initial":
                # 记录目标函数数据
                makespan_list.append(np.amax(machinetime_list))
            else:
                # 记录目标函数1数据
                makespan_list.append(np.amax(machinetime_list))
                # 记录目标函数2数据
                change_number = 0
                for j in range(len(Initial_product_list[3])):
                    if Initial_product_list[3][j] != product_list[j]:
                        change_number = change_number + 1
                SCR_list.append(change_number / len(Initial_product_list[3]))
            # 记录奖励数据
            reward_list.append(ep_reward)

            # 累计奖励大于最大奖励时更新记录的最大累计奖励
            if ep_reward > max_reward:
                #bestActions = Actions
                best_actionlist = action_list
                max_reward = ep_reward
                best_makespan=np.amax(machinetime_list)
                if FLAG == "Dynamic":
                    best_SCR = SCR_list[-1:][0]
                bselect_gongxvlist = select_gongxvlist
                bselect_Machinelist = select_Machinelist
                bselect_productlist = select_productlist
                b_productlist = product_list
            # 在样本数量超过样本容量时更新智能体才进行探索率更新
            if dqn.memory_counter >= dqn.MEMORY_CAPACITY:
               dqn.EPSILON = max(0.05, dqn.EPSILON-0.0014)  # 下降速可调节
            # print(6)
            if (i + 1) % 10 == 0:
                pbar.set_postfix({
                    'episode':'%d' % (i+ 1),
                    'dqn.EPSILON': '%.5f' % (dqn.EPSILON),
                    'best_makespan':'%.3f' % (best_makespan),
                    'best_SCR': '%.3f' % (best_SCR),
                    'curr_action': '%s' % (str(action_list)[1:-1])
                })
            pbar.update(1)
    nn_path = os.path.join(Network_path, f"{GUID}")
    if not os.path.exists(nn_path):
         os.makedirs(nn_path)
    toolset.save_model(dqn.eval_net, f"{nn_path}//QN.pt")

    return reward_list, makespan_list, SCR_list, best_makespan,best_SCR,best_actionlist,bselect_gongxvlist,bselect_Machinelist,bselect_productlist,b_productlist,fixed_number_time
