#
# @Author      : Huang Ming
# @Create      : 2025/2/15 18:26
# @University  : Beijing Institute of Technology
# Copyright (C) 2026-05 Huang Ming, indie developer. All Rights Reserve
import numpy as np
import random


#获取加工时间，使用时先保证加工表能加工，前置表满足，
def C_max_calculation(PTM,TTM,position_list,product_timelist,Machinetime_list,gongxv,workpiece,machine,PRODUCT_info):
    # 判断是否是产品的第一道工艺，初始位置（默认运输时间为0）,如果不是的话需要计算运输时间
    if position_list[workpiece] != -1:
        #如果max（产完,插入时间）>机完
        if max(PRODUCT_info[workpiece][3],product_timelist[workpiece])>=Machinetime_list[machine] :
            #C_max=max（产完,插入时间）+运输+持续时间
            C_max = max(PRODUCT_info[workpiece][3],product_timelist[workpiece])+ TTM[position_list[workpiece],machine]+PTM[gongxv,machine]* PRODUCT_info[workpiece, 1]
        else:
            #C_max=max（产完+运输时间，机完）+持续时间
            C_max = max(product_timelist[workpiece]+TTM[position_list[workpiece],machine],Machinetime_list[machine])+PTM[gongxv,machine]* PRODUCT_info[workpiece, 1]
    else:
        # C_max=max（机完，产完，插入时间）+持续时间
        C_max =max([Machinetime_list[machine], product_timelist[workpiece], PRODUCT_info[workpiece, 3]])+PTM[gongxv,machine]* PRODUCT_info[workpiece, 1]
    return C_max


# 获取加工开始时间
def Min_begintime(product_timelist,Machinetime_list,gongxv,workpiece,machine,PRODUCT_info):
    begin_time =max([Machinetime_list[machine],product_timelist[workpiece],PRODUCT_info[workpiece][3]])
    return begin_time


# 调度规则1：针对当前状态下可进行加工的装配工序，选择可以最早开展加工任务的装配岛，加工对应装配工序。
def action1(PTM,PPM,TTM, position_list,Machinetime_list,product_timelist,able_gongxv,able_workpiece,ables,PRODUCT_info):
    info=np.empty((0,5),dtype=float)
    for i in range(ables):
        #首先找能进行该工序的机床
        for j in range(PTM.shape[1]):
            if PTM[able_gongxv[i],j] > 0:
                begin_time = max([Machinetime_list[j], product_timelist[able_workpiece[i]], PRODUCT_info[able_workpiece[i],3]])
                #储存：[产品序号，工艺序号，装配岛序号，最早加工开始时间，加工持续时间]
                info_add=np.array([able_workpiece[i],able_gongxv[i],j,begin_time,PTM[able_gongxv[i],j]*PRODUCT_info[able_workpiece[i],1]])
                info=np.vstack((info,info_add))
    # 如果存在多个min最早加工开始时间则选择最小加工持续时间的工件
    select_info_index = np.argwhere(info[:, 3] == np.amin(info[:, 3], axis=0))
    select_info=info[np.squeeze(select_info_index)].reshape(-1,5)
    if select_info.shape[0] != 1:
        second_index = np.argwhere(select_info[:, 4] == np.amin(select_info[:, 4], axis=0))
        select_info = select_info[np.squeeze(second_index)].reshape(-1,5)
    x=random.randint(0, select_info.shape[0]-1)
    select_gongxv = int(select_info[x, 1])
    select_Machine = int(select_info[x, 2])
    return select_gongxv, select_Machine

# 调度规则2：针对当前状态下可进行加工的装配工序，选择加工持续时间最短的装配工序在对应的装配岛上加工。
def action2(PTM,PPM,TTM,position_list,Machinetime_list,product_timelist,able_gongxv,able_workpiece,ables,PRODUCT_info):
    info = np.empty((0, 5), dtype=float)
    # 首先找能进行该工序的机床
    for i in range(ables):
        for j in range(PTM.shape[1]):



            
            if PTM[able_gongxv[i],j] != -1:
                begin_time = max([Machinetime_list[j], product_timelist[able_workpiece[i]], PRODUCT_info[able_workpiece[i], 3]])
                # 储存：[产品序号，工艺序号，装配岛序号，最早加工开始时间，加工持续时间]
                info_add = np.array([able_workpiece[i], able_gongxv[i], j, begin_time,
                                     PTM[able_gongxv[i], j] * PRODUCT_info[able_workpiece[i], 1]])
                info = np.vstack((info, info_add))
    # 如果存在多个最小加工持续时间则选择min最早加工开始时间的工件
    select_info_index = np.argwhere(info[:, 4] == np.amin(info[:, 4], axis=0))
    #np.squeeze 将（1；4）转（4；） np.squeeze 将（1；4）转（4；）  .reshape(1,-1) 转（4；）为（1；4）
    select_info=info[np.squeeze(select_info_index)].reshape(-1,5)
    if select_info.shape[0] != 1:
        second_index = np.argwhere(select_info[:, 3] == np.amin(select_info[:, 3], axis=0))
        select_info = select_info[np.squeeze(second_index)].reshape(-1,5)
    x = random.randint(0, select_info.shape[0] - 1)
    select_gongxv = int(select_info[x, 1])
    select_Machine = int(select_info[x, 2])

    return select_gongxv,select_Machine

# 调度规则3：针对当前状态下可进行加工的装配工序，选择加入工序后使得max( )最小的装配工序和装配岛。
def action3(PTM,PPM,TTM, position_list,machinetime_list,product_timelist,able_gongxv,able_workpiece,ables,PRODUCT_info):
    info = np.empty((0, 6), dtype=float)
    # 计算开始时的时间
    for i in range(ables):
        for j in range(PTM.shape[1]):
            if PTM[able_gongxv[i],j] > 0:
                Cmax_list = machinetime_list.copy()   #Cmax_list=machinetime_list # 浅层copy 造成机器完工时间赋值错误。
                begin_time = max([machinetime_list[j], product_timelist[able_workpiece[i]], PRODUCT_info[able_workpiece[i], 3]])
                # 计算该选择方案下，所选机床的最晚加工时间
                Cmax_list[j] = C_max_calculation(PTM,TTM,position_list,product_timelist,machinetime_list,able_gongxv[i],able_workpiece[i],j,PRODUCT_info)
                # 储存：[产品序号，工艺序号，装配岛序号，最早加工开始时间，加工持续时间，max(Cmax)]
                info_add = np.array([able_workpiece[i], able_gongxv[i], j, begin_time,
                                     PTM[able_gongxv[i], j] * PRODUCT_info[able_workpiece[i], 1],np.amax(Cmax_list)])
                info = np.vstack((info, info_add))
                # 最后判断该方案是否是让时间推动最少的，即加工完时间最早
    # 如果存在多个min的max(Cmax)则选择最小加工持续时间的工件
    select_info_index = np.argwhere(info[:, 5] == np.amin(info[:, 5], axis=0))
    # np.squeeze 将（1；4）转（4；） np.squeeze 将（1；4）转（4；）  .reshape(1,-1) 转（4；）为（1；4）
    select_info = info[np.squeeze(select_info_index)].reshape(-1, 6)
    if select_info.shape[0] != 1:
        second_index = np.argwhere(select_info[:, 4] == np.amin(select_info[:, 4], axis=0))
        select_info = select_info[np.squeeze(second_index)].reshape(-1, 6)
    x = random.randint(0, select_info.shape[0] - 1)
    select_gongxv = int(select_info[x, 1])
    select_Machine = int(select_info[x, 2])
    return select_gongxv, select_Machine

# 调度规则4：针对当前状态下可进行加工的装配工序，选择生产利用率最低的装配岛进行对应装配工序的加工。
def action4(PTM,PPM,TTM,position_list,Machinetime_list,product_timelist,able_gongxv,able_workpiece,ables,PRODUCT_info,product_list):
    #计算当前机床利用率
    third_column = PRODUCT_info[:, 2]
    total_gongxv = np.sum(third_column)
    usage_list = np.zeros(shape=PTM.shape[1], dtype=float)
    #用usage_list储存每个machine的工作时间
    # 获取所有可行工序的工件种类（对应4种工件的哪一种）
    workpiece_index = []
    for i in range(total_gongxv):
        compare = 0
        for j in range(third_column.shape[0]):
            compare = compare + third_column[j]
            if i < compare:
                workpiece_index.append(j)
                break

    for i in range(total_gongxv):
        if product_list[i] != -1:

            usage_list[product_list[i]] = usage_list[product_list[i]] + PTM[i, product_list[i]]* PRODUCT_info[workpiece_index[i], 1]

    for i in range(PTM.shape[1]):
        if Machinetime_list[i] != 0:
            usage_list[i] = usage_list[i] / Machinetime_list[i]
        else:
            #如果该岛没加工过，利用率为0
            usage_list[i] = 0


    ##形成可加工装配工艺集合
    info = np.empty((0, 6), dtype=float)
    # 首先找能进行该工序的机床
    for i in range(ables):
        for j in range(PTM.shape[1]):
            if PTM[able_gongxv[i], j] != -1:
                begin_time = max([Machinetime_list[j], product_timelist[able_workpiece[i]], PRODUCT_info[able_workpiece[i], 3]])
                # 储存：[产品序号，工艺序号，装配岛序号，岛生产利用率，最早加工开始时间，加工持续时间]
                info_add = np.array([able_workpiece[i], able_gongxv[i], j, usage_list[j], begin_time,
                                     PTM[able_gongxv[i], j] * PRODUCT_info[able_workpiece[i], 1]])
                info = np.vstack((info, info_add))
    # 如果存在多个min利用率的岛，则选择最小加工持续时间的工件
    select_info_index = np.argwhere(info[:, 3] == np.amin(info[:, 3], axis=0))
    # np.squeeze 将（1；4）转（4；） np.squeeze 将（1；4）转（4；）  .reshape(1,-1) 转（4；）为（1；4）
    select_info = info[np.squeeze(select_info_index)].reshape(-1, 6)
    if select_info.shape[0] != 1:
        second_index = np.argwhere(select_info[:, 5] == np.amin(select_info[:, 5], axis=0))
        select_info = select_info[np.squeeze(second_index)].reshape(-1, 6)
    x = random.randint(0, select_info.shape[0] - 1)
    select_gongxv = int(select_info[x, 1])
    select_Machine = int(select_info[x, 2])
    return select_gongxv, select_Machine

# 调度规则5：针对当前状态下可进行加工的装配工序，选择完成装配工艺数量最少的产品所对应的装配工艺，选择可以最早开展加工任务的装配岛进行加工。
def action5(PTM,PPM,TTM,position_list,Machinetime_list,product_timelist,able_gongxv,able_workpiece,ables,PRODUCT_info,product_list):


    third_column = PRODUCT_info[:, 2]
    total_gongxv = np.sum(third_column)
    gongxvs = third_column.size

    workpiece_donelist = np.zeros(shape = PRODUCT_info.shape[0], dtype=float)
    #统计工件完成的工序数
    for i in range(total_gongxv):
        compare = 0
        if product_list[i] != -1:
            for j in range(gongxvs):
                compare = compare + third_column[j]
                if i < compare:
                    workpiece_donelist[j] = workpiece_donelist[j] +1
                    break

    info = np.empty((0, 6), dtype=float)
    for i in range(ables):
        for j in range(PTM.shape[1]):
            if PTM[able_gongxv[i]][j] != -1:
                begin_time = max([Machinetime_list[j], product_timelist[able_workpiece[i]], PRODUCT_info[able_workpiece[i], 3]])
                # 储存：[产品序号，工艺序号，装配岛序号，产品完成装配工艺数量，最早加工开始时间，加工持续时间]
                info_add = np.array([able_workpiece[i], able_gongxv[i], j, workpiece_donelist[able_workpiece[i]], begin_time,
                                     PTM[able_gongxv[i], j] * PRODUCT_info[able_workpiece[i], 1]])
                info = np.vstack((info, info_add))
                # 如果存在多个成装配工艺数量最少的，则选择最小加工持续时间的工件
    select_info_index = np.argwhere(info[:, 3] == np.amin(info[:, 3], axis=0))
    # np.squeeze 将（1；4）转（4；） np.squeeze 将（1；4）转（4；）  .reshape(1,-1) 转（4；）为（1；4）
    select_info = info[np.squeeze(select_info_index)].reshape(-1, 6)
    if select_info.shape[0] != 1:
        second_index = np.argwhere(select_info[:, 4] == np.amin(select_info[:, 4], axis=0))
        select_info = select_info[np.squeeze(second_index)].reshape(-1, 6)
    x = random.randint(0, select_info.shape[0] - 1)
    select_gongxv = int(select_info[x, 1])
    select_Machine = int(select_info[x, 2])
    return select_gongxv, select_Machine

# 调度规则6：针对当前状态下可进行加工的产品，选择当前未加工时间最长的产品，将对应的装配工艺在可以最早开展加工任务的装配岛进行加工。
def action6(PTM,PPM,TTM,product_list,position_list,Machinetime_list,product_timelist,able_gongxv,able_workpiece,ables,PRODUCT_info):

    third_column = PRODUCT_info[:, 2]
    total_gongxv = np.sum(third_column)
    gongxvs = third_column.size

    # 用两个数组分别存储每个产品剩余的总加工时间（包括同道工序在不同机床上用平均时间）、和总加工次数
    remain_worklist = np.zeros(shape = PRODUCT_info.shape[0], dtype=float)
    for i in range(total_gongxv):
        repeat = 0
        total = 0
        compare = 0
        for k in range(PRODUCT_info.shape[0]):
            compare = compare + third_column[k]
            if i < compare:
                workpiece = k
                break
        for j in range(PTM.shape[1]):
            if PTM[i,j] != -1 and product_list[i] == -1:
                    total = total + PTM[i,j]*PRODUCT_info[workpiece,1]
                    repeat = repeat + 1
        # 不用写repeat=0的情况，因为可行工序必能有解

        if repeat != 0:
            remain_worklist[workpiece] = remain_worklist[workpiece] + total / repeat


    info = np.empty((0, 6), dtype=float)
    for i in range(ables):
        for j in range(PTM.shape[1]):
            if PTM[able_gongxv[i]][j] > 0 :
                begin_time = max([Machinetime_list[j], product_timelist[able_workpiece[i]], PRODUCT_info[able_workpiece[i], 3]])
                # 储存：[产品序号，工艺序号，装配岛序号，产品当前未加工时间，最早加工开始时间，加工持续时间]
                info_add = np.array([able_workpiece[i], able_gongxv[i], j, remain_worklist[able_workpiece[i]], begin_time, PTM[able_gongxv[i], j] * PRODUCT_info[able_workpiece[i], 1]])
                info = np.vstack((info, info_add))
                # 如果存在多个未加工时间最长的，则选择最小加工持续时间的工件
    select_info_index = np.argwhere(info[:, 3] == np.amax(info[:, 3], axis=0))
    # np.squeeze 将（1；4）转（4；） np.squeeze 将（1；4）转（4；）  .reshape(1,-1) 转（4；）为（1；4）
    select_info = info[np.squeeze(select_info_index)].reshape(-1, 6)
    if select_info.shape[0] != 1:
        second_index = np.argwhere(select_info[:, 4] == np.amin(select_info[:, 4], axis=0))
        select_info = select_info[np.squeeze(second_index)].reshape(-1, 6)
    x = random.randint(0, select_info.shape[0] - 1)
    select_gongxv = int(select_info[x, 1])
    select_Machine = int(select_info[x, 2])
    return select_gongxv, select_Machine





def action_done(action,PRODUCT_info,TTM,PTM,PPM,product_list,position_list,product_timelist,machinetime_list):

    Time_last = machinetime_list.max()
    timedone_rows = PRODUCT_info[PRODUCT_info[:, 3] <= Time_last]
    gongxv_list = timedone_rows[:, 2]
    total_gongxv = np.sum(gongxv_list)
    gongxvs = gongxv_list.size

    # 先根据前置表PPM把可行工序的集合列出来（如果时间有在插单后的则包括插单的，否则无）
    # (该logic成立的前提是订单按到达时间从小到大排序，PPM也是)
    able_gongxv = []
    for i in range(total_gongxv):
        done = 1
        if product_list[i] != -1:
            done = 0
        for j in range(total_gongxv):
            if PPM[i][j] == 1:
                if product_list[j] == -1:
                    done = 0
        if done == 1:
            able_gongxv.append(i)

    #可选的工序种类有几种
    ables = len(able_gongxv)

    # 获取所有可行工序的工件种类（对应4种工件的哪一种）
    able_workpiece = []
    for i in range(len(able_gongxv)):
        compare = 0
        for j in range(gongxvs):
            compare = compare + gongxv_list[j]
            if able_gongxv[i] < compare:
                able_workpiece.append(j)
                break
    if action ==0:
        select_gongxv, select_Machine = action1(PTM,PPM,TTM, position_list,machinetime_list,product_timelist,able_gongxv,able_workpiece,ables,PRODUCT_info)
    if action ==1:
        select_gongxv, select_Machine = action2(PTM,PPM,TTM,position_list,machinetime_list,product_timelist,able_gongxv,able_workpiece,ables,PRODUCT_info)
    if action ==2:
        select_gongxv, select_Machine = action3(PTM,PPM,TTM, position_list,machinetime_list,product_timelist,able_gongxv,able_workpiece,ables,PRODUCT_info)
    if action ==3:
        select_gongxv, select_Machine = action4(PTM,PPM,TTM,position_list,machinetime_list,product_timelist,able_gongxv,able_workpiece,ables,PRODUCT_info,product_list)
    if action ==4:
        select_gongxv, select_Machine = action5(PTM,PPM,TTM,position_list,machinetime_list,product_timelist,able_gongxv,able_workpiece,ables,PRODUCT_info,product_list)
    if action ==5:
        select_gongxv, select_Machine = action6(PTM,PPM,TTM,product_list,position_list,machinetime_list,product_timelist,able_gongxv,able_workpiece,ables,PRODUCT_info)


    return select_gongxv,select_Machine






#状态转移函数，其作用是根据action更新状态
def state_transition(select_gongxv,select_Machine,product_list,position_list,PTM,TTM,product_timelist,Machinetime_list,PRODUCT_info,FLAG,Initial_product_list,Weight,min_reward):

    third_column = PRODUCT_info[:, 2]
    total_gongxv = third_column.sum()

    # 先确定动作对应的product
    gongxvs = PRODUCT_info.shape[0]
    compare = 0
    for i in range(gongxvs):
        compare = compare + PRODUCT_info[i,2]
        if select_gongxv < compare:
            select_product = i
            break

    # 动作未进行时最小化最大完工时间
    c_max_now = np.amax(Machinetime_list)
    if FLAG == "Dynamic":
        change_number = 0
        aaa= Initial_product_list[3]
        for i in range(len(Initial_product_list[3])):
            if product_list[i] != -1 and Initial_product_list[3][i] != product_list[i]:
                change_number = change_number + 1
        ocp_now = change_number / len(Initial_product_list[3])

    #获取开始时间
    begin_time = max([Machinetime_list[select_Machine], product_timelist[select_product], PRODUCT_info[select_product, 3]])
    #获取设备当前完工时间
    C_max = C_max_calculation(PTM, TTM, position_list, product_timelist, Machinetime_list, select_gongxv, select_product, select_Machine, PRODUCT_info)


    #时间状态更新
    product_timelist[select_product] = C_max
    Machinetime_list[select_Machine] = C_max
    #更新product工序表
    product_list[select_gongxv] = select_Machine

    #更新product位置表
    position_list[select_product] = select_Machine

    #判断是否结束
    finish = 1
    for i in range(total_gongxv):
        if product_list[i] == -1:
            finish = 0
            break
    # 动作进行后最小化最大完工时间
    c_max_next = np.amax(Machinetime_list)

    #基于Tchebycheff的奖励计算
    if FLAG =="Initial":
        reward= 0 - (c_max_next - c_max_now)
        reward = (reward - min_reward) / (0 - min_reward)  #归一化

    else:
        reward1 = 0 - (c_max_next - c_max_now)
        reward11 = (reward1 - min_reward) / (0 - min_reward)

        #奖励2的逻辑编写
        change_number=0
        for i in range(len(Initial_product_list[3])):
            if product_list[i] != -1 and Initial_product_list[3][i] != product_list[i]:
                change_number=change_number+1
        ocp_next = change_number/len(Initial_product_list[3])
        reward2=0 - (ocp_next - ocp_now) #本身就是归一化的
        reward22 = (reward2 + 1/len(Initial_product_list[3])) / (0 + 1/len(Initial_product_list[3]))  # 归一化
        ws_reward = np.dot(Weight, np.array([reward1, reward2])) #标准加权
        n_ws_reward=np.dot(Weight,np.array([reward11,reward22]))#归一化加权
        tchebycheff = np.abs(np.array([reward1, reward2]) - np.array([0,0]))#标准Tchebycheff聚合函数
        t_reward = -np.max(tchebycheff * Weight,axis=0)
        n_tchebycheff=np.abs((np.array([reward1,reward2]) - np.array([0,0])) / (np.array([min_reward,-1 / len(Initial_product_list[3])])-np.array([0,0])  - 1e-6))#归一化Tchebycheff聚合函数
        reward = -np.max(n_tchebycheff * Weight,axis=0)
        #reward = n_ws_reward
    #后三个变量用于画图使用
    return product_list,position_list,product_timelist,Machinetime_list,finish,reward,begin_time,C_max,select_product







