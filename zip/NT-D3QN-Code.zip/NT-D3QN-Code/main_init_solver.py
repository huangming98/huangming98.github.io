#
# @Author      : Huang Ming
# @Create      : 2025/2/15 18:26
# @University  : Beijing Institute of Technology
# Copyright (C) 2026-05 Huang Ming, indie developer. All Rights Reserve
import numpy as np
import torch
import time
import os
from D3QN import D3QN
import model_training as mt
import toolset

EXCEL= 'data8-4-8.xlsx'

# 超参数设置
LR = 0.001  #8-4-8用的是0.01
MEMORY_CAPACITY = 2000
BATCH_SIZE = 512
EPSILON = 1
Q_NETWORK_ITERATION = 100
GAMMA=0.9
# 获取动作空间、状态空间大小
NUM_STATES = 7
NUM_ACTIONS =6
# 设置迭代次数、初始最大奖励
episodes = 1000
# 多目标优化的分解权重粒度
Decomposition_number= 20
def main():
    #########获得初始解#############
    FLAG="Initial"
    Initial_product_list=[]
    Weight=np.zeros((Decomposition_number+1,2),dtype=np.float64)

    Network_path = 'Network_save'
    if not os.path.exists(Network_path):
         os.makedirs(Network_path)
    save_path = f"result_data"
    if not os.path.exists(save_path):
         os.makedirs(save_path)
    Gannt_path = 'Gannt_save'
    if not os.path.exists(Gannt_path):
        os.makedirs(Gannt_path)

    # # D3QN执行
    # #计时开始
    torch.cuda.synchronize()
    time_start = time.time()
    GUID = f"init_d3qn"  # 储存时的命名区别符
    dqn_init = D3QN(NUM_STATES, NUM_ACTIONS, LR, MEMORY_CAPACITY, BATCH_SIZE, EPSILON, Q_NETWORK_ITERATION, GAMMA)
    reward_list, makespan_list, SCR_list, best_makespan, best_SCR, best_actionlist, bselect_gongxvlist, bselect_Machinelist, bselect_productlist, b_productlist, fixed_number_time = mt.model_training(
        episodes, dqn_init, EXCEL, FLAG,
        Weight, Initial_product_list, Network_path, GUID)

    torch.cuda.synchronize()
    time_end = time.time()
    time_sum = time_end - time_start
    print("best_makespan", best_makespan, "总耗时:", time_sum)

    toolset.draw_gantt(bselect_gongxvlist, bselect_Machinelist, bselect_productlist, b_productlist, best_makespan,
                       best_SCR, fixed_number_time, EXCEL, FLAG, GUID, Gannt_path)
    toolset.fig_data_save(reward_list, makespan_list, SCR_list, dqn_init, FLAG, save_path, GUID, best_makespan,
                          best_SCR, bselect_gongxvlist,
                          bselect_Machinelist, bselect_productlist, b_productlist, best_actionlist, time_sum, episodes)

if __name__ == '__main__':
    main()
