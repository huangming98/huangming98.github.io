function front_population = non_domination_sort_pareto( merge_population ,obj_no,MNumber)
%% 仅计算种群Pareto前沿面上的个体及拥挤度距离 
Object = merge_population(:,MNumber+1:MNumber+obj_no);
o = zeros(1,size(Object,1));
for i = 1:size(Object,1)                   % 找到前沿面赋值为零  
    o(i) = 0;                              % i是在逐步判定个体
    for j = 1:i-1
        if any(Object(i,:) ~= Object(j,:)) % 适应度值函数值不完全相同时，即任意一个不等就可得出逻辑 1即进行判定得出0即执行else。
           if dominates(Object(i,:),Object(j,:))
                o(j) = 1;
           elseif dominates(Object(j,:),Object(i,:))
                o(i) = 1;                  % 如果被支配则赋值为1
                break;                     % 只要当前个体被之前某一个体支配则不可能为前沿面上的个体直接赋值为1，赋值当前为一跳出循环 就终止for 或者while 循环
           end
        else
            o(i) = o(j);
        end
    end
end
indexo = find(o == 0);                          % 索引其位置
front_population = merge_population(indexo,:);  % 找出的前沿面个体集合
%% Crowding distance
distance = 0;
sorted_based_on_objective = [];
for i = 1 : obj_no
    [sorted_based_on_objective, index_of_objectives] = sort(front_population(:,MNumber+ i));   % 逐次按目标值排序
    sorted_based_on_objective = [];
    for j = 1 : length(index_of_objectives)
        sorted_based_on_objective(j,:) = front_population(index_of_objectives(j),:);           % 按目标函数排序后的个体集合
    end
    f_max = sorted_based_on_objective(length(index_of_objectives), MNumber + i);               % 找出该目标函数的最大值和最小值
    f_min = sorted_based_on_objective(1, MNumber + i);
    front_population(index_of_objectives(length(index_of_objectives)),obj_no + MNumber  + i)= Inf; % 对排序后的第一个个体和最后一个个体的距离设为无穷大
    front_population(index_of_objectives(1),obj_no + MNumber + i) = Inf;
    for j = 2 : length(index_of_objectives) - 1          %循环集合中除了第一个和最后一个的个体
        next_obj  = sorted_based_on_objective(j + 1,MNumber + i);
        previous_obj  = sorted_based_on_objective(j - 1,MNumber + i);
        if (f_max - f_min == 0)
            front_population(index_of_objectives(j),obj_no + MNumber+ i) = Inf;
        else
            front_population(index_of_objectives(j),obj_no + MNumber+ i) = (next_obj - previous_obj)/(f_max - f_min);
        end
    end
end  
distance = [];
distance(:,1) = zeros(size(front_population,1),1);
for i = 1 :obj_no
    distance(:,1) = distance(:,1) + front_population(:,obj_no + MNumber+ i); % 两个距离相加为最终距离
end
front_population(:,obj_no + MNumber+1) = distance;
front_population = front_population(:,1 : obj_no + MNumber+1);    
 
    
    
    
    
    
    
    
    
    

