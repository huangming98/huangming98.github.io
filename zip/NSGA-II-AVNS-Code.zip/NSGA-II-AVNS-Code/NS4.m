function N = NS4(front_pop,front_population,MNumber,obj_no,ci)
%% 寻找pareto上的开阔方向    
    % 不同的随机位变成与开阔点最优个体一致的编码
    %%找到开阔点（食物点）（即找到拥挤距离大于0.5的点合并后随机选）
    distance_index = find(front_population(:,MNumber+obj_no+1)>=0.5);
    Food_index = distance_index(1,unidrnd(size( distance_index,2)));        % 如果最少出现的一样则随机选
    Food_fitness = front_population( Food_index,MNumber+1:MNumber+obj_no);  
    Food_pos = front_population( Food_index,1:MNumber);
    N = [];
    FF = front_pop;
    difp = find(FF-Food_pos~=0);                      % 找到每列个体与食物点不同的位置
    for i = 1:ci
        FF = front_pop;
        if ~isempty(difp)                             % 注意difp可能为空 所以需要嵌套一个if
            fp = randi([1,size(difp,2)],1,1);         % 改变的零售商点数确定
            Mob = randperm(size(difp,2),fp);          % 改变的位置确定
            pindex = difp(1,Mob);                     % 需改变的零售商编号
            FF(1,pindex) = Food_pos(1,pindex);
            N = [N;FF];
        end            
    end
end