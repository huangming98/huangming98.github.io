function N = NS5(front_pop,front_population,selectv,MNumber,obj_no,ci)
%% 躲避pareto上拥挤的方向    
    %%与最拥挤点的相同位随机改为可选的不同车辆的编码 
    %%找到拥挤点（天敌点）
    distance_index = find(front_population(:,MNumber+obj_no+1)==min(front_population(:,MNumber+obj_no+1)));
    Enemy_index = distance_index(1,unidrnd(size( distance_index,2)));        % 如果最少出现的一样则随机选
    Enemy_fitness = front_population(Enemy_index,MNumber+1:MNumber+obj_no);  % 取前沿面中个体（拥挤距离最小的）作为天敌点
    Enemy_pos = front_population(Enemy_index,1:MNumber);
    N = [];
    FF = front_pop;
    somep = find(FF - Enemy_pos == 0);  % 找到两个数组中相同的元素所代表的零售商所组成的集合    可能为空故需要判定一下以免直接find后出现错误
    for  i = 1:ci
         FF = front_pop;  
         if ~isempty(somep)                                           % 非空时即有相同位
            fp = randi([1,size(somep,2)],1,1);                        % 改变的零售商点数确定
            Mob = randperm(size(somep,2),fp);                         % 改变的位置确定
            oindex = somep(1,Mob);                                    % 需改变的零售商编号
            for k = 1:length(oindex)
                selv = setdiff(selectv{1,oindex(k)},FF(1,oindex(k))); % 找到可选车但除去当前与天敌相同的编码后的可选集合selv是行向量
                sev = selv(unidrnd(size(selv,1)),1);                  % 随机选后选中的车的编码
                FF(1,oindex(k)) = sev;
            end
            N = [N;FF];
         end
    end