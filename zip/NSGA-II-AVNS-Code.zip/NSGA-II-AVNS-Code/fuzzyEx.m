function [obj] = fuzzyEx(fitness)
%% TFN取期望操作,输入形式为cell，可输入单一cell或n*2的cell 
[N,M] = size(fitness);
if M == 1 % 计算单一的模糊数
   obj = zeros(N,1);
   for i = 1:N
       obj(i,1) = (fitness{i,1}(1) + 2*fitness{i,1}(2) + fitness{i,1}(3))/4;
   end
else      % 计算目标函数模糊数
   obj = zeros(N,2);
   for i=1:N
       obj(i,1) = (fitness{i,1}(1) + 2*fitness{i,1}(2) + fitness{i,1}(3))/4;
       obj(i,2) = (fitness{i,2}(1) + 2*fitness{i,2}(2) + fitness{i,2}(3))/4;
   end
end