function [edpc]=fuzzypenaltytime(G,departuretime)
%% 计算某一巡回环中所有零售商接收订单的模糊加权惩罚时间（考虑了订单容量） 
global timewindows X occupy timespan Re Rd
edpc = [0 0 0];
atime = [];
wpenaltytime = [];
penaltytime = [];
wwpenaltytime = [];
for j = 1:size(G,2)           % 该巡回环中的零售商逐个遍历
    switch  j
            case 1
                atime = departuretime+X{G(1,j)};
                for i = 1:3
                    if atime(1,i) < timewindows(G(1,j),1)
                        wpenaltytime(1,i) = Re * abs(atime(1,i) - timewindows(G(1,j),1));
                    elseif  timewindows(G(1,j),1) <= atime(1,i) && atime(1,i) <= timewindows(G(1,j),2)
                        wpenaltytime(1,i) = 0;
                    else
                        wpenaltytime(1,i) = Rd * abs(atime(1,i) - timewindows(G(1,j),2));
                    end
                end
                penaltytimecell = [min(wpenaltytime'),wpenaltytime(2),max(wpenaltytime')];
                edpc = edpc + penaltytimecell * occupy(G(1,j));
        otherwise
              atime = atime + timespan{G(1,j-1),G(1,j)};
              for  i = 1:3
                    if atime(1,i) < timewindows(G(1,j),1)
                       wpenaltytime(1,i) = Re * abs(atime(1,i) - timewindows(G(1,j),1));
                    elseif  timewindows(G(1,j),1) <= atime(1,i) <= timewindows(G(1,j),2)
                        wpenaltytime(1,i) = 0;
                    else
                        wpenaltytime(1,i) = Rd * abs(atime(1,i) - timewindows(G(1,j),2));
                    end
              end
              penaltytimecell = [min(wpenaltytime'),wpenaltytime(2),max(wpenaltytime')];
              edpc = edpc + penaltytimecell * occupy(G(1,j));
        end  
end