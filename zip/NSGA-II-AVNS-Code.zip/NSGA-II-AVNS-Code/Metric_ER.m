function Score = ER(PopObj,allpop)
%% 评价指标：错误率 <metric> <min>  
%------------------------------- Reference --------------------------------
%%(调度优化邻域使用该指标paper) 2.“A hybrid collaborative framework for integrated production scheduling and vehicle routing problem with batch manufacturing and soft time windows,” COR（2023）
%%(调度优化邻域使用该指标paper) 3.考虑软时间窗限制和模糊旅途时间的生产配送集成调度优化. 控制理论与应用(2023）
%--------------------------------------------------------------------------
%PopObj ：所评价算法所得的Pareto前沿
%allpop:  所有测试算法所得的Pareto前沿面种群的集合
allpop = unique(allpop,'rows');
front_pop = non_domination_sort_front(allpop);
e_pop = setdiff(PopObj,front_pop,'rows');
Score = size(e_pop,1) / size(PopObj,1);
end

function front_pop = non_domination_sort_front( allpop)
        o = zeros(1,size(allpop,1));
        for i = 1:size(allpop,1)   % 找到前沿面赋值为零  
            o(i) = 0;              % i是在逐步判定个体
            for j = 1:i-1
                if any(allpop(i,:) ~= allpop(j,:)) % 适应度值函数值不完全相同时，即任意一个不等就可得出逻辑 1即进行判定得出0即执行else。

                    if dominates(allpop(i,:),allpop(j,:))
                        o(j) = 1;
                    elseif dominates(allpop(j,:),allpop(i,:))
                        o(i) = 1;   % 如果被支配则赋值为1
                        break;      % 只要当前个体被之前某一个体支配则不可能为前沿面上的个体直接赋值为1，赋值当前为一跳出循环 就终止for 或者while 循环
                    end
                else
                      o(i) = o(j);
                end
            end
        end
        indexo = find(o == 0);          % 索引其位置
        front_pop = allpop(indexo,:);   % 找出的前沿面个体集合
end
      
function    o = dominates(x,y)
            o = 0;
            if  x(1,1) <= y(1,1) && x(1,2) <= y(1,2)
               o = o + 1;
            end
end