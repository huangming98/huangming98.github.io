function f  = replace_chromosome(intermediate_chromosome, M, V,pop)
%% 修剪种群 
N = size(intermediate_chromosome,1);
unique_intermediate_chromosome = intermediate_chromosome;
if  size(unique_intermediate_chromosome,1) < pop                % unique后个体数小于种群个数时需要补上个 个体
    addnumber = pop - size(unique_intermediate_chromosome,1);   % addnumber是大于等于1的
    if  addnumber <= size(unique_intermediate_chromosome,1)
        index1 = randperm(N,addnumber);
        add_chromosome = unique_intermediate_chromosome(index1,:);
        unique_intermediate_chromosome = [unique_intermediate_chromosome;add_chromosome];
        [f,index2] = sortrows(unique_intermediate_chromosome,[M+V+1 M+V+2],{'ascend' 'descend'});
        clear index2
    else
         for h = 1:round(addnumber / size(unique_intermediate_chromosome,1)) + 1
            unique_intermediate_chromosome = [unique_intermediate_chromosome;intermediate_chromosome];
         end
         NN = size(unique_intermediate_chromosome,1);
         index1 = randperm(NN,addnumber);
         add_chromosome = unique_intermediate_chromosome(index1,:);
         unique_intermediate_chromosome = [unique_intermediate_chromosome;add_chromosome];
         [f,index2] = sortrows(unique_intermediate_chromosome,[M + V + 1 M + V + 2],{'ascend' 'descend'});
         clear index2
    end   
else
    [sorted_chromosome,index3] = sortrows(unique_intermediate_chromosome,[M + V + 1 M + V + 2],{'ascend' 'descend'});%先按序值再按拥挤距离排序
    clear index3
    f = sorted_chromosome(1:pop,:);
end
