function N=NS3(front_pop,selectv,ci)
%% 邻域结构3：%导向寻优  
%%负载换车操作  容量负载比例最小的被选中交换的概率越大 
global   vcapacity  occupy;
N = [];                         % 用于储存换车操作的后的邻域种群
G = S1_routing(front_pop);
% 用GOC代表该生产组占据容量/最大容量（表征占有率）
V = size(G,1); H = size(G,2);
GOC = zeros(V,H);
for i = 1:V
    for j = 1:H
        if ~isempty(G{i,j})
            for k = 1:size(G{i,j},2)
               GOC(i,j) = GOC(i,j) + occupy(G{i,j}(1,k),1);    
            end
            GOC(i,j) = GOC(i,j) / vcapacity(i,1);
            GOC(i,j) = 1 / GOC(i,j);                        % 表征被选中概率
        end
    end
end
weights = GOC(:);                                           % 将矩阵排成一列
for i = 1:ci
    cc = RouletteWheelSelection(weights);                   % 按权重选择一个需要换车的生产组
    cha = unidrnd(V * H);
    hang(1) = mod(cc,V);
    if hang(1) == 0
        hang(1) = V;
    end
    lie(1) = fix(cc / V);
    if hang(1) ~= V
       lie(1) = lie(1) + 1;
    end
    hang(2) = mod(cha,V);
    if hang(2) == 0
       hang(2) = V;
    end
    lie(2) = fix(cha/V);
    if hang(2) ~= V
       lie(2) = lie(2) + 1;
    end
    while hang(1) == hang(2)
         cha = unidrnd(V * H);
         hang(2) = mod(cha,V);
         if hang(2) == 0
            hang(2) = V;
         end
         lie(2) = fix(cha / V);
         if hang(2) ~= V
            lie(2) = lie(2) + 1;
         end
    end
    G_A = G{hang(1),lie(1)};                       % 该环所包含的零售商
    
    %%%整体换车 
    AA = front_pop;
    for k = 1:length(G_A)  
        flag = find(selectv{1,G_A(k)} == hang(2)); % 是否为可选车辆
        if  ~isempty(flag)
            AA(1,G_A(k)) = hang(2);
        end 
    end
    AAA = AA;                                      % 保存只改变一个组后的个体
    if  ~isempty(G{hang(2),lie(2)})
        G_B = G{hang(2),lie(2)};                   % 该环所包含的零售商%省略了容量比较问题
        for k = 1:length(G_B)
            flag = find(selectv{1,G_B(k)} == hang(1)); % 是否为可选车辆
            if  ~isempty(flag)
              AA(1,G_B(k)) = hang(1);
            end 
        end
    end
    
    %%%随机换车
    SS = front_pop;
    for k = 1:size(G_A,1)
        Mobile = selectv{1,G_A(k)};
        Mobilev = Mobile(unidrnd(size(Mobile,1)),1);  % 随机选后选中的车的编码
        SS(1,G_A(k)) = Mobilev;
    end  
    N = [N;AAA;AA;SS];                                % 用于储存邻域操作3执行后的邻域种群
end           