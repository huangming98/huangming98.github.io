function N = NS1(front_pop,front_population,selectv,MNumber,ci)
%% 邻域结构1：分散搜索  
% 将当前个体的多个位置的编码改为出现次数最少的车辆配送方式进行配送相同位变成不同位 寻找其中Ci个
N =[]; 
for i = 1:ci
    SS = front_pop;
    CC = front_pop;
    sp = randi([ceil(MNumber*0.3),MNumber],1,1);                    % 分散的零售商点数确定
    Mob = randperm(MNumber,sp);                                     % 分散的位置确定
    for k = 1:sp
        chuxian_v = unique(front_population(:,Mob(k)));
            if size(chuxian_v,1) < size(selectv{1,Mob(k)},1)        % 邻域内该订单所选车辆并未出现全部可能
                  diffv = setdiff(selectv{1,Mob(k)},chuxian_v);     % 未出现的车辆码
                  SS(1,Mob(k)) = diffv(unidrnd(length(diffv)),1);   % 在未出现的车辆码随机选
            else  % 可选车辆全部出现需要找最少出现的那辆车 如果最少出现的一样则随机选。
                  countv = histcounts(front_population(:,Mob(k)));  % histcounts(a)会出现计数0的情况相当于没有这个数
                  countv(countv == 0) = [];                         % 用于避免为0时占用一个位置导致选择是超出数组索引
                  %%必须由可能有的车辆容量小不能满足某一零售商的货物，导致可选车辆不全但是都出现了可能出现0导致索引错误。 
                  countvindex = find(countv == min(countv));
                  svindex = countvindex(1,unidrnd(size(countvindex,2))); % 如果最少出现的一样则随机选
                  sv = chuxian_v;
                  SS(1,Mob(k)) = sv(svindex,1);
            end
    end 
    N = [N;SS];
end