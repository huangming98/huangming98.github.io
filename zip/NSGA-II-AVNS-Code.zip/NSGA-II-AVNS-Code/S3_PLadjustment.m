function [GST,GFT,GDT,stockoccupy] = S3_PLadjustment(G,GPT,GPN,GSI,GDTW)
%% 整体的排产及各出发时刻的确定 
global  pallet 
%%批次的生产开始时间 生产完成时间和配送时间三个储存单元组（GST GFT GDT）共三种调整 调整有限次直至最优
%批次按生产顺序从0进行连续排产得出产线的批次的开始、完成（初步GST\GFT）并按可允许的最晚时间进行车辆开始时间的确定
[PNumber,R] = size(GPT);       % R 代表批次数
GFT = cumsum(GPT,2);           % 累计和
GST = GFT - GPT;
%% 得出初始的配送矩阵（正向调整）
GDT = cell([2,R]);%% 第一行储存配送开始时间节点；第二行储存配送结束返回到工厂的时间节点
%%%%大于各产线的最后完工时间、时间窗最早最晚、该车前一巡回环的回厂时间节点             
V = size(G,1); H = size(G,2);
for i = 1:R
     [row,col] = find(GSI == i);
     dep = max(max(GFT(:,i)),GDTW{3,i});                           % 最佳配送时间最晚时间节点
     if col == 1                                                   % 是该车的第一个巡回环
        GDT{1,i} = [dep,dep,dep];
        GDT{2,i} = GDT{1,i} + GDTW{4,i};                           % 模糊数
     else                                                          % 不是该车的第一个巡回环 需要考虑前一巡回环的回厂时间不能让车辆时间上产生重叠。
        GDT{1,i} = fuzzymax([dep,dep,dep],GDT{2,GSI(row,col - 1)});% 代表该各产线的最后完工时间、时间窗最晚、巡回环的前一巡回环的配送回厂时间三个时间节点的最大值
        GDT{2,i} = GDT{1,i} + GDTW{4,i};                                 
     end            
end
%% 根据GDT逆序调整批次的排产
for i = R:-1:1
     if i == R
        GFT(:,i) = GDT{1,i}(1);          % 最早的模糊数
        GST(:,i) = GFT(:,i) - GPT(:,i);  % 完成时间-生产时间
     else
        PNumber = size(GST,1);
        adj = zeros(PNumber,2);
        adj(:,1) = GST(:,i + 1);         % 下一批的生产开始时间
        adj(:,2) = GDT{1,i}(1);          % 当前批的生产配送时间
        GFT(:,i) = min(adj')';
        GST(:,i) = GFT(:,i) - GPT(:,i);
     end
end
%% 压缩生产配送时间间隔策略（当最佳配送时间为时间段时需要进行该策略）向前调度操作 满足最早配送
bestTW = cell2mat(GDTW(2:3,:)); 
if  bestTW(1,:) ~= bestTW(2,:)        % 存在时间段
    for i = 1:R
        if  i == 1
             adj1 = max(GPT(:,i));% 往前调整最大值后批次的最早完成时间的最大值即其瓶颈
             dep = max(adj1,GDTW{2,i});
             if i ~= R            % 并非最后一个批次   还要结合下一批次的生产开始时间进行判定
                 dep1 = inf(PNumber,1);
                 dep1(:) = dep;
                 GFT(:,i) = min([dep1,GST(:,i + 1)]')';
                 GST(:,i) = GFT(:,i) - GPT(:,i);
             else
                 GFT(:,i) = dep;
                 GST(:,i) = GFT(:,i) - GPT(:,i);
             end
             GDT{1,i} = [dep,dep,dep];
             GDT{2,i} = GDT{1,i} + GDTW{4,i};
       else
            [row,col] = find(GSI == i);
            adj1 = max(GFT(:,i - 1) + GPT(:,i));  % 往前调整最大值后批次的最早完成时间的最大值即其瓶颈
            if col == 1                           % 是该车的第一个巡回环
               dep = max(adj1,GDTW{2,i});
               if i ~= R                          % 并非最后一个批次
                 dep1 = inf(PNumber,1);
                 dep1(:) = dep;
                 GFT(:,i) = min([dep1,GST(:,i + 1)]')';
                 GST(:,i) = GFT(:,i) - GPT(:,i);
               else
                 GFT(:,i) = dep;
                 GST(:,i) = GFT(:,i) - GPT(:,i);
               end
               GDT{1,i} = [dep,dep,dep];
               GDT{2,i} = GDT{1,i} + GDTW{4,i}; 
            else                                   % 不是该车的第一个巡回环 需要考虑前一巡回环的回厂时间不能让车辆时间上产生重叠。
               dep = max(adj1,GDTW{2,i});
               GDT{1,i} = fuzzymax([dep,dep,dep],GDT{2,GSI(row,col - 1)})% 代表该各产线的瓶颈时间、时间窗最早、巡回环的前一巡回环的配送回厂时间三个时间节点的最大值
               GDT{2,i} = GDT{1,i} + GDTW{4,i};       
               if  i ~= R
                   for j = 1:PNumber
                      GFT(j,i) = min(GDT{1,i}(1),GST(j,i + 1));
                      GST(:,i) = GFT(:,i) - GPT(:,i);
                   end
               else
                  GFT(:,i) = GDT{1,i}(1);
                  GST(:,i) = GFT(:,i) - GPT(:,i);
               end                           
           end
        end
    end
end
%先去得出各批次的各产品线的生产组所占容量矩阵根据produce进行计算得出stockoccupy表征各批次的各种产线产品所占据的容量
PNumber = size(GST,1);
stockoccupy = zeros(PNumber,R);
for i = 1:PNumber
    stockoccupy(i,:) = GPN(i,:) * pallet(i);%每类产品占据的托盘数=产品数*单位产品占据托盘数
end

