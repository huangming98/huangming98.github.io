function [F] = fuzzymax(F1,F2)
%% Masatoshi Sakawa(1999) 的TFN取大的方法 
%实际应用：根据生产顺序进行batch-tour的协调时，对比出发时刻（区间）[A,A,A]和模糊时间
    F = max([F1;F2]);
end