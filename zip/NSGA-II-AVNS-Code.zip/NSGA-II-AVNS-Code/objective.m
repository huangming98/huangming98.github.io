function Z = objective(GST,GFT,GDT,GDTW,GSI,stockoccupy)
global produce vfixcost pc  holding vvarcost 
%总成本的计算
Z = cell([1,2]);
[PNumber,R] = size(GST);

%%生产成本
cost1 = 0;
sum_number = sum(produce,2);
cost1 = pc'*sum_number;

%%库存成本的求解  
depEx = [];
cost2 = 0;
for i = 1:R
    depEx(1,i) = fuzzyEx(GDT(1,i));
end
GGDT = repmat(depEx(1,:),PNumber,1);%重复数组行用来矩阵运算
AA = GGDT - GFT;
cost2 = sum((GGDT - GFT).*stockoccupy,'all') * holding;

%%车辆的配送成本
cost3 = 0;
vvcost = [0 0 0];
for i = 1:R
    vvcost = vvarcost(GDTW{5,i},1) * GDTW{4,i} + vvcost;   
end
vuse = size(GSI,1);  % 可能出现情况：可采用的车辆数为3辆但是只用了2辆，所以遍历时不能用VNumber作为遍历的终止代数。
for v = 1:vuse
    cost3 = nnz(GSI(v,:)) * vfixcost(v) + cost3;
end
cost3 = cost3 + vvcost;

%提前延期惩罚时间
totaltime = [0 0 0];    % 提前和延期惩罚模糊时间。
for i = 1:R
    [edpc] = fuzzypenaltytime(GDTW{1,i},GDT{1,i});
    totaltime = totaltime + edpc;
end    
Z{1,1} = cost1 + cost2 + cost3;
Z{1,2} = totaltime;