%% 正交实验设计(design of experiment, DOE)  
%%用于多次运行程序储存每次前沿面个体进行正交实验。
clear all; close all;clc;%清除所有变量\清图\清屏
all_front_population={};
parfor  iii=1:10
    unique_vis_front_population1=m_NSGA_II_AVNS(iii) % m_NSGA_II_AVNS:将NSGA_II_AVNS的主程序变为函数后执行并行运算
    all_front_population{iii,1}=unique_vis_front_population1;
end
    allpop=cell2mat(all_front_population);
    num=size(allpop,2);              % 等于零售商+2
    allpop=allpop(:,num-1:num);      % allpop代表所有算法所得的前沿面种群的集合
    Score=inf(10,1);
    for i=1:10
        PopObj=all_front_population{i,1}(:,num-1:num);  % 算法所得的前沿
        Score(i,1) = HV(PopObj,allpop);
    end
    [M,I1] = max(Score);
    zuhe1=all_front_population{I1,1};  % 储存该参数水平下的指标值  正交表L16 代表使用不同参数做16次。
)


