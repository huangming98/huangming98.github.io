function [s] = fuzzycom_min(F)
%% 寻找一组TFN中最小TFN，并返回其序号 
%利用雷德明(2010) 的模糊数比较大小的方法 并取出较小的模糊数所在行号
V = [];
for i = 1:size(F,1)
    V(i,1) = (F(i,1) + 2 * F(i,2) + F(i,3))/4;
    V(i,2) = F(i,2);
    V(i,3) = F(i,3) - F(i,1);
    V(i,4) = i;
end
[s1,~] = find(V(:,1) == min(V(:,1)));
V = V(s1,:);
if length(s1) == 1
    s = V(:,4);
else
    [s2,~] = find(V(:,2) == min(V(:,2)));
    V = V(s2,:);
    if length(s2) == 1
       s = V(:,4);
    else
        [s3,~] = find(V(:,3) == min(V(:,3)));
        V = V(s3,:);
        s = V(:,4);
    end
end