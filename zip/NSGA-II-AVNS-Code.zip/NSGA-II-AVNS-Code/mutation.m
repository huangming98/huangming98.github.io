function pop = mutation(MNumber, MU, pop,selectv)  
%% 多点变异操作 
for i = 1:size(pop,1)
        if rand < MU
           W = unidrnd(ceil(MNumber*0.4)); % 变异的点数
           p = randperm(MNumber,W);        % 变异的位置
           for  j = 1:size(p,2)
                selv = setdiff(selectv{1,p(1,j)},pop(i,p(1,j)),'stable'); % 找到可选车但刨去当前与当前相同的编码后的可选集合selv是行向量
                pop(i,p(1,j)) = selv(unidrnd(size(selv,1)),1);            % 随机选后选中的车的编码
           end 
        end
end