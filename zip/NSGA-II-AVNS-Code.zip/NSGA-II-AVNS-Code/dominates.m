function o=dominates(x,y)
%% non_domination_sort_front的支配判定 
o=0;
if  x(1,1)<=y(1,1)&&x(1,2)<=y(1,2)
   o=o+1;
end

end
