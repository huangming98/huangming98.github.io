function Score = HV(PopObj,allpop)
%% 评价指标：超体积 <指标越大越好>
%目标均为越小越好前沿面趋向于左下方
%------------------------------- Reference --------------------------------
%%(提出该指标paper)1."Comparison of Multiobjective Evolutionary Algorithms:Empirical Results"  Evolutionary Computation, (2000);
%%(调度优化邻域使用该指标paper) 2.“A hybrid collaborative framework for integrated production scheduling and vehicle routing problem with batch manufacturing and soft time windows,” COR（2023）
%%(调度优化邻域使用该指标paper) 3.考虑软时间窗限制和模糊旅途时间的生产配送集成调度优化. 控制理论与应用(2023）
%--------------------------------------------------------------------------
%PopObj ：所评价算法所得的Pareto前沿
%allpop:  所有测试算法所得的Pareto前沿面种群的集合
[N,M]  = size(PopObj);
fmin   = min(allpop,[],1);
fmax   = max(allpop,[],1);
PopObj = (PopObj - repmat(fmin,N,1))./repmat((fmax - fmin) * 1.1,N,1);   % 1.1是为了使两端的点不至于落在体积边界线上从而不影响指标HV周
Score = 0;
RefPoint = [1,1]; % 参考点
if isempty(PopObj)
    Score = 0;
else
    S = [];
    pl = sortrows(PopObj); % 由第一维从小到大排列
    for j = 1: size(pl,1)
        if j == size(pl,1)
           S(j,1) = abs(pl(j,1) - RefPoint(1,1));
        else
            S(j,1) = abs(pl(j+1,1) - pl(j,1));
        end
    end
    for i = 1 : size(pl,1)
        Score = Score + S(i,1) * abs(pl(i,2) - RefPoint(1,2));
    end
end
  