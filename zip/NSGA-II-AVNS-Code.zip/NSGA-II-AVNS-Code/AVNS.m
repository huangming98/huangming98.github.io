function [N_all,o] = AVNS(front_population,selectv,MNumber,obj_no,w1,w2,w3,w4,w5,ci)
%% 基于问题特征设计的自适应变邻域搜索策略
%针对前沿面个体执行邻域操作利用自适应的权重选择邻域结构 
%%基于问题特征设计的5种邻域结构, 涉及分散搜索、聚集搜索、导向寻优以及兼顾Pareto前沿面均匀性调整等方面; 
%%(NS1分散搜索;NS2聚集搜索;NS3更换车辆导向寻优; NS4、NS5拥挤调整)
N_all = [];
%自适应的权重变化，按轮盘赌选择操作类型 o=1\2\3\4\5分别代表五种操作 
weights = [w1;w2;w3;w4;w5];
o = RouletteWheelSelection(weights); 

for  i = 1:size(front_population,1)     % 针对每个前沿面个体去寻找其邻域
     front_pop = front_population(i,1:MNumber);            
     switch o
          case 1      % 分散搜索
                N = NS1(front_pop,front_population,selectv,MNumber,ci);
          case 2      % 聚集搜索    
                N = NS2(front_pop,front_population,selectv,MNumber,ci);
          case 3      % 导向寻优   
                N = NS3(front_pop,selectv,ci);
          case 4      % 寻找pareto上的开阔方向    
                N = NS4(front_pop,front_population,MNumber,obj_no,ci);
          otherwise   % 躲避pareto上拥挤的方向  
                N = NS5(front_pop,front_population,selectv,MNumber,obj_no,ci);
     end
     N_all = [N_all;N];
end