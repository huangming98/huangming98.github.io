function G = S1_routing(individual)
global  timewindows vcapacity occupy timespan X 
VNumber = size(vcapacity,1); 
G = {};
for k = 1:VNumber
    temp = find(individual==k);                                 % 每辆车配送的零售商
    %%其中的同一辆车的订单是按编号排序的需要改成按时间窗排序索引time表中的最晚时间
    %%将同一辆车的订单是按编号排序改成按时间窗排序的形式。
    st = timewindows(temp,:);
    [B2,index2] = sortrows(st,[2 1],{'ascend' 'ascend'});       % index代表零售商顺序 
    clear B2                                                    % 释放内存
    temp = temp(1,index2');                                     % 输出按时间窗排序的零售商编号顺序。
    %%按容量和时间窗约束进行排序车辆的巡回环     
    voccupy = 0;h = 1;L = 1;                                    % L储存该巡回环的第一个订单
    for t = 1:size(temp,2)
        if t == 1 && t ~= size(temp,2)                          % 只有t不等于1时L永远比t小
             voccupy = occupy(temp(1,t)) + voccupy;             % 有可能size(temp,2)=1，所以要加&&t~=size(temp,2)
        elseif t ~= 1&&t ~= size(temp,2)
             voccupy = occupy(temp(1,t)) + voccupy;
             if voccupy > vcapacity(k)                          % 超容重置 并形成一个巡回环
                G{k,h} = temp(1,L:t-1);
                L = t; h = h + 1;
                voccupy = occupy(temp(1,t));
             else                                               % 容量可载时，判定时间窗确定当前环排还是下一巡回环排
                vphtime = 0;
                for m = L:t-1                                   % L<=t-1 必成立
                vphtime = timespan{temp(1,m),temp(1,m+1)}+vphtime;   
                end
                vphtime = timewindows(temp(1,L),2)+vphtime;     % 零售商放当前轮的最晚到达时间
                if t == L+1                                     % 放在下个巡回环时上一巡回只有一个零售商
                   vnhtime = timewindows(temp(1,L),2) + X{temp(1,L)} + X{temp(1,t)};             % 放在下一巡回环中的最早到达时间
                else                                            % 放在下个巡回环时上一巡回有超过一个零售商
                   vnhtime = 0;
                   for m = L:t-2                                % L<=t-2 必成立
                   vnhtime = timespan{temp(1,m),temp(1,m+1)} + vnhtime;   
                   end
                   vnhtime = timewindows(temp(1,L),2) + vnhtime + X{temp(1,t-1)} + X{temp(1,t)}; % 放在下一巡回环中的最早到达时间
                end
                vphtimecell = {vphtime};vnhtimecell = {vnhtime};
                if fuzzyEx(vphtimecell) < timewindows(temp(1,t),1) && fuzzyEx(vnhtimecell) < timewindows(temp(1,t),2)       
                 % 零售商放当前轮的最晚到达时间<该零售商时间窗的最早时间
                 % 并且放在下一巡回环中在车辆不停歇的情况下的最早到达时间<该零售商时间窗的最晚时间（如果想要更严格可以用最早时间）
                 % 将该零售商放置在下一巡回环中
                   G{k,h} = temp(1,L:t-1);
                   L = t;  h = h + 1;
                   voccupy = occupy(temp(1,t)); 
                end
             end
        else                                                 % 判定最后一个零售商订单的存放环次
             voccupy = occupy(temp(1,t))+ voccupy;
             if voccupy > vcapacity(k)                       % 超容重置 
                   G{k,h} = temp(1,L:t - 1);
                  G{k,h + 1} = temp(1,t);
             else
                G{k,h} = temp(1,L:t);                        % 没必要考虑放到下一轮的情况 最后一个订单放到下一轮需要重新启动巡回车没有必要
             end
        end
    end      
  end