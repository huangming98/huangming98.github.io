clc;clear;
%% Algorithm name: NSGA-II-AVNS （自适应变邻域搜索改进的非支配排序遗传算法） 
%------------------------------- Reference --------------------------------
%%黄铭, 杜百岗, 郭钧, 等. 考虑软时间窗限制和模糊旅途时间的生产配送集成调度优化. 控制理论与应用, 2023, 40(x): 1 – 10 DOI: 10.7641/CTA.2023.20920
%--------------------------------------------------------------------------
%% 数据传入
    global  timespan X produce timewindows takt pc pallet vcapacity vfixcost vvarcost occupy Re Rd holding; % 变成全局变量避免传参频繁-精简代码
    % global reference_point;
    path = 'D:\桌面\Fuzzy-IPDS Dateset\instance4-5-20\';
    Data = {'traveltime','retailsneed','other'};
    xlsx_tail = '.xlsx';
    PATH1 = [path,Data{1,1},xlsx_tail];
    PATH2 = [path,Data{1,2},xlsx_tail];
    PATH3 = [path,Data{1,3},xlsx_tail];
    [timespan,X,produce,timewindows,takt,pc,pallet,vcapacity,vfixcost,vvarcost] = read_para(PATH1,PATH2,PATH3);%读取数据
    clear PATH1 PATH2 PATH3
    %创立写结果的文件夹
    respath='result\';
    respath=[respath,'Data4-5-20','\'];
    a=['mkdir ' respath];
    system(a);%利用Windows命令行命令执行dos命令
    fprintf('%s %s\r\n','Calculating ',respath);
%% 基本参数
    population_num = 200;          % 种群中的个体数目
    Re = 1;                        % 提前惩罚时间率
    Rd = 3;                        % 延期惩罚时间率
    holding = 10;                  % 单位托盘的库存持有成本率             
    Max_iteration = 200;           % 最大迭代次数
    obj_no = 2;                    % 目标函数的个数
    w1 = 1;                        % NS1：分散搜索权重
    w2 = 1;                        % NS2：聚集搜索权重
    w3 = 1;                        % NS3：导向寻优权重
    w4 = 1;                        % NS4：寻找pareto上的开阔方向权重
    w5 = 1;                        % NS5：逃离pareto上拥挤的方向权重
    CR = 0.7;                      % 交叉概率
    MU = 0.3;                      % 变异概率
    CI = 2;                        % 邻域结构执行的次数
    RS = 0.5;                      % 邻域结构分值重置时迭代百分比
    
%% 初始化
    %%计算零售商订单占据托盘量
    [PNumber,MNumber] = size(produce);
    VNumber = size(vcapacity,1); 
    occupy = (pallet'*produce)';                                         % matlab的矩阵运算
   
    %%产生随机初始可行解   并且获得各零售商依据订单容量可选的车序号集合利用元胞数组(后续VNS中NS3导向寻优时会用到)
    rpopulation = zeros(population_num,MNumber);
    selectv = cell([1,MNumber]);                                         % 储存零售商可选的车辆
    for j = 1:MNumber
        selectv{1,j} = find(vcapacity(:,1) >= occupy(j));                % 该行代码仅支持数据传入时车辆容量是按降序排列的 因此可选的车序号连续
        rpopulation(:,j) = randi(size(selectv{1,j},1),population_num,1); % 要考虑该订单所能随机选的车的车容量是大于该订单容量的才可运输。              
    end
    population = rpopulation;                                            % 随机选取初始种群
    
%% NSGA-Ⅱ+VNS
    ObjectF = Fitnessvalue(population);
    Object = fuzzyEx(ObjectF);
    population = [population,Object];
    population = non_domination_sort_mod_min(population,obj_no, MNumber);% 非支配排序与拥挤度距离
    
    for iter = 1:Max_iteration  
        %%锦标赛选择操作
        pool_size = population_num * 0.9;                                      % 设置选择代沟
        tour_size = 2;
        child_population = tournament_selection(population, pool_size, tour_size);
        child_population = child_population(:,1:MNumber);
        %%基于片段的两两交叉操
        child_population = cross(MNumber,CR,child_population);
        %%变异操作                        
        child_population = mutation(MNumber,MU,child_population,selectv);

        %%合并父子并排序
        ObjectF = Fitnessvalue(child_population); 
        Object = fuzzyEx(ObjectF);
        child_population = [child_population,Object];
        child_population = [child_population;population(:,1:MNumber+obj_no)];
        child_population = unique( child_population,'row');
        front_population = non_domination_sort_pareto( child_population ,obj_no,MNumber);

        %%对当前前沿面个体进行自适应的变邻域搜索（AVNS）
        [neighborhood_population,o] = AVNS(front_population,selectv,MNumber,obj_no,w1,w2,w3,w4,w5,CI);

        %%合并基于（精英策略保留的父代个体）和（子代种群）和（ALNS搜索出来的邻域种群）后进行非支配排序并修剪产生新种群     
        ObjectF = Fitnessvalue(neighborhood_population); 
        Object = fuzzyEx(ObjectF); 
        neighborhood_population = [neighborhood_population,Object];
        Final_population = [child_population;neighborhood_population];
        Final_population = unique(Final_population,'row');
        %%非支配排序
        Final_population = non_domination_sort_mod_min(Final_population,obj_no, MNumber);
        %%修剪种群
        population = replace_chromosome(Final_population,obj_no, MNumber, population_num);
        frontnumber =  find(Final_population(:,obj_no+MNumber+1)==1,1,'last'); % 前沿面个体数
        unique_vis_front_population = Final_population(1:frontnumber,1:MNumber + 2);

        %%更新自适应权重根据前沿面个数的变化和seff函数的使用进行实现
        former_front_population = unique(front_population(:,1:MNumber),'row');
        former_num = size(former_front_population,1);
        up1_population = setdiff(unique_vis_front_population(:,1:MNumber),former_front_population,'rows'); % 当前前沿面有，原来前沿面无的的个体集合。即更新个体集合
        up1 = size(up1_population,1);
        up_rate = up1 / former_num;          % 前沿面更新比率
        if up_rate == 0                      % 所执行邻域结构增加权重的确定
            addweight = 0;
        elseif up_rate <= 0.1 
            addweight = 1;
        elseif up_rate <= 0.3 
            addweight = 2;
        elseif up_rate <= 0.5 
            addweight = 3;
        elseif up_rate > 0.5 
            addweight = 4;
        end

        switch o
        case 1
            w1 = w1 + addweight;
        case 2
            w2 = w2 + addweight;
        case 3
            w3 = w3 + addweight;
        case 4
            w4 = w4 + addweight;
        case 5
            w5 = w5 + addweight;
        end
        if  iter == ceil(RS*Max_iteration) % 执行邻域结构分值重置操作
            w1 = 1;
            w2 = 1;                       
            w3 = 1;                   
            w4 = 1;                     
            w5 = 1;  
        end
       %% Visualize        
         disp(['NSGA_II_AVNS 第 ', num2str(iter), ' 次迭代有 ', num2str(size(unique_vis_front_population,1)), ' 个非支配解']);
            figure(1)
            plot(population(:,MNumber + 1),population(:,MNumber + 2),'o','MarkerSize',8,'MarkerFaceColor','#1a6fdf');                                   % 表征种群变化  
            title('种群演化图','fontsize',12)
            xlabel('总成本/元','fontsize',12)
            ylabel('提前延迟加权惩罚时间/h','fontsize',12)
            set (gcf,'Position',[50,50,700,500], 'color','w')
            figure(2)
            plot(unique_vis_front_population(:,MNumber + 1),unique_vis_front_population(:,MNumber + 2),'o','MarkerSize',8,'MarkerFaceColor','#e41a1c'); % 表征前沿面
            title('Pareto前沿面','fontsize',12)
            xlabel('总成本/元','fontsize',12)
            ylabel('提前延迟加权惩罚时间/h','fontsize',12)
            legend({'pareto'},'Location','northeast','NumColumns',4);
            set (gcf,'Position',[800,50,700,500], 'color','w') 
            drawnow    
    end
   saveas(2,[respath,'pareto front.jpg'])
   save([respath,'pareto.mat'],'unique_vis_front_population','-nocompression'); % 保存变量以.mat的形式