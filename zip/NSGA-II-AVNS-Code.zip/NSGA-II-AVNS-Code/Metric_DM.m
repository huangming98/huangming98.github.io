function Score = DM(PopObj,allpop)
%% 评价指标：分布指标<metric> <min>Metric 
%%分布越均匀（方差越小）；覆盖范围越大（设计点间距和分布范围的比值就越小）；所以越小越好
%------------------------------- Reference --------------------------------
%%(提出该指标paper)1.A new distribution metric for comparing Pareto optimal solutions  Kai Zheng1 & Ren-Jye Yang2 & Hongyi Xu2 & Jie Hu1  (2016)
%%(调度优化邻域使用该指标paper) 2.“A hybrid collaborative framework for integrated production scheduling and vehicle routing problem with batch manufacturing and soft time windows,” COR（2023）
%%(调度优化邻域使用该指标paper) 3.考虑软时间窗限制和模糊旅途时间的生产配送集成调度优化. 控制理论与应用(2023）
%--------------------------------------------------------------------------
%PopObj ：所评价算法所得的Pareto前沿
%allpop:  所有测试算法所得的Pareto前沿面种群的集合
    if size(PopObj,1) < 3   %只有两个或一个解时
        Score = inf;
    else
        fmin = min(PopObj,[],1);
        fmax = max(PopObj,[],1);
        fU   = min(allpop,[],1);   % Utopia design point.
        fN   = max(allpop,[],1);   % Nadir design point.
        pl = sortrows(PopObj);     % 由第一维从小到大排列
        pop_num = size(pl,1);      % 个体数
        obj_num = size(pl,2);      % 目标个数
        D = [];
        Score = 0;
        for i = 1:obj_num
            for j = 1: size(pl,i)-1          
               D(j,1) = abs(pl(j + 1,i) - pl(j,i));    
            end
            d_mean = mean(D);
            d_var = var(D);
            Score = Score + (d_var / d_mean) * (abs(fU(i) - fN(i)) / (fmax(i) - fmin(i)));
        end
        Score = Score / pop_num;
    end