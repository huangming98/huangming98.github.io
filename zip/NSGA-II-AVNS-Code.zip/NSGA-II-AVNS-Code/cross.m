function pop = cross(MNumber, CR, pop)
%% 基于标准的两点交叉操作 
for i = 1:2:size(pop,1)-mod(size(pop,1),2)
   if rand < CR %实现片段的交换
      dian = randperm(MNumber,2);
      dian_1 = dian(1,1);
      dian_2 = dian(1,2);
      if dian_1 > dian_2
         temp1 = dian_1;
         dian_1 = dian_2;
         dian_2 = temp1;
      end
      temp = pop(i,dian_1:dian_2);
      pop(i,dian_1:dian_2) = pop(i+1,dian_1:dian_2); 
      pop(i+1,dian_1:dian_2) = temp;
   end
 end