%% ������-����ģ������ͼGANTT��ʾ��Ϊ4-5-30�� 
global  timespan X produce timewindows takt pc pallet vcapacity vfixcost vvarcost occupy Re Rd holding; % ȫ�ֳ���
individual = [2,4,4,4,2,5,3,4,5,2,5,4,5,5,5,5,5,5,4,4,5,5,5,4,4,4,4,3,4,3];  %%�ɱ���С
%individual = [4,4,3,3,5,5,1,5,5,1,2,5,3,3,2,4,3,5,4,4,3,3,3,5,5,4,4,1,3,1];   %�ͷ�ʱ����С
%% ��ȡ����
    path='D:\����\Fuzzy-IPDS Dateset\instance4-5-30\';
    Data={'traveltime','retailsneed','other'};
    xlsx_tail='.xlsx';
    PATH1 = [path,Data{1,1},xlsx_tail];
    PATH2 = [path,Data{1,2},xlsx_tail];
    PATH3 = [path,Data{1,3},xlsx_tail];
    [timespan,X,produce,timewindows,takt,pc,pallet,vcapacity,vfixcost,vvarcost] = read_para(PATH1,PATH2,PATH3);% ��ȡ����
    Re = 1;                              % ��ǰ�ͷ�ʱ����
    Rd = 3;                              % ���ڳͷ�ʱ����(ʱ�������1��3�����������ǰ�Ǹ����ܽ��ܵ�)
    holding = 10;                        % ��λ���̵Ŀ����гɱ���    
    %%���������̶���ռ��������
    [PNumber,MNumber] = size(produce);
    VNumber = size(vcapacity,1); 
    occupy = (pallet' * produce)'; 
    clear PATH1 PATH2 PATH3     
%% ���߱�����ȡ
    G = S1_routing(individual);
    [G,DBT] = S2_besttime(G);             % ���ͳ�������ֵ
    [GDTW,GSI,GPT,GPN] = S3_groupDPtime(G,DBT);
    [GST,GFT,GDT,stockoccupy] = S3_PLadjustment(G,GPT,GPN,GSI,GDTW);
    GST = round(GST,2);
    GFT = round(GFT,2);
    tournum = size(GST,2);
    % ��ԭɫ��ʾ
    c={[0.890625	0.1015625	0.109375] [0.1015625	0.43359375	0.87109375] [0.09765625	0.17578125	0.72265625] [0.31640625	0.31640625	0.31640625] [0.21484375	0.67578125	0.41796875] [0.796875	0.59765625	0] [0.2421875	0.16796875	0.42578125] [0.1875	0.58984375	0.63671875] [0.01953125	0.3125	0.35546875] [0.27734375	0.19921875	0.20703125]};
    e = [0 0 0];
    O_Font = 'Times New Roman';
    n_Font = 'Times New Roman';
    n_size = 7;
    O_size = 9;
    dot_size = 6;
    O_up = 2.2;
    dot_up = 1.8;
    h1 = 1;                                                        % ��ʾ���εĳ����εĸ� 
    h2 = 2;                                                        % ��ʾ���������̴�ʱ�䣨TFN���ĸ�
    x = 150;                                                       % x��ĳ���
    set(gcf,'Units','centimeters','Position',[17.5,5.4,28,9.7]);   % ���������ᵼ��ͼƬ�ĳ���
    axis([0,150,0,32]);
    plot([0 0],[0 32]);
    hold on;
    plot([0 x],[4 4],'color',c{6});                                 % ������ x=0-80 y=2-2
    hold on;
    plot([0 x],[8 8],'color',c{6});
    hold on;
    plot([0 x],[12 12],'color',c{6});
    hold on;
    plot([0 x],[16 16],'color',c{6});
    hold on;
    plot([0 x],[20 20],'color',c{6});
    hold on;
    plot([0 x],[24 24],'color',c{2});
    hold on;
    plot([0 x],[26 26],'color',c{2});
    hold on;
    plot([0 x],[28 28],'color',c{2});
    hold on;
    plot([0 x],[30 30],'color',c{2});
    hold on;
    %'FontName' ����  'FontSize'�־�
    text(-3,4,'V','FontName',O_Font,'FontSize',O_size);text(-1.5,3.5,'5','FontName',n_Font,'FontSize',n_size);
    text(-3,8,'V','FontName',O_Font,'FontSize',O_size);text(-1.5,7.5,'4','FontName',n_Font,'FontSize',n_size);
    text(-3,12,'V','FontName',O_Font,'FontSize',O_size);text(-1.5,11.5,'3','FontName',n_Font,'FontSize',n_size);
    text(-3,16,'V','FontName',O_Font,'FontSize',O_size);text(-1.5,15.5,'2','FontName',n_Font,'FontSize',n_size);
    text(-3,20,'V','FontName',O_Font,'FontSize',O_size);text(-1.5,19.5,'1','FontName',n_Font,'FontSize',n_size);
    text(-3,24+1,'P','FontName',O_Font,'FontSize',O_size);text(-1.5,23.5+1,'4','FontName',n_Font,'FontSize',n_size);
    text(-3,26+1,'P','FontName',O_Font,'FontSize',O_size);text(-1.5,25.5+1,'3','FontName',n_Font,'FontSize',n_size);  %+1 ��P�볤���ζ���
    text(-3,28+1,'P','FontName',O_Font,'FontSize',O_size);text(-1.5,27.5+1,'2','FontName',n_Font,'FontSize',n_size);
    text(-3,30+1,'P','FontName',O_Font,'FontSize',O_size);text(-1.5,29.5+1,'1','FontName',n_Font,'FontSize',n_size);
    for i = 1:tournum
        color = mod(i,10);
        if  color == 0
            color = 10;
        end
      vy = GDTW{5,i};
      vy = 24 - vy * 4;                                          % ʵ�ʵĸó���ռ��ͼ��������
      plot([GDT{1,i}(1) GDT{1,i}(1)],[vy 30], 'Color',c{color}); % �����εĳ��������ߣ�batch-tour��
      hold on;
      patch([ GST(1,i) GFT(1,i) GFT(1,i) GST(1,i)],[30 30 30+h1 30+h1],c{color});
      patch([ GST(2,i) GFT(2,i) GFT(2,i) GST(2,i)],[28 28 28+h1 28+h1],c{color});
      patch([ GST(3,i) GFT(3,i) GFT(3,i) GST(3,i)],[26 26 26+h1 26+h1],c{color});
      patch([ GST(4,i) GFT(4,i) GFT(4,i) GST(4,i)],[24 24 24+h1 24+h1],c{color});
      [row,col] = find(GSI == i);
      if col == 1  %�ǳ����ĵ�һ��Ѳ�ػ�
          patch([GDT{1,i}(1) GDT{1,i}(1) + 0.2 GDT{1,i}(1) + 0.2 GDT{1,i}(1)],[vy vy vy + h2 vy + h2],c{color})  
          text(GDT{1,i}(1) - 2.5,vy + 1,strcat(num2str(round(GDT{1,i}(1),1))),'FontName',n_Font,'FontSize',n_size);      % �����ǿ�ǰһ����λ��ʼ��
          text(GDT{1,i}(1)-5,vy + O_up,'tour','FontName',O_Font,'FontSize',O_size);
          text(GDT{1,i}(1)-1,vy + dot_up, strcat(num2str(i)),'FontSize',dot_size); 
        else                                                         % ���Ǹó��ĵ�һ��Ѳ�ػ�
            if  GDT{1,i}(1) == GDT{1,i}(2) && GDT{1,i}(2) == GDT{1,i}(3)      
                patch([GDT{1,i}(1) GDT{1,i}(1) + 0.2 GDT{1,i}(1) + 0.2 GDT{1,i}(1)],[vy vy vy + h2 vy + h2],c{color});
                text(GDT{1,i}(1) - 2.5,vy + 1,strcat(num2str(round(GDT{1,i}(1),1))),'FontName',n_Font,'FontSize',n_size);  % �����ǿ�ǰһ����λ��ʼ��
                text(GDT{1,i}(1) - 5,vy + O_up,'tour','FontName',O_Font,'FontSize',O_size);
                text(GDT{1,i}(1) - 1,vy + dot_up, strcat(num2str(i)),'FontSize',dot_size);                                 % ��עtour1  tour3 ��
            else
                patch([ GDT{1,i}(1) GDT{1,i}(2) GDT{1,i}(3)],[vy vy + h2 vy],c{color});                                    % ���ǵĸ�Ϊ1.5
                ps = strcat('(',num2str(round(GDT{1,i}(1),1)));
                ps = strcat(ps,',');
                ps = strcat(ps,num2str(round(GDT{1,i}(2),1)));
                ps = strcat(ps,',');
                ps = strcat(ps,num2str(round(GDT{1,i}(3),1)));
                ps = strcat(ps,')');                                                                                       % �γɣ�5��8��10����������
                text(GDT{1,i}(2) - 2.5,vy + 1,ps,'FontName',n_Font,'FontSize',n_size);                                     % �����ǿ�ǰһ����λ��ʼ��  
                text(GDT{1,i}(2) - 5,vy + O_up,'tour','FontName',O_Font,'FontSize',O_size);
                text(GDT{1,i}(2) - 1,vy + dot_up, strcat(num2str(i)),'FontSize',dot_size);
            end  
        end
        %������Ѳ�ػ��ķ��ع�����ģ��ʱ��
        patch([ GDT{2,i}(1) GDT{2,i}(2) GDT{2,i}(3)],[vy vy-h2 vy],c{color});
        ps = strcat('(',num2str(round(GDT{2,i}(1),1)));
        ps = strcat(ps,',');
        ps = strcat(ps,num2str(round(GDT{2,i}(2),1)));
        ps = strcat(ps,',');
        ps = strcat(ps,num2str(round(GDT{2,i}(3),1)));
        ps = strcat(ps,')');
        text(GDT{2,i}(2) - 2.5,vy - 1,ps,'FontName',n_Font,'FontSize',n_size);
        text(GDT{2,i}(2) - 5,vy - 1.8,'tour','FontName',O_Font,'FontSize',O_size);
        text(GDT{2,i}(2) - 1,vy - 2.3, strcat(num2str(i)),'FontSize',dot_size);

        %����������ģ����ͼ
        early = 0;ness = 0;last = 0;
        for j = 1:size(GDTW{1,i},2)
            if j == 1                                                         % Ѳ�ػ����ʵĵ�һ�������� int2str
                early = GDT{1,i}(1) + X{GDTW{1,i}(1)}(1);
                ness = GDT{1,i}(2) + X{GDTW{1,i}(1)}(2);
                last = GDT{1,i}(3) + X{GDTW{1,i}(1)}(3);
                patch([early ness last],[vy vy + h2 vy],c{color});            % ���ǵĸ�Ϊ1.5
                ps = strcat('(',num2str(round(early,1)));
                ps = strcat(ps,',');
                ps = strcat(ps,num2str(round(ness,1)));
                ps = strcat(ps,',');
                ps = strcat(ps,num2str(round(last,1)));
                ps = strcat(ps,')');                                           % �γɣ�5��8��10����������
                text(ness - 1,vy + 1,ps,'FontName',n_Font,'FontSize',n_size);  % �����ǿ�ǰһ����λ��ʼ��  
                text(ness,vy + O_up,'R','FontName',O_Font,'FontSize',O_size);
                text(ness + 1.5,vy + dot_up, strcat(num2str(GDTW{1,i}(1))),'FontSize',dot_size);
             else
                early = early + timespan{GDTW{1,i}(j),GDTW{1,i}(j - 1)}(1);
                ness =  ness + timespan{GDTW{1,i}(j),GDTW{1,i}(j - 1)}(2);
                last = last + timespan{GDTW{1,i}(j),GDTW{1,i}(j - 1)}(3);
                patch([early ness last],[vy vy + h2 vy],c{color});
                ps = strcat('(',num2str(round(early,1)));
                ps = strcat(ps,',');
                ps = strcat(ps,num2str(round(ness,1)));
                ps = strcat(ps,',');
                ps = strcat(ps,num2str(round(last,1)));
                ps = strcat(ps,')');
                text(ness - 1,vy + 1,ps,'FontName',n_Font,'FontSize',n_size);
                text(ness,vy + O_up,'R','FontName',O_Font,'FontSize',O_size);
                text(ness + 1.5,vy + dot_up, strcat(num2str(GDTW{1,i}(j))),'FontSize',dot_size);
            end   
        end
    end   
    set(gca,'ytick',[]);           % ����������հ�
    alpha(0.4)
    set(gca,'XTick',[0:10:150])    % �ı�x����������ʾ ������Ϊ2
    hold off