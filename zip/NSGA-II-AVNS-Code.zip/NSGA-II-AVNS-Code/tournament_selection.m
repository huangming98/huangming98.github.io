function child_population = tournament_selection(population, pool_size, tour_size)
%% 锦标赛选择法 
% pool_size选出的个体数进行后续交叉和变异, tour_size（进行锦标赛的个体数）
% 典型的NSGA-Ⅱ的tour_size是2 。可以自定义2-5之间，超过5被证明意义不大。
[population_num, variables] = size(population);
rank = variables - 1;           % 序值所在列
distance = variables;           % 拥挤距离所在列
child_population = zeros(pool_size,variables);
for i = 1 : pool_size           % Select n individuals at random, where n = tour_size
    candidate = inf(1,tour_size);
    for j = 1 : tour_size       % Select an individual at random
        candidate(j) = unidrnd(population_num);
        % Make sure that the array starts from one. 
        if j > 1
            % Make sure that same candidate is not choosen.
            while ~isempty(find(candidate(1 : j - 1) == candidate(j)))%如果重复重新选
                candidate(j) = unidrnd(population_num);
            end
        end
    end
    % Collect information about the selected candidates.
     c_obj_rank = inf(1,tour_size); c_obj_distance = inf(1,tour_size);
    for j = 1 : tour_size
        c_obj_rank(j) = population(candidate(j),rank);
        c_obj_distance(j) = population(candidate(j),distance);
    end
    % Find the candidate with the least rank
    min_candidate = find(c_obj_rank == min(c_obj_rank));
    % If more than one candiate have the least rank then find the candidate
    % within that group having the maximum crowding distance.
    if length(min_candidate) ~= 1       % 序值有多个第一梯队时，比较最大拥挤距离
        max_candidate = find(c_obj_distance(min_candidate) == max(c_obj_distance(min_candidate)));
        if length(max_candidate) ~= 1   % 如果最大拥挤距离也一样就选第一个
            max_candidate = max_candidate(1);
        end
        child_population(i,:) = population(candidate(min_candidate(max_candidate)),:);
    else
        child_population(i,:) = population(candidate(min_candidate(1)),:);
    end
end
