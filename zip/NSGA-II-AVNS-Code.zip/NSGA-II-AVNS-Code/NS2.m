function N=NS2(front_pop,front_population,selectv,MNumber,ci)
%% 邻域结构2：聚集搜索     
%%个体向邻域的中点移动即改为每个位置上重复最多的车编号  寻找其中Ci个
    N = []; 
    for i = 1:ci
        CC = front_pop;
        sp = randi([ceil(MNumber*0.3),MNumber],1,1);                       % 聚集的零售商点数确定
        Mob = randperm(MNumber,sp);                                        % 聚集的位置确定
        for k = 1:sp
            chuxian_v = unique(front_population(:,Mob(k)));
            countv = histcounts(front_population(:,Mob(k)));               % histcounts(a)会出现计数0的情况相当于没有这个数
            countv(countv == 0) = [];
            countvindex1 = find(countv == max(countv));
            svindex1 = countvindex1(1,unidrnd(size(countvindex1,2)));      % 如果最多出现的一样则随机选
            sv1 = chuxian_v;
            CC(1,Mob(k)) = sv1(svindex1,1);
        end 
        N = [N;CC];
    end