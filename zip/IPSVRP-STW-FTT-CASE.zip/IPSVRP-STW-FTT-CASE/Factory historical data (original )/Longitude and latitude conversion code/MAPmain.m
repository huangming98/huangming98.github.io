clc;clear
load location
[m,n]=size(location);
T=zeros(m,m); %Travel distance
for i=1:1:m
    for j=i+1:1:m
        T(i,j)=distance(location(i,1),location(i,2),location(j,1),location(j,2));
    end
end

for i=1:1:m
    for j=i+1:1:m
        T(j,i)=T(i,j); 
    end
end

figure(1)
hold on 
for i=1:m
    if i==1
        plot(location(i,1),location(i,2),'o','MarkerFaceColor','b');
    else
    plot(location(i,1),location(i,2),'s','MarkerFaceColor','b');
    end
    text(location(i,1)+0.05,location(i,2),num2str(i-1));
end
title('车辆路径网络图')
xlabel('经度')
ylabel('纬度')

