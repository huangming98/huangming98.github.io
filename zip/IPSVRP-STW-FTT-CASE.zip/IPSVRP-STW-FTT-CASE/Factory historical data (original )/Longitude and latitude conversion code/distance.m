function dis=distance(MLonA,LatA,MLonB,LatB)%MLonA经度,LatA纬度
         c = sin(LatA/57.2958)*sin(LatB/57.2958) + cos(LatA/57.2958)*cos(LatB/57.2958)*cos((MLonA-MLonB)/57.2958);
         dis=6371.004*acos(c);
end
