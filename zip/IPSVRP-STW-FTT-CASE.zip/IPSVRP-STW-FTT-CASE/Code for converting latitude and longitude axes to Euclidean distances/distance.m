function dis=distance(MLonA,LatA,MLonB,LatB)%MLonA经度,LatA纬度
         c = sin(LatA/57.2958)*sin(LatB/57.2958) + cos(LatA/57.2958)*cos(LatB/57.2958)*cos((MLonA-MLonB)/57.2958);
         dis=6371.004*acos(c);
end
% Distance = R*Arccos(C) = 6371.004*Arccos(C) kilometer = 0.621371192*6371.004*Arccos(C) mile = 3958.758349716768*Arccos(C) mile
