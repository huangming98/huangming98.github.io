This industry case is obtained from the factory's historical data.
The industry case includes 22 assembly islands, 5 product orders, and a maximum assembly process count of 11.

The Excel file for industry case consists of four worksheets:
    **Worksheet 1 – Order information**
    This worksheet records the information of historical dealer orders, including the product type, the number of products, the maximum number of processes, and the order arrival time;

    **Worksheet 2 – Assembly processing information**
    This worksheet stores the processing duration of the assembly process k of product i on assembly island m. The processing time for each product operation at the assembly islands is determined based on preset assembly times and historical process data. A value of -1 indicates that the corresponding assembly island is incapable of performing the specified process. The unit is minutes;

    **Worksheet 3 – Transportation information**
    This worksheet stores the transportation time required for products to move between any two assembly islands. It is derived based on the travel distances and steady travel speeds of the AGVs, with clamping calibration time and unloading positioning time included. The unit is minutes;

    **Worksheet 4 – Predecessor process information**
    This worksheet stores the precedence constraints for the assembly processes of each product. Each row uses 0-1 encoding to indicate which assembly processes must be completed before a specific assembly processes can begin. For example, if the 1~3 columns of row 4 are 1 and the rest are 0, it means that assembly process 4 of product 1 must follow assembly processes 1, 2 and 3. I.e. The set of predecessor processes for the assembly process 4 of product 1 includes assembly process 1 ~3 of product 1;
