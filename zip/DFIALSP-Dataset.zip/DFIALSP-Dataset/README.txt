Dynamic flexible island assembly line scheduling problem dataset: DFIALSP-Dataset (IAI 8-4-8, IAI 12-8-10, IAI 16-12-12).
The test instances (IAI M-P-max(O_i)) are defined by the number of assembly islands (M {8, 12, 16}), the number of product types (P {4, 8, 12}), and the maximum number of assembly processes (max(O_i) {8, 10, 12}).

The Excel file for each test instance consists of four worksheets:
    **Worksheet 1 – Order information**
    This worksheet records the information of each product order, including the product type, the number of products, the maximum number of processes, and the order arrival time;

    **Worksheet 2 – Processing information**
    This worksheet stores the processing duration of the assembly process k of product i on assembly island m. A value of -1 indicates that the corresponding assembly island is incapable of performing the specified process. The unit is minutes;

    **Worksheet 3 – Transportation information**
    This worksheet stores the transportation time required for products to move between any two assembly islands. The unit is minutes;

    **Worksheet 4 – Predecessor process information**
    This worksheet stores the precedence constraints for the assembly processes of each product. Each row uses 0-1 encoding to indicate which assembly processes must be completed before a specific assembly processes can begin. For example, if the 1 and 2 columns of row 3 are 1 and the rest are 0, it means that assembly process 3 of product 1 must follow assembly processes 1 and 2. I.e. The set of predecessor processes for the assembly process 3 of product 1 includes assembly process 1 and assembly process 2 of product 1;
