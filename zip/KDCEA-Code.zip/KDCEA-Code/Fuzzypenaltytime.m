function [edpc] = Fuzzypenaltytime(G,departuretime)
%% 计算one tour中所有retails的模糊加权惩罚时间（考虑了订单容量）
global timewindows X occupy timespan Re Rd
edpc = [0 0 0];
atime = [];
penaltytime = [];
for j = 1:size(G,2)           %该巡回环中的零售商逐个遍历
     switch j
            case 1
                atime = departuretime+X{G(1,j)};  
         otherwise
                atime = atime + timespan{G(1,j-1),G(1,j)};
     end
     for i = 1:3
         penaltytime(1,i) = atime(1,i) - min( max(timewindows(G(1,j),1),atime(1,i)) ,timewindows(G(1,j),2)); % 惩罚时间（<0提前到达、>0延迟到达）
     end
     superposition_penaltytime = fuzzy_superposition(penaltytime,0,Re,Rd,0); % Fuzzy Superposition Operation
     edpc = edpc + superposition_penaltytime * occupy(G(1,j));
end