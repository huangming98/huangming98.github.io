function SX_TFN = fuzzy_superposition(X_TFN,k,w1,w2,mode)
%% FUZZY SUPERPOSITION OPERATION
%------------------------------- Reference --------------------------------
%%"Fuzzy Superposition Operation and Knowledgedriven Co-evolutionary Algorithm for Integrated 
%  Production Scheduling and Vehicle Routing Problem with Soft Time Windows and Fuzzy Travel Times"
%--------------------------------------------------------------------------
%  x: Triangular fuzzy number 
%  k: the superimposed axis  x=k
%  w1: Weights on the left side of the axis  x=k
%  w2: Weights on the right side of the axis  x=k
%  mode:  0:Superimpose the left part of the axis to the right part
%         1:Superimpose the right part of the axis to the left part
%  mode:
%  mode=0  : SX=(|x-k|-(x-k))/(-2(x-k))*[w1(k-x)+k]+(|x-k|+(x-k))/(2(x-k))*[w2*x]=0.5*[(w2-w1)*x+(1+w1)k]+0.5*|x-k|*[(w1+w2)*x-(1+w1)k]/(x-k)  %(simplified)
%  mode=1  : SX=(|x-k|-(x-k))/(-2(x-k))*[w1*x]+(|x-k|+(x-k))/(2(x-k))*[w2(k-x)+k]=0.5*[(w1-w2)*x+(1+w2)k]+0.5*|x-k|*[(1+w1)k-(w1+w2)*x]/(x-k)  %(simplified)
for i = 1:3
    if  X_TFN(1,i) == k
        SX(1,i) = k;
    else
        if  mode == 0
            SX(1,i) = 0.5 * ((w2 - w1) * X_TFN(1,i) + (1 + w1) * k) + 0.5 * abs(X_TFN(1,i) - k) * ((w1 + w2) * X_TFN(1,i) - (1 + w1) * k) / (X_TFN(1,i) - k);
        else
            SX(1,i) = 0.5 * ((w1 - w2) * X_TFN(1,i) + (1 + w2) * k) + 0.5 * abs(X_TFN(1,i) - k) * ((1 + w1) * k - (w1 + w2) * X_TFN(1,i)) / (X_TFN(1,i) - k);
        end
    end
end
SX_TFN = [min(SX'),SX(1,2),max(SX')];