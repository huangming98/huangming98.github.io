function [edpc] = fuzzy_superposition(G,departuretime)
%% FUZZY SUPERPOSITION OPERATION
%计算one tour中所有retails的模糊加权惩罚时间（考虑了订单容量）
global timewindows X occupy timespan Re Rd
edpc = [0 0 0];
atime = [];
penaltytime = [];
for j = 1:size(G,2)           %该巡回环中的零售商逐个遍历
     switch j
       case 1
            atime = departuretime+X{G(1,j)};
            for i = 1:3
                if atime(1,i) < timewindows(G(1,j),1)
                    penaltytime(1,i) = Re * abs(atime(1,i)-timewindows(G(1,j),1));
                elseif  timewindows(G(1,j),1) <= atime(1,i) && atime(1,i) <= timewindows(G(1,j),2)
                    penaltytime(1,i) = 0;
                else
                    penaltytime(1,i) = Rd * abs(atime(1,i) - timewindows(G(1,j),2));
                end
            end
            penaltytimecell = [min(penaltytime'),penaltytime(2),max(penaltytime')];  % fuzzy_superposition
            edpc = edpc + penaltytimecell * occupy(G(1,j));
        otherwise
            atime = atime + timespan{G(1,j-1),G(1,j)};
            for i = 1:3
                if atime(1,i) < timewindows(G(1,j),1)
                   penaltytime(1,i) = Re * abs(atime(1,i) - timewindows(G(1,j),1));
                elseif  timewindows(G(1,j),1) <= atime(1,i) <= timewindows(G(1,j),2)
                    penaltytime(1,i) = 0;
                else
                    penaltytime(1,i) = Rd * abs(atime(1,i) - timewindows(G(1,j),2));
                end
            end
            penaltytimecell = [min(penaltytime'),penaltytime(2),max(penaltytime')];
            edpc = edpc + penaltytimecell * occupy(G(1,j));
     end
end