function op = Knowledge_drival(CV,KS,K)
%% knowledge-drival operator selection
if       all(CV == 0) || any(KS(1,:) == 0)  %如果知识集未满时或无操作能提升时
         op = randi(K);       
elseif   any(CV == 0)        %如果知识集中某类操作未出现
         if rand < 0.5
            op = RouletteWheelSelection(CV);
         else  
            ap = find(CV == 0);
            op = ap(unidrnd(length(ap)));
         end                
else
         op = RouletteWheelSelection(CV);
end
if op == -1   % KS里第二行均为0  说明没一种操作可以更新的  应随机选一个
   op = randi(K);
end