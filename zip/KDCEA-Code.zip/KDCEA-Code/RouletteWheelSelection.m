function o = RouletteWheelSelection(weights) %%实现按权重轮盘赌数越大选中概率越大
%% 轮盘赌选择法（输入权重向量；输出序号）
accumulation = cumsum(weights);        % 累计数
p = rand() * accumulation(end);        % 随机位置
chosen_index = -1;
for index = 1 : length(accumulation)   % 利用length向量不管权重是行向量还是列向量都可
    if (accumulation(index) > p)
        chosen_index = index;
        break;
    end
end
o = chosen_index;