%% ������-����ģ������ͼGANTT��ʾ��Ϊ5-6-30��
global  timespan X produce timewindows takt pc pallet vcapacity vfixcost vvarcost occupy Re Rd holding; %ȫ�ֳ���
% individual = [2,3,2,6,3,2,2,1,6,5,2,5,6,5,5,6,5,3,4,3,2,3,2,2,5,6,5,6,2,5]% �ͷ�ʱ����С 418071,81
individual = [5,5,6,6,4,5,6,5,6,6,4,5,6,5,5,4,6,5,6,4,6,5,6,4,5,5,5,6,5,6]% �ɱ���С 374566,1180
%% ��ȡ����
    path = 'D:\����\IPSVRP-STW-FTT-Dateset\instance5-6-30 real case\';
    Data = {'traveltime','retailsneed','other'};
    xlsx_tail = '.xlsx';
    PATH1 = [path,Data{1,1},xlsx_tail];
    PATH2 = [path,Data{1,2},xlsx_tail];
    PATH3 = [path,Data{1,3},xlsx_tail];
    [timespan,X,produce,timewindows,takt,pc,pallet,vcapacity,vfixcost,vvarcost] = read_para(PATH1,PATH2,PATH3);% ��ȡ����
    Re = 1;                              % ��ǰ�ͷ�ʱ����
    Rd = 3;                              % ���ڳͷ�ʱ����(ʱ�������1��3�����������ǰ�Ǹ����ܽ��ܵ�)
    holding = 10;                        % ��λ���̵Ŀ����гɱ���    
    %%���������̶���ռ��������
    [PNumber,MNumber] = size(produce);
    VNumber = size(vcapacity,1); 
    occupy = (pallet' * produce)'; 
    clear PATH1 PATH2 PATH3   
%% ���߱�����ȡ
%     ObjectF=Fitnessvalue(individual);
    G = S1_routing(individual);
    [G,DBT] = S2_besttime(G);             % ���ͳ�������ֵ
    [GDTW,GSI,GPT,GPN] = S3_groupDPtime(G,DBT);
    [GST,GFT,GDT,stockoccupy] = S3_PLadjustment(G,GPT,GPN,GSI,GDTW);
    GST = round(GST,2);
    GFT = round(GFT,2);
    tournum = size(GST,2);
    % ��ԭɫ��ʾ
   % c = {[0.953125	0.43359375	0.265625] [0.640625	0.01953125	0.26953125] [0.98828125	0.84765625	0.51953125] [0.91015625	0.95703125	0.62890625] [0.49609375	0.79296875	0.640625] [0.29296875	0.39453125	0.68359375] [0.65625	0.8515625	0.85546875] [0.46843  0.40392	0.93333] [1	0.8549	0.72549] [0.37647	0.48235	0.5451]};
    c = {[0.4765625	0.10546875	0.42578125] [0.73828125	0.21484375	0.3203125] [0.92578125	0.40625	0.14453125] [0.98046875	0.703125	0.1015625] [0.984375	0.6171875	0.49609375]  [0.71484375	0.70703125	0.625] [0.15234375	0.6171875	0.734375]  [0.0703125	0.40625	0.51171875] [0.0078125	0.1875	0.27734375] [0	0	0.98828125] [0.91015625	0.95703125	0.62890625] [0.49609375	0.79296875	0.640625] [0.29296875	0.39453125	0.68359375] [0.65625	0.8515625	0.85546875] [0.46843  0.40392	0.93333] [0 0 0]};
    e = [0 0 0];
    
    O_Font = 'Times New Roman';
    n_Font = 'Times New Roman';
    n_size = 7;
    O_size = 9;
    dot_size = 6;
    O_up = 2.2;
    dot_up = 1.8;
    h1 = 1;                                                        % ��ʾ���εĳ����εĸ� 
    h2 = 2;                                                        % ��ʾ���������̴�ʱ�䣨TFN���ĸ�
    x = 210;                                                       % x��ĳ���
    set(gcf,'Units','centimeters','Position',[17.5,5.4,28,9.7]);   % ���������ᵼ��ͼƬ�ĳ���
    axis([30,210,0,39]);
    plot([0 0],[0 38]);
    hold on;
    plot([0 x],[4 4],'color',c{16});                                % ������ x=0-80 y=2-2
    hold on;
    plot([0 x],[8 8],'color',c{16});
    hold on;
    plot([0 x],[12 12],'color',c{16});
    hold on;
    plot([0 x],[16 16],'color',c{16});
    hold on;
    plot([0 x],[20 20],'color',c{16});
    hold on;
    plot([0 x],[24 24],'color',c{16});
    hold on;
    plot([0 x],[28 28],'color',c{2});
    hold on;
    plot([0 x],[30 30],'color',c{2});
    hold on;
    plot([0 x],[32 32],'color',c{2});
    hold on;
    plot([0 x],[34 34],'color',c{2});
    hold on;
    plot([0 x],[36 36],'color',c{2});
    hold on;
    %'FontName' ����  'FontSize'�־�
    text(-3,4,'V','FontName',O_Font,'FontSize',O_size);text(-1.5,3.5,'6','FontName',n_Font,'FontSize',n_size);
    text(-3,8,'V','FontName',O_Font,'FontSize',O_size);text(-1.5,7.5,'5','FontName',n_Font,'FontSize',n_size);
    text(-3,12,'V','FontName',O_Font,'FontSize',O_size);text(-1.5,11.5,'4','FontName',n_Font,'FontSize',n_size);
    text(-3,16,'V','FontName',O_Font,'FontSize',O_size);text(-1.5,15.5,'3','FontName',n_Font,'FontSize',n_size);
    text(-3,20,'V','FontName',O_Font,'FontSize',O_size);text(-1.5,19.5,'2','FontName',n_Font,'FontSize',n_size);
    text(-3,24,'V','FontName',O_Font,'FontSize',O_size);text(-1.5,23.5,'1','FontName',n_Font,'FontSize',n_size);
    text(-3,28+1,'P','FontName',O_Font,'FontSize',O_size);text(-1.5,27.5+1,'5','FontName',n_Font,'FontSize',n_size);
    text(-3,30+1,'P','FontName',O_Font,'FontSize',O_size);text(-1.5,29.5+1,'4','FontName',n_Font,'FontSize',n_size);
    text(-3,32+1,'P','FontName',O_Font,'FontSize',O_size);text(-1.5,31.5+1,'3','FontName',n_Font,'FontSize',n_size);
    text(-3,34+1,'P','FontName',O_Font,'FontSize',O_size);text(-1.5,33.5+1,'2','FontName',n_Font,'FontSize',n_size);
    text(-3,36+1,'P','FontName',O_Font,'FontSize',O_size);text(-1.5,35.5+1,'1','FontName',n_Font,'FontSize',n_size);
    for i = 1:tournum
        color = mod(i,14);
        if  color == 0
            color = 14;
        end
        vy = GDTW{5,i};
        vy = 28 - vy * 4;                                           % ʵ�ʵĸó���ռ��ͼ��������
        plot([GDT{1,i}(1) GDT{1,i}(1)],[vy 36], 'Color',c{color});  % �����εĳ��������ߣ�batch-tour��
        hold on;
        patch([ GST(1,i) GFT(1,i) GFT(1,i) GST(1,i)],[36 36 36 + h1 36 + h1],c{color});
        patch([ GST(2,i) GFT(2,i) GFT(2,i) GST(2,i)],[34 34 34 + h1 34 + h1],c{color});
        patch([ GST(3,i) GFT(3,i) GFT(3,i) GST(3,i)],[32 32 32 + h1 32 + h1],c{color});
        patch([ GST(4,i) GFT(4,i) GFT(4,i) GST(4,i)],[30 30 30 + h1 30 + h1],c{color});
        patch([ GST(5,i) GFT(5,i) GFT(5,i) GST(5,i)],[28 28 28 + h1 28 + h1],c{color});
        [row,col] = find(GSI == i);
        if  col == 1                                                 % �ǳ����ĵ�һ��Ѳ�ػ�
            patch([GDT{1,i}(1) GDT{1,i}(1) + 0.2 GDT{1,i}(1) + 0.2 GDT{1,i}(1)],[vy vy vy + h2 vy + h2],c{color})  
            text(GDT{1,i}(1) - 2.5,vy + 1,strcat(num2str(round(GDT{1,i}(1),1))),'FontName',n_Font,'FontSize',n_size);      % �����ǿ�ǰһ����λ��ʼ��
            text(GDT{1,i}(1)-5,vy + O_up,'tour','FontName',O_Font,'FontSize',O_size);
            text(GDT{1,i}(1)-1,vy + dot_up, strcat(num2str(i)),'FontSize',dot_size);                                       % ��עtour1  tour3 ��
        else                                                         % ���Ǹó��ĵ�һ��Ѳ�ػ�
            if  GDT{1,i}(1) == GDT{1,i}(2) && GDT{1,i}(2) == GDT{1,i}(3)      
                patch([GDT{1,i}(1) GDT{1,i}(1) + 0.2 GDT{1,i}(1) + 0.2 GDT{1,i}(1)],[vy vy vy + h2 vy + h2],c{color});
                text(GDT{1,i}(1) - 2.5,vy + 1,strcat(num2str(round(GDT{1,i}(1),1))),'FontName',n_Font,'FontSize',n_size);  % �����ǿ�ǰһ����λ��ʼ��
                text(GDT{1,i}(1) - 5,vy + O_up,'tour','FontName',O_Font,'FontSize',O_size);
                text(GDT{1,i}(1) - 1,vy + dot_up, strcat(num2str(i)),'FontSize',dot_size);                                 % ��עtour1  tour3 ��
            else
                patch([ GDT{1,i}(1) GDT{1,i}(2) GDT{1,i}(3)],[vy vy + h2 vy],c{color});                                    % ���ǵĸ�Ϊ1.5
                ps = strcat('(',num2str(round(GDT{1,i}(1),1)));
                ps = strcat(ps,',');
                ps = strcat(ps,num2str(round(GDT{1,i}(2),1)));
                ps = strcat(ps,',');
                ps = strcat(ps,num2str(round(GDT{1,i}(3),1)));
                ps = strcat(ps,')');                                                                                       % �γɣ�5��8��10����������
                text(GDT{1,i}(2) - 2.5,vy + 1,ps,'FontName',n_Font,'FontSize',n_size);                                     % �����ǿ�ǰһ����λ��ʼ��  
                text(GDT{1,i}(2) - 5,vy + O_up,'tour','FontName',O_Font,'FontSize',O_size);
                text(GDT{1,i}(2) - 1,vy + dot_up, strcat(num2str(i)),'FontSize',dot_size);
            end  
        end
        %������Ѳ�ػ��ķ��ع�����ģ��ʱ��
        patch([ GDT{2,i}(1) GDT{2,i}(2) GDT{2,i}(3)],[vy vy-h2 vy],c{color});
        ps = strcat('(',num2str(round(GDT{2,i}(1),1)));
        ps = strcat(ps,',');
        ps = strcat(ps,num2str(round(GDT{2,i}(2),1)));
        ps = strcat(ps,',');
        ps = strcat(ps,num2str(round(GDT{2,i}(3),1)));
        ps = strcat(ps,')');
        text(GDT{2,i}(2) - 2.5,vy - 1,ps,'FontName',n_Font,'FontSize',n_size);
        text(GDT{2,i}(2) - 5,vy - 1.8,'tour','FontName',O_Font,'FontSize',O_size);
        text(GDT{2,i}(2) - 1,vy - 2.3, strcat(num2str(i)),'FontSize',dot_size);
        %����������ģ����ͼ
        early = 0;ness = 0;last = 0;
        for j = 1:size(GDTW{1,i},2)
            if j == 1                                                         % Ѳ�ػ����ʵĵ�һ�������� int2str
                early = GDT{1,i}(1) + X{GDTW{1,i}(1)}(1);
                ness = GDT{1,i}(2) + X{GDTW{1,i}(1)}(2);
                last = GDT{1,i}(3) + X{GDTW{1,i}(1)}(3);
                patch([early ness last],[vy vy + h2 vy],c{color});            % ���ǵĸ�Ϊ1.5
                ps = strcat('(',num2str(round(early,1)));
                ps = strcat(ps,',');
                ps = strcat(ps,num2str(round(ness,1)));
                ps = strcat(ps,',');
                ps = strcat(ps,num2str(round(last,1)));
                ps = strcat(ps,')');                                           % �γɣ�5��8��10����������
                text(ness - 1,vy + 1,ps,'FontName',n_Font,'FontSize',n_size);  % �����ǿ�ǰһ����λ��ʼ��  
                text(ness,vy + O_up,'R','FontName',O_Font,'FontSize',O_size);
                text(ness + 1.5,vy + dot_up, strcat(num2str(GDTW{1,i}(1))),'FontSize',dot_size);
             else
                early = early + timespan{GDTW{1,i}(j),GDTW{1,i}(j - 1)}(1);
                ness =  ness + timespan{GDTW{1,i}(j),GDTW{1,i}(j - 1)}(2);
                last = last + timespan{GDTW{1,i}(j),GDTW{1,i}(j - 1)}(3);
                patch([early ness last],[vy vy + h2 vy],c{color});
                ps = strcat('(',num2str(round(early,1)));
                ps = strcat(ps,',');
                ps = strcat(ps,num2str(round(ness,1)));
                ps = strcat(ps,',');
                ps = strcat(ps,num2str(round(last,1)));
                ps = strcat(ps,')');
                text(ness - 1,vy + 1,ps,'FontName',n_Font,'FontSize',n_size);
                text(ness,vy + O_up,'R','FontName',O_Font,'FontSize',O_size);
                text(ness + 1.5,vy + dot_up, strcat(num2str(GDTW{1,i}(j))),'FontSize',dot_size);
            end   
        end
    end    
    set(gca,'ytick',[]);           % ����������հ�
    alpha(0.5)
    set(gca,'XTick',[30:10:210])    % �ı�x����������ʾ ������Ϊ2
    hold off