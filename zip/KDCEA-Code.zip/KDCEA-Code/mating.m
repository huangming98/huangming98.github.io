function Offspring = mating(selectv,op,x,population,P,MNumber,EP)
%% Four different operators base on problem knowledges
N = [];
    switch op
              case 1      %Vehicle replacement based on vehicle actual load rate.
                    N = OP1(x,selectv);
              case 2      % Aiming to reduce the weighted penalty time of the batch.
                    N = OP2(x,selectv);
              case 3      % Vehicle replacement based on least frequently(enrich the individual search region).
                    N = OP3(x,population(P,:),selectv,MNumber);
              case 4      % External population to guide and assist the evolution of the two subpopulations.
                    N = OP4(x,EP(:,1:MNumber),selectv,MNumber);
    end
    Offspring = N;
end