function [pop_best,W,Pi] = updateWeightU(pop_best,W,Z,EP,nus,Pi)
%% MOEA/D-AWA 权重的调整（归一化的切比雪夫函数）
% Delete overcrowded subproblems and add new subproblems
%Population 种群 W 权重向量 Z 参考理想点,EP 外部精英种群,nus 更改权重向量的最大数目
[N,M] = size(pop_best);
M = M - 2;%最后两列是目标列
%% Update the current population by EP
% Calculate the function value of each solution in Population or EP on
% each subproblem in W merge
merge = [pop_best;EP];
m_in = min(merge(:,M + 1:M + 2));
m_ax = max(merge(:,M + 1:M + 2));
mergeObj = abs(merge(:,M + 1:M + 2) - repmat(m_in,length(merge),1)) ./ (m_ax - m_in);%考虑了归一化
g = zeros(size(merge,1),size(W,1));
for i = 1 : size(W,1)
    g(:,i) = max(mergeObj.*repmat(W(i,:),size(merge,1),1),[],2);  % 针对每个权重向量 获取混合种群中每个个体的对应归一化后切比雪夫聚合函数值 放置成一列
end
% Choose the best solution for each subproblem
[~,best] = min(g,[],1);
pop_best = merge(best,:);                                         % 获取每个权重向量的最佳个体（编码+目标值）
pop_best_U = abs(pop_best(:,M + 1:M + 2) - repmat(min(pop_best(:,M + 1:M + 2)),length(best),1)) ./ (max(pop_best(:,M + 1:M + 2)) - min(pop_best(:,M + 1:M + 2)));%考虑了归一化
%% Delete the overcrowded subproblems
Dis = pdist2(pop_best_U,pop_best_U);                              % 每对观测值之间的距离
Dis(logical(eye(length(Dis)))) = inf;
Del = false(1,size(pop_best,1));
while sum(Del) < min(nus,size(EP,1))
    Remain = find(~Del);
    subDis = sort(Dis(Remain,Remain),2); 
    [~,worst] = min(prod(subDis(:,1:min(2,length(Remain))),2));  
    Del(Remain(worst)) = true;
end
pop_best = pop_best(~Del,:);
W = W(~Del,:); 
Pi(size(pop_best,1) + 1:end) = max(Pi);  % 将新插入的个体效益改为目前最大值使其更易被选      
%% Add new subproblems
% Determine the new solutions be added
merge  = [pop_best;EP];
Selected = false(1,size(merge,1));
Selected(1:size(pop_best,1)) = true;
merge_U = abs(merge(:,M + 1:M + 2) - repmat(min(merge(:,M + 1:M + 2)),size(merge,1),1)) ./ (max(merge(:,M + 1:M + 2)) - min(merge(:,M + 1:M + 2)));%考虑了归一化
Dis = pdist2(merge_U,merge_U);                                    % 每对观测值之间的距离
Dis(logical(eye(length(Dis)))) = inf;
while sum(Selected) < min(N,size(Selected,2))                     % 执行添加的循环直至达到规模
    subDis = sort(Dis(~Selected,Selected),2);                     % 外部EP到 当前保留的种群的各个点的距离从小到大排序
    [~,best] = max(prod(subDis(:,1:min(2,size(subDis,2))),2));    % 距离最大的外部种群中的个体是最优的查入个体
    Remain = find(~Selected);
    Selected(Remain(best)) = true;
end
% Add new subproblems
newObjs = EP(Selected(size(pop_best,1)+1:end),M+1:M+2);
temp = 1./(newObjs-repmat(Z,size(newObjs,1),1)+1e-6);
W = [W;temp./repmat(sum(temp,2),1,size(temp,2))];                 % 该目标值对应的最优权重向量
% Add new solutions
pop_best = merge(Selected,:);