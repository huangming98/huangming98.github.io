function [GDTW,GSI,GPT,GPN] = S3_groupDPtime(G,DBT)
global produce timespan X takt 
%批次按最佳配送时间排序
V = size(DBT,1);H = size(DBT,2);
r = 0;
GDTW = cell([V*H,5]);
for v = 1:V     
    for h = 1:H
        if ~isempty(DBT{v,h})                        % 非空判定
            r = r + 1;                               % 用来记录批次的个数
            GDTW{r,1} = G{v,h};
            GDTW{r,2} = DBT{v,h}(1,1);               % 最早最佳时间
            GDTW{r,3} = DBT{v,h}(size(DBT{v,h},1),1);% 最晚最佳时
            GDTW{r,5} = v;                           % 记录所用车辆的编号用于后期解码计算运输成本
        end
    end
end
GDTW = GDTW(1:r,:);
[GDTW,index3] = sortrows(GDTW,[2 3],{'ascend' 'ascend'}); % index代表零售商顺序
GDTW = GDTW';                                             % 储存批次，最佳配送时间（最早，最晚）

%记录车辆巡回环的索引次序
e = 0;GSI = zeros(V,H);                 % GSI用来储存生产批次的顺序索引
for v = 1:V     
    for h = 1:H
        if isempty(DBT{v,h}) == 0       % 非空判定
           e = e + 1;
           GSI(v,h) = find(index3 == e);
        end
    end
end           
for i = 1:r                             % 保留一个巡回的整体运输模糊时间
    if size(GDTW{1,i},2) == 1           % 该批次就一个订单
       GDTW{4,i}=X{GDTW{1,i}}*2;
    else                                % 该批次多个订单
       tran=[0 0 0];
       for j=1:size(GDTW{1,i},2)-1
           tran=tran+timespan{GDTW{1,i}(1,j),GDTW{1,i}(1,j+1)};  
       end
       GDTW{4,i}=X{GDTW{1,i}(1,1)}+X{GDTW{1,i}(1,size(GDTW{1,i},2))}+tran; % 储存巡回运输模糊时间
    end
end

%批次各产线的生产持续时间
PNumber = size(produce,1);
GNumber = size(GDTW,2);
GPT = zeros(PNumber,GNumber);                           % 生产持续时间
GPN = zeros(PNumber,GNumber);                           % 批次的产品数矩阵
for j = 1:GNumber
   for k = 1:size(GDTW{1,j},2)
       GPN(:,j) = GPN(:,j) + produce(:,GDTW{1,j}(1,k)); % 批次各产线上的产品数
   end
end  
for i = 1:PNumber
   GPT(i,:) = GPN(i,:) * takt(i);                       % 生产时间=产品数*节拍
   GPT = round(GPT,4);                                  % 小数点后位数太多无意义
end