%% |Fuzzy Superposition Operation and Knowledgedriven Co-evolutionary Algorithm for Integrated Production Scheduling and Vehicle Routing Problem with Soft Time Windows and Fuzzy Travel Times|
%%Algorithm name: Knowledge-driven Co-evolutionary Algorithm 知识驱动的双种群协同进化算法（KDCEA）
clc
clear
global  timespan X produce timewindows takt pc pallet vcapacity vfixcost vvarcost occupy Re Rd holding; %全局常量

%% 读取数据
path='D:\桌面\IPSVRP-STW-FTT-Dateset\instance3-4-20\';
Data={'traveltime','retailsneed','other'};
xlsx_tail='.xlsx';
PATH1=[path,Data{1,1},xlsx_tail];
PATH2=[path,Data{1,2},xlsx_tail];
PATH3=[path,Data{1,3},xlsx_tail];
[timespan,X,produce,timewindows,takt,pc,pallet,vcapacity,vfixcost,vvarcost]=read_para(PATH1,PATH2,PATH3);
clear PATH1 PATH2 PATH3
%创立写结果的文件夹
respath='result\';
respath=[respath,'Data3-4-20','\'];
a=['mkdir ' respath];
system(a);%利用Windows命令行命令执行dos命令
fprintf('%s %s\r\n','Calculating ',respath);
%% 基本参数设置
    Re = 1;                              % Early time penalty rate for per pallet product
    Rd = 3;                              % Delay time penalty rate for per pallet product
    holding = 10;                        % Holding cost rate for inventory of a pallet of products
    obj_no = 2;                          % 目标函数的个数
    Max_iteration = 50;                 % 最大迭代次数
    population_num = 500;                % 每个子种群中的个体数目 Corresponding to N in the paper
    U = 0.01;                            % Improved baseline for the utility function U
    IP = 0.7;                            % The iteration percentage for performing adaptive weight adjustment IP
    NR = 1;                              % Number of individuals replaced in each update NR
    KL = 1000;                           % Record length of the knowledge set RL.
    K = 4;                               % Number of operators
    rate_update_weight = 0.05;           % 更新权重参数比例
    wag = 20;                            % 利用AWA的迭代间隔
    T = ceil(population_num/10);         % 邻居规模
    nEP = ceil(population_num*1.5);      % 外部精英的最大储存量
    Pi_1 = ones(population_num,1);       % Utility for each subproblem
    Pi_2 = ones(population_num,1);       % Utility for each subproblem
    
%% 权重向量（解映射向量）
    [Weight,population_num] = UniformPoint(population_num,2);         % 超过2维以后 为了保证初始点的均匀 种群数可能改变
    Weight1 = 1./Weight./repmat(sum(1./Weight,2),1,size(Weight,2));   % WS-transformation method
    Weight2 = Weight1;
    
%% 个体邻域的生成
    Neighbor = pdist2(Weight1,Weight1);                              % 欧式距离矩阵
    [~,Neighbor] = sort(Neighbor,2);                                 % 按行排序 取其从小到大的索引
    Neighbor = Neighbor(:,1:T);                                      % 取最小的T个权重向量为邻居(包括其本身的)
    
%% Initial population
   %%计算零售商订单占据托盘量
   [PNumber,MNumber] = size(produce);
   VNumber = size(vcapacity,1); 
   occupy = (pallet'*produce)';    
   %%产生随机初始可行解，并且获得各零售商依据订单容量可选的车序号集合(后续的进化操作时会用到)
   rpopulation = zeros(population_num,MNumber);
   selectv = cell([1,MNumber]);                                           % 储存零售商可选的车辆
   for  j = 1:MNumber
        selectv{1,j} = find(vcapacity(:,1)>=occupy(j));                   % 本行代码仅支持数据传入时车辆容量是按降序排列的 因此可选的车序号连续
        rpopulation(:,j) = randi(size(selectv{1,j},1),population_num,1);  % 要考虑该订单所能随机选择的车容量应是大于该订单容量的才能执行交付。              
   end
   population = rpopulation;             % 随机选取初始种群  
   ObjectF = Fitnessvalue(population);
   Object = fuzzyEx(ObjectF);
   
   Z1 = min(Object,[],1);                % 储存子种群A，B的参考点
   Z2 = min(Object,[],1);
   Z_bad = max(Object,[],1);             % 储存子种群B的最坏参考点
   merge = [population,Object];
   [merge,~] = sortrows([population,Object],[MNumber+1 MNumber+2],{'ascend' 'descend'});   %依据权重向量先将初始个体排序以期适应进化
   population1 = merge(:,1:MNumber);     % 采用标准切比雪夫函数作为更新策略    由于成本目标的数量级大，向左搜索
   population2 = merge(:,1:MNumber);     % 采用归一化的切比雪夫函数作为更新策略   弥补向下搜索的薄弱部分
   Object1 = merge(:,MNumber+1:MNumber+2);
   Object2 = merge(:,MNumber+1:MNumber+2);
   Object_init1 = Object1;
   Object_init2 = Object2;    
   %%初始化外部种群
   merge = unique( merge,'row');                                        % 去除重复个体
   Final_population = non_domination_sort_mod_min( merge,2, MNumber);
   frontnumber =  find(Final_population(:,2+MNumber+1)==1,1,'last');    % 储存前沿面个体数
   if frontnumber > nEP
            total_EP = Final_population(1:frontnumber,1:MNumber + 4);
            [f,~] = sortrows(Final_population(1:frontnumber,:),[MNumber+2+1 MNumber+2+2],{'ascend' 'descend'}); 
            EP = f(1:nEP,1:MNumber +2);
   else
            EP = Final_population(1:frontnumber,1:MNumber +2);
   end
   
%% Optimization
   CV_1 = zeros(1,K);	                  % Credit value of each operator
   CV_2 = zeros(1,K);	                  % Credit value of each operator
   KS_1 = zeros(2,KL);	                  % 知识集 knowledge set 
   KS_2 = zeros(2,KL);	                  % 知识集 knowledge set 
   for iter = 1:Max_iteration
        %% 标准的切比雪夫聚合
         for subgeneration = 1 : 5
            % Choose I  （子迭代种群）
            Bounday = find(sum(Weight<1e-3,2) == 2-1)';           % 取出pareto上下边界的两个值（2个边界）三个目标就是三个值
            I1 = [tournamentselect_utility(Pi_1,floor(population_num/5)-length(Bounday),10),Bounday]; % 基于效应函数和10元锦标赛选取出五分之一的种群个体
            % For each solution in I
            for i = 1: size(I1,2)
                % knowledge-drival operator selection 
                op = Knowledge_drival(CV_1,KS_1,K);               % op代表选用的算子编号
                % Choose the parents （实际选择的邻域区域）
                if rand < 0.9
                    P = Neighbor(I1(i),randperm(end)); 
                else
                    P = randperm(population_num);
                end
                % Generate an offspring based operator
                Offspring = mating(selectv,op,population1(I1(i),:),population1,P,MNumber,EP);
                Object_Off = fuzzyEx(Fitnessvalue(Offspring));
                Object_Off = round(Object_Off);
                % Update the ideal point
                Z1 = min(Z1,Object_Off);
                % Update the solutions in P by Tchebycheff approach
                g_old = max(abs(Object1(P,:)-repmat(Z1,length(P),1)).*Weight1(P,:),[],2);
                g_new = max(repmat(abs(Object_Off-Z1),length(P),1).*Weight1(P,:),[],2);
                replace = find(g_old>g_new,NR);
                if replace > 0
                   for i = 1:length(replace)
                        population1(P(replace(i)),:) = Offspring;
                        Object1(P(replace(i)),:) = Object_Off;
                   end
                end              
                % Update knowledge set 
                TIR = sum((g_old(replace)-g_new(replace))./(g_old(replace)+1e-6)); % The improvement rate of the Tchebycheff function(TIR)
                KS_1 = [KS_1(1,2:end),op;KS_1(2,2:end),TIR];                       % The first-in-first-out (FIFO).实现知识的动态更新
                % Update Credit value of each operator
                Reward = zeros(1,K);
                for k = 1 : K
                    Reward(k) = sum(KS_1(2,KS_1(1,:)==k));
                end
                CV_1 = Reward./(sum(Reward)+1e-6);
            end
         end
          % Update Pi for each solution  周期更新效应
          % Old Tchebycheff function value of each solution on its subproblem
         if iter == 1
            oldObj1 = max(abs(Object_init1-repmat(Z1,population_num,1)).*Weight1,[],2);
         end
         newObj1 = max(abs(Object1-repmat(Z1,population_num,1)).*Weight1,[],2);
         DELTA = abs(oldObj1-newObj1)./oldObj1;
         Temp = DELTA < U;
         Pi_1(~Temp) = 1;
         Pi_1(Temp) = (0.95+0.05*DELTA(Temp)/U).*Pi_1(Temp);
         oldObj1 = newObj1;  
       %% 归一化的切比雪夫聚合
        for subgeneration = 1 : 5
            % Choose I  
            Bounday = find(sum(Weight<1e-3,2)==2-1)';
            I2 = [tournamentselect_utility(Pi_2,floor(population_num/5)-length(Bounday),10),Bounday];
            % For each solution in I
            for i = 1: size(I2,2)
                % knowledge-drival operator selection 
                op = Knowledge_drival(CV_2,KS_2,K);            % op代表选用的算子编号
                % Choose the parents
                if rand < 0.9
                    P = Neighbor(I2(i),randperm(end)); 
                else
                    P = randperm(population_num);
                end
                % Generate an offspring based operator
                Offspring = mating(selectv,op,population2(I2(i),:),population2,P,MNumber,EP);
                Object_Off = fuzzyEx(Fitnessvalue(Offspring));
                Object_Off = round(Object_Off); 
                % Update the ideal point
                Z2 = min(Z2,Object_Off);
                % Update the solutions in P by Tchebycheff approach
                g_old = max(abs(Object2(P,:)-repmat(Z2,length(P),1))./(Z_bad-Z2+1e-6).*Weight2(P,:),[],2);
                g_new = max(repmat(abs(Object_Off-Z2)./(Z_bad-Z2+1e-6),length(P),1).*Weight2(P,:),[],2);
                replace = find(g_old>g_new,NR);
                if replace > 0
                   for i = 1:length(replace)
                       population2(P(replace(i)),:) = Offspring;
                       Object2(P(replace(i)),:) = Object_Off;
                   end
                end 
                % Update knowledge set 
                TIR = sum((g_old(replace)-g_new(replace))./(g_old(replace)+1e-6)); % The improvement rate of the Tchebycheff function(TIR)
                KS_2  = [KS_2(1,2:end),op;KS_2(2,2:end),TIR];                      % The first-in-first-out (FIFO).实现知识的动态更新
                % Update Credit value of each operator
                Reward = zeros(1,K);
                for k = 1 : K
                    Reward(k) = sum(KS_2(2,KS_2(1,:)==k));
                end
                CV_2 = Reward./(sum(Reward)+1e-6);
            end
        end
        % Update Pi for each solution
        % Old Tchebycheff function value of each solution on its subproblem
        Z_bad_new = max(Object2,[],1); 
        if iter == 1
           oldObj2 = max(abs(Object_init2-repmat(Z2,population_num,1))./(Z_bad-Z2+1e-6).*Weight2,[],2);
        end
        newObj2 = max(abs(Object2-repmat(Z2,population_num,1))./(Z_bad-Z2+1e-6).*Weight2,[],2);
        DELTA = abs(oldObj2-newObj2)./oldObj2;
        Temp = DELTA < U;
        Pi_2(~Temp) = 1;
        Pi_2(Temp) = (0.95+0.05*DELTA(Temp)/ U) .* Pi_2(Temp);
        oldObj2 = newObj2;
        Z_bad = Z_bad_new;
       %% Update EP for population
        merge = [EP;[population1,Object1];[population2,Object2]];
        merge = unique( merge,'row');
        Final_population = non_domination_sort_mod_min( merge,2, MNumber);
        frontnumber =  find(Final_population(:,2+MNumber+1)==1,1,'last');
        if frontnumber > nEP
            total_EP = Final_population(1:frontnumber,1:MNumber + 4);
            [f,index2] = sortrows(Final_population(1:frontnumber,:),[MNumber+2+1 MNumber+2+2],{'ascend' 'descend'});
            clear index2
            EP = f(1:nEP,1:MNumber +2);
        else
            EP = Final_population(1:frontnumber,1:MNumber +2);
        end
        % Adaptive weight adjustment
        if ~mod(iter,wag) && iter >= IP * Max_iteration
            [population_object1,Weight1,Pi_1] = updateWeight([population1,Object1],Weight1,Z1,EP,rate_update_weight*population_num,Pi_1);
            [population_object2,Weight2,Pi_2] = updateWeightU([population2,Object2],Weight2,Z2,EP,rate_update_weight*population_num,Pi_2);        
            population1 = population_object1(:,1:MNumber);
            Object1 = population_object1(:,MNumber+1:MNumber+2);
            population2 = population_object2(:,1:MNumber);
            Object2 = population_object2(:,MNumber+1:MNumber+2);
        end
       %% Visualize        
        disp(['KDCEA algorithm ', num2str(iter), 'st iteration has ', num2str(size(EP,1)), ' non-dominated solutions']);
        figure(1)
        plot(Object1(:, 1),Object1(:, 2),'*','MarkerSize',5,'MarkerEdgeColor','#303030'); %表征子种群1变化
        plot(Object2(:, 1),Object2(:, 2),'o','MarkerSize',5,'MarkerEdgeColor','#FF7802'); %表征子种群2变化
        hold on ;
        title('Evolutionary map of subpopulations','fontsize',12)
        xlabel('TC(yuan)','fontsize',12)
        ylabel('ETPT(hour)','fontsize',12)
        legend({'Subpopulation 1','Subpopulation 2'},'Location','northeast','NumColumns',4);
        set (gcf,'Position',[50,50,700,500], 'color','w') 
        figure(2)
        plot(EP(:,MNumber + 1),EP(:,MNumber + 2),'*');% 表征前沿面
        title('Pareto front','fontsize',12)
        xlabel('TC(yuan)','fontsize',12)
        ylabel('ETPT(hour)','fontsize',12)
        legend({'pareto solution'},'Location','northeast','NumColumns',4);
        set (gcf,'Position',[800,50,700,500], 'color','w') 
        drawnow  
   end
   saveas(1,[respath,'evolution process.jpg'])
   saveas(2,[respath,'pareto front.jpg'])
   save([respath,'pareto solutions.mat'],'EP','-nocompression'); % 保存变量以.mat的形式
