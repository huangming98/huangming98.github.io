function    Fitness = Fitnessvalue(population)
%% **************解码过程 *********************
population_num = size(population,1);
Fitness = cell([population_num,2]);
for i = 1:population_num
    individual = population(i,:);
   %% 巡回环划分策略: 得出车辆巡回环表G   
    G = S1_routing(individual);
   %% 巡回环（批次）理想最优配送时间区间或者时刻
    %（确定情况下的理想最优配送时间往往是区间；而fuzzy情况下几乎不可能是区间 因为要用到模糊惩罚时间中的比较大小，往往是时刻）
    %%计算最佳车辆配送的开始时间BT(BEST TIME) 以总模糊惩罚时间最小为量化指标进行选优  
    [G,DBT] = S2_besttime(G); % 配送出发最优值
   %% 三项调整得出生产和库存计划
    %%GDTW   将批次按理想最优配送时间排序后第一行储存批次组成，2、3行储存其理想最优配送时间区间或时刻（最早时间，最晚时间）,最后一行储存该巡回环的路由时间；
    %%GSI    记录车辆巡回环的索引次序，并在后续的甘特图绘制中也需要用到；
    %%GPT    储存批次在各产线上的生产持续时间；
    %%GPN    储存批次在各产线上的产品数；
    [GDTW,GSI,GPT,GPN] = S3_groupDPtime(G,DBT);
    %%整体的排产及各出发时刻的确定
    %%批次的生产开始时间 生产完成时间和模糊配送时间三个储存单元组（GST GFT GDT）
    [GST,GFT,GDT,stockoccupy] = S3_PLadjustment(G,GPT,GPN,GSI,GDTW);
    %% 计算目标函数值即适应度值函数
    Z = objective(GST,GFT,GDT,GDTW,GSI,stockoccupy);
    Fitness{i,1} = Z{1,1};
    Fitness{i,2} = Z{1,2};
end