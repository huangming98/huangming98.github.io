function N = OP3(x,negihborhood_population,selectv,MNumber)
%% Vehicle replacement based on least frequently
%将当前个体的多个位置的编码改为出现次数最少的车辆配送方式进行配送相同位变成不同位 寻找其中Ci个
N = []; 
N = x;
negihborhood_population = [negihborhood_population;N];
sp = randperm(MNumber - ceil(MNumber * 0.3),1) + ceil(MNumber * 0.3);
Mob = randperm(MNumber,sp);
for k = 1:sp
    chuxian_v = unique(negihborhood_population(:,Mob(k)));
    if size(chuxian_v,1) < size(selectv{1,Mob(k)},1)                       % 邻域内该订单所选车辆并未出现全部可能
          diffv = setdiff(selectv{1,Mob(k)},chuxian_v);                    % 未出现的车辆码
          N(1,Mob(k)) = diffv(unidrnd(length(diffv)),1);                   % 在未出现的车辆码随机选
    else  % 可选车辆全部出现需要找最少出现的那辆车 如果最少出现的一样则随机选。
          countv = histcounts(negihborhood_population(:,Mob(k)));          
          countv(countv == 0) = [];                                        % 用于避免为0时占用一个位置导致选择是超出数组索引
          %%必须由可能有的车辆容量小不能满足某一零售商的货物，导致可选车辆不全但是都出现了可能出现0导致索引错误。
          countvindex = find(countv == min(countv));
          svindex = countvindex(1,unidrnd(size(countvindex,2)));           % 如果最少出现的一样则随机选
          sv = chuxian_v;
          N(1,Mob(k)) = sv(svindex,1);
    end
end 