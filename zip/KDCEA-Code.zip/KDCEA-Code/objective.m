function Z = objective(GST,GFT,GDT,GDTW,GSI,stockoccupy)
%% 计算目标函数值即适应度值函数
global produce vfixcost pc  holding vvarcost
%%总成本的计算
 Z = cell([1,2]);
[PNumber,R] = size(GST);
%%生产成本
cost1 = 0;
sum_number = sum(produce,2);
cost1 = pc' * sum_number;
%%库存成本的求解  
cost2 = [];
for i = 1:R
    GGDT = repmat(GDT{1,i},PNumber,1);                                    % 重复数组行用来矩阵运算
    cost2(i,1:3) = sum((GGDT - GFT(:,i)) .* stockoccupy(:,i)) * holding;  % 等价于 (GGDT-GFT(:,i)).*repmat(stockoccupy(:,i),1,3)
end
cost2 = sum(cost2);  % 模糊数形式
%%车辆的配送成本
cost3 = 0;
vvcost = [0 0 0];
for i = 1:R
    vvcost = vvarcost(GDTW{5,i},1) * GDTW{4,i} + vvcost;   
end
vuse = size(GSI,1);                            % 可能用车中有三辆车只用二辆所以遍历时不能用VNumber作为遍历的终止代数。
for v = 1:vuse
   cost3 = nnz(GSI(v,:)) * vfixcost(v) + cost3;   % N = nnz(X) 返回矩阵 X 中的非零元素数。可以替换find 后在用size的方法
end
cost3 = cost3 + vvcost;
%提前延期惩罚时间
totaltime = [0 0 0];                           % 提前和延期惩罚模糊时间。
for i = 1:R                                    % 每个批次
    [edpc] = Fuzzypenaltytime(GDTW{1,i},GDT{1,i});
    totaltime = totaltime + edpc;
end    
Z{1,1} = cost1 + cost2 + cost3; 
Z{1,2} = totaltime;