% % 算法对比主程序（以各目标的10次均值为选择依据进行对比）
% %（10次的指标均值，以及在这10次中各指标的最好值被储存）
% 
% % 清空环境 
% clc;clear
% 
% %%数据
% global  timespan X produce timewindows takt pc pallet vcapacity vfixcost vvarcost occupy Re Rd holding;%变成全局变量避免传参频繁，精简代码
% 
% path='D:\桌面\IPSVRP-STW-FTT-Dateset\instance3-4-20\';
% Data={'traveltime','retailsneed','other'};
% xlsx_tail='.xlsx';
% 
%  PATH1=[path,Data{1,1},xlsx_tail];
%  PATH2=[path,Data{1,2},xlsx_tail];
%  PATH3=[path,Data{1,3},xlsx_tail];
% [timespan,X,produce,timewindows,takt,pc,pallet,vcapacity,vfixcost,vvarcost]=read_para(PATH1,PATH2,PATH3);%读取数据
% clear PATH1 PATH2 PATH3
% Re=1;                              %提前惩罚时间率
% Rd=3;                              %延期惩罚时间率(时间比率在1：3延期相比于提前是更不能接受的)
% holding=10;                        %单位托盘的库存持有成本率
% [PNumber,MNumber]=size(produce);
% VNumber=size(vcapacity,1); 
% occupy=(pallet'*produce)'; 
% 
% %创立写结果的文件夹
% respath='result\';
% respath=[respath,'Data3-4-20','\'];
% a=['mkdir ' respath];
% system(a);%利用Windows命令行命令执行dos命令  如果该文件已经存在会提醒已存在。
% fprintf('%s %s\r\n','Calculating ','Data5-6-30');
% runtime=[];
% 
% %% matlab并行操作测试
% all_front_population=cell([10,1]);
% tic
% parfor  iii=1:10
%     unique_vis_front_population1=z_KDCEA(iii);% 知识驱动协同进化算法
%     all_front_population{iii,1}=unique_vis_front_population1;
% end
% toc
% runtime(1,1)=toc;
% 
%% 计算所有实验的算法结果(最小值、平均、最大值)
result_set=inf(3,2);%每两列为一组算法结果第一列是利润，第二列是惩罚时间
result_alg1 = cell2mat(all_front_population);
pop_num=size(result_alg1,1);%等于零售商+2
result_alg2 = result_alg1(:,end-1:end);
result_set(1,1:2) = min(result_alg2);
result_set(2,1:2)= sum(result_alg2)/pop_num;
result_set(3,1:2) = max(result_alg2);

%% 计算所有实验的四个指标值，
%画前沿面对比图和计算这六个算法的四个评价指标
zuhe=all_front_population;
allpop=cell2mat(zuhe);
num=size(allpop,2);%等于零售商+2
allpop=allpop(:,num-1:num);%allpop代表所有算法所得的前沿面种群的集合

Score=inf(10,4);
for i=1:10
    PopObj=zuhe{i,1}(:,end-1:end);%算法所得的前沿
    Score(i,1) = Metric_ER(PopObj,allpop);
    Score(i,2) = Metric_DM(PopObj,allpop);
    Score(i,3) = Metric_IGD(PopObj,allpop);
    Score(i,4) = Metric_HV(PopObj,allpop);
end
mean=inf(1,4);
best=inf(1,4);
mean(1,1) = sum(Score(:,1))/10;
mean(1,2) = sum(Score(:,2))/10;
mean(1,3) = sum(Score(:,3))/10;
mean(1,4) = sum(Score(:,4))/10;
best(1,1) = min(Score(:,1));
best(1,2) = min(Score(:,2));
best(1,3) = min(Score(:,3));
[best(1,4),num] = max(Score(:,4)); 
select_zuhe=zuhe(num,:);       %储存以指标HV选择每个算法的最好的解集
PopObj=select_zuhe{1,1}(:,end-1:end);%算法所得的前沿
writematrix(PopObj,[respath,'score-pareto.xls'],'Sheet','pareto','Range','A1:B100'); 

%% 保存数据文件
save([respath,'allpopulation.mat'],'all_front_population','runtime','select_zuhe','result_set','mean','best','-nocompression'); % 保存变量以.mat的形式
writematrix(result_set,[respath,'score-pareto.xls'],'Sheet','result_set');
writematrix(mean,[respath,'score-pareto.xls'],'Sheet','mean');
writematrix(best,[respath,'score-pareto.xls'],'Sheet','best');
writematrix(runtime,[respath,'score-pareto.xls'],'Sheet','pareto','Range','Q1:Q10');%储存十次总程序时间
runtime_mean=runtime/10;
writematrix(runtime_mean,[respath,'score-pareto.xls'],'Sheet','pareto','Range','R1:R10');%储存程序均值时间

%可视化
unique_vis_front=select_zuhe{1,1}(:,end-1:end);
unique_vis_front=sortrows(unique_vis_front);
plot(unique_vis_front(:,1),unique_vis_front(:,2),['-' 'o' 'g'],'MarkerSize',4,'MarkerfaceColor','g'); 
title('Pareto front','fontsize',12)
xlabel('TC(yuan)','fontsize',12)
ylabel('ETPT(hour)','fontsize',12)
legend({'KDCEA'},'Location','northeast','NumColumns',4);
set (gcf,'Position',[50,50,800,500], 'color','w') 
saveas(gcf,[respath,'pareto front.jpg'])
    
