function [G,DBT]=S2_besttime(G)
%% 巡回环（批次）理想最优配送时间区间或者时刻
%%计算最佳车辆配送的开始时间BT(BEST TIME) 以总模糊惩罚时间最小为量化指标进行选优
global timewindows timespan X  
V = size(G,1);
H = size(G,2);
DBT = cell([V,H]); 
for v = 1:V                       % 找到每一个位置最佳开始时间，遇到空集时（利用isempty）令BT{v,h}=[]
    TDBT = {};                    % 用于储存巡回环理想的出发时间节点或区间
    for h = 1:H
        if ~isempty(G{v,h})       % 非空判定
            M = G{v,h};            % 用来储存该巡回环每个零售商的分段函数间断点
            for k = 1:size(M,2)
                if k == 1
                   M(2,k) = timewindows(M(1,k),1) - fuzzyEx(X(M(1,k)));M(3,k) = timewindows(M(1,k),2) - fuzzyEx(X(M(1,k)));    
                else
                   M(2,k) = timewindows(M(1,k),1);
                   for z = 1:k - 1 
                       M(2,k) = M(2,k) - fuzzyEx(timespan(M(1,z),M(1,z + 1)));   
                   end
                   M(2,k) = M(2,k) - fuzzyEx(X(M(1,1)));
                   M(3,k) = M(2,k) + timewindows(M(1,k),2) - timewindows(M(1,k),1);
                end
             end
            M = M(2:3,:);
            M = round(M,1);  
            M = unique(M(:));         % 用来储存该巡回环每个零售商的分段函数间断点，从而得出理想最佳时间节点
            M(M < 0) = 0;             % 最早从0开始配送
            edtc = inf(size(M,1),3);  % 单位容量总提前延期加权时间
            for i = 1:size(M,1)       % 遍历节点
                [edpc] = Fuzzypenaltytime(G{v,h},M(i));
                edtc(i,1:3) = edpc;
            end
            mini = fuzzycom_min(edtc);    
            DBT{v,h} = M(mini);        % 可能有多个，因为可能都在时间窗内[0 0 0] 计算的罚时也均为0      
            TDBT{h,1} = DBT{v,h}(1,1);
            TDBT{h,2} = DBT{v,h}(size(DBT{v,h},1),1); 
        end                                 
    end
    if ~isempty(TDBT)                   % 在同一车中对于出现后巡回环理想出发节点在前巡回环的前面的情况时，进行更改DBT G 的零售商序列顺序
        [TDBT,index5] = sortrows(TDBT,[1 2],{'ascend' 'ascend'});   %TDBT形成一个2行*该车巡回环数的cell  %index代表零售商顺序%利用index5去排序G和DBT
        DBTtemp = cell([1,H]);Gtemp = cell([1,H]);
        for k = 1:size(index5,1)
            DBTtemp{1,k} = DBT{v,index5(k)};        
            Gtemp{1,k} = G{v,index5(k)};      %中间变量去赋值
        end
        for k = 1:size(index5,1)
             DBT{v,k} = DBTtemp{1,k};
             G{v,k} = Gtemp{1,k};
        end
    end
end