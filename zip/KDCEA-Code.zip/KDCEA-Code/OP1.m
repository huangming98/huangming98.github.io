function N = OP1(x,selectv)
%% a rank-based roulette wheel strategy is used to select batch with low load rate, and randomly replacing.
global   vcapacity  occupy;
%负载换车操作  容量负载比例最小的被选中交换的概率越大  基于排序的轮盘赌机制
N = [];   % 用于储存换车操作的后的邻域种群
G = S1_routing(x);
%用LR代表该批次占据容量/最大容量（表征占有率）
V = size(G,1); H = size(G,2);
LR = zeros(V,H);
r = 0; CV = [];
GLR = cell([V * H,2]);
for i = 1:V
    for j = 1:H
        if ~isempty(G{i,j})
            r = r + 1;
            for k = 1:size(G{i,j},2)
               LR(i,j) = LR(i,j) + occupy(G{i,j}(1,k),1);   
            end 
            GLR{r,1} = G{i,j};                   % orders of the batch
            GLR{r,2} = LR(i,j)/vcapacity(i,1);   % 负载率
        end     
    end
end

GLR = GLR(1:r,:);
GLR = sortrows(GLR,2,{'ascend'});                % index代表零售商顺序
for i = 1:r
    CV(i) = 1/(GLR{i,2}*i);                      % 信用值
end
batch = RouletteWheelSelection(CV);              % 按权重选择一个需要换车的批次
G_A = GLR{batch,1};                              % 该环所包含的零售商
%%随机换车
N = x;
for k = 1:size(G_A,1)
    Mobile = selectv{1,G_A(k)};
    Mobilev = Mobile(unidrnd(size(Mobile,1)),1); % 随机选后选中的车的编码
    N(1,G_A(k)) = Mobilev;
end          