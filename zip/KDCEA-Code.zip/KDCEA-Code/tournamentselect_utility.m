function pool = tournamentselect_utility(utility, pool_size, tour_size)
%% 基于效应函数的锦标赛选择法
%,pool_size选出个体数, tour_size进行锦标赛的个体数)
total_num = size(utility,1);
pool = [];
for i = 1:pool_size
    select = randperm(total_num);
    select = select(1,1:tour_size);
    [~,rank] = max(utility(select'));
    pool(i) = select(rank);
end
