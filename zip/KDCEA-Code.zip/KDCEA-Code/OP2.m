function N = OP2(x,selectv)
%%  为加权惩罚时间最大的批次更换车辆编号 
N = [];                                         % 用于储存换车操作的后的邻域种群
G = S1_routing(x);
[G,DBT] = S2_besttime(G);                       % 配送出发最优值
[GDTW,GSI,GPT,GPN] = S3_groupDPtime(G,DBT);
[GST,GFT,GDT,stockoccupy] = S3_PLadjustment(G,GPT,GPN,GSI,GDTW);
for i = 1:size(GST,2)                           % 每个批次
    edpc = Fuzzypenaltytime(GDTW{1,i},GDT{1,i});
    batch(i) = fuzzyEx({edpc});
end     
[~,batch_select] = max(batch);
G_A = GDTW{1,batch_select};                     % 该环所包含的零售商
%%%随机换车
N = x;
for k = 1:size(G_A,1)
    Mobile = selectv{1,G_A(k)};
    Mobilev = Mobile(unidrnd(size(Mobile,1)),1);% 随机选后选中的车的编码
    N(1,G_A(k)) = Mobilev;
end          