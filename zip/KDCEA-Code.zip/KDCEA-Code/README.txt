Knowledge-driven Co-evolutionary Algorithm(KDCEA) Code
Including the following key points:
1.Algorithm specific execution process; (KDCEA.m)
2.Fuzzy Superposition Operation; (fuzzy_superposition.m)
3.Four indicators for multi-objective optimization; (Metric_ER.m, Metric_DM.m, Metric_IGD.m, Metric_HV.m）
4.Main procedure for algorithmic parallel computational experiments; (par_calcuate_mean.m)
5.Draw Gantt Chart; (GANTT.m)