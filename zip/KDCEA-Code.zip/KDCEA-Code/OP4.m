function N = OP4(x,EP,selectv,MNumber)
%% External population to guide and assist the evolution of the two subpopulations
N = x;
%两点交叉
ep = randperm(size(EP,1),1);
dian = randperm(MNumber,2);
dian_1 = dian(1,1);
dian_2 = dian(1,2);
if dian_1 > dian_2
   temp1 = dian_1;
   dian_1 = dian_2;
   dian_2 = temp1;
end    
N(:,dian_1:dian_2) = EP(ep,dian_1:dian_2); 
%多点变异
p = randperm(MNumber,ceil(0.1*MNumber));                % 变异的位置
for  i = 1:length(p)
   selv = setdiff(selectv{1,p(i)},x(:,p(i)),'stable');  % 找到可选车但刨去当前与当前相同的编码后的可选集合selv是行向量
   N(:,p(i)) = selv(unidrnd(size(selv,1)),1);           % 随机选后选中的车的编码
end